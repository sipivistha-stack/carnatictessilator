/**
 * Type definitions for EduTask Studio
 */

export type Role = 'student' | 'teacher';

export type TaskCategory = 'temporary_task' | 'assignment' | 'examination';

export type TaskType = 
  | 'coding'
  | 'mcq'
  | 'quiz'
  | 'word_doc'
  | 'ppt'
  | 'excel'
  | 'upload'
  | 'video'
  | 'image'
  | 'text'
  | 'drawing'
  | 'carnatic_music'
  | 'typing_exam';

export type TaskStatus = 'active' | 'stopped';

export type ProgrammingLanguage = 'c' | 'cpp' | 'python' | 'javascript' | 'java' | 'html';

export type StudentTier = 'bright' | 'average' | 'failing';

export interface McqQuestion {
  id: string;
  question: string;
  options: string[];
  correctOptionIndex: number;
  explanation?: string;
  points: number;
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctOptionIndex: number;
  points: number;
}

export interface CarnaticConfig {
  raga: string; // e.g. "Mayamalavagowla", "Kalyani", "Mohanam", "Hamsadhwani"
  tala: string; // e.g. "Adi Tala (8 aksharas)", "Rupaka Tala (6 aksharas)", "Mishra Chapu (7 aksharas)"
  baseShruti: string; // e.g. "C (1 Kattai)", "C# (1.5 Kattai)", "D (2 Kattai)", "G (5 Kattai)"
  taskAspect: 'theory_internal' | 'viva_vocal' | 'tala_meter' | 'swara_notation';
  recommendedSpeed?: string; // "1st Kala (Vilambita)", "2nd Kala (Madhyama)", "3rd Kala (Dhruta)"
  sampleNotation?: string;
  instructions: string;
  enabledTools?: ('shruti_box' | 'tala_meter' | 'swara_keyboard' | 'raga_explorer' | 'audio_recorder' | 'alankara_pad')[];
  singingActivity?: boolean;
  recordingRequired?: boolean;
  recordingMaxSeconds?: number;
  lyricsByLevel?: { beginner?: string; intermediate?: string; advanced?: string };
  strictSubmission?: boolean;
}

export interface TypingConfig {
  passage: string;
  targetWpm?: number;
  minAccuracyPercentage?: number;
  timeLimitSeconds?: number;
}

export interface Task {
  id: string;
  title: string;
  description: string;
  category: TaskCategory; // 'temporary_task' (Dashboard) | 'assignment' (Assignments) | 'examination' (Examination Section)
  type: TaskType;
  status: TaskStatus; // 'active' (visible to students) | 'stopped' (hidden from students)
  maxPoints: number; // custom marks e.g. 40, 10, 50, 100
  createdAt: string;
  dueDate?: string;
  timeLimitMinutes?: number; // Optional timer for MCQs / Quizzes / Examinations
  classId?: string; // Associated class group
  strictSubmission?: boolean; // AI/student submissions must follow teacher structure; no autocorrection

  // Interconnection / Bundling
  linkedBundleId?: string;
  bundleWeightage?: number;

  // Type specific configurations:
  codingConfig?: {
    language: ProgrammingLanguage;
    starterCode: string;
    instructions: string;
    sampleInput?: string;
    expectedOutput?: string;
  };
  mcqConfig?: {
    questions: McqQuestion[];
  };
  quizConfig?: {
    questions: QuizQuestion[];
  };
  docConfig?: {
    prompt: string;
    minWords?: number;
    sampleTemplate?: string;
  };
  pptConfig?: {
    prompt: string;
    recommendedSlideCount?: number;
  };
  excelConfig?: {
    prompt: string;
    headers: string[];
    sampleRows?: string[][];
  };
  drawingConfig?: {
    prompt: string;
    canvasWidth?: number;
    canvasHeight?: number;
  };
  uploadConfig?: {
    prompt: string;
    allowedExtensions: string[];
    fileCategory: 'all' | 'video' | 'image' | 'document';
  };
  textConfig?: {
    prompt: string;
    minCharacters?: number;
  };
  carnaticConfig?: CarnaticConfig;
  typingConfig?: TypingConfig;
}

export type AnnouncementPriority = 'normal' | 'important' | 'exam_alert';

export interface Announcement {
  id: string;
  title: string;
  content: string;
  priority: AnnouncementPriority;
  classId?: string; // target class or 'all'
  postedBy: string;
  postedAt: string;
  pinned: boolean;
  tags?: string[];
}

export interface AttendanceRecord {
  studentId: string;
  studentName: string;
  rollNo: string;
  status: 'present' | 'absent' | 'late' | 'excused';
  cumulativePercentage: number;
  remarks?: string;
}

export interface AttendanceSession {
  id: string;
  date: string; // YYYY-MM-DD
  classId: string;
  className: string;
  sessionTitle: string;
  records: AttendanceRecord[];
  createdAt: string;
}

export interface PenStroke {
  id: string;
  color: string;
  width: number;
  points: { x: number; y: number }[];
  type?: 'pen' | 'highlighter' | 'eraser';
}

export interface StampAnnotation {
  id: string;
  x: number;
  y: number;
  text: string;
  color: string;
  iconType: 'check' | 'cross' | 'star' | 'question' | 'hundred';
}

export interface TeacherCorrection {
  grade: number; // e.g. 38 out of 40
  maxPoints: number; // e.g. 40
  letterGrade: string; // e.g. 'A+'
  feedback: string;
  evaluatedAt: string;
  penStrokes: PenStroke[];
  stamps?: StampAnnotation[];
  evaluatorName: string;
}

export interface SlideItem {
  id: string;
  title: string;
  bullets: string[];
  notes?: string;
  layout?: 'title' | 'content' | 'two_column' | 'section' | 'blank';
  backgroundColor?: string;
  fontFamily?: string;
}

export interface SubmissionPayload {
  // Coding
  code?: string;
  codeLanguage?: ProgrammingLanguage;
  codeStdout?: string;
  codeStderr?: string;
  codeExecutionSuccess?: boolean;

  // MCQ & Quiz
  selectedOptions?: Record<string, number>;
  autoScore?: number;

  // Word Document
  docTitle?: string;
  docContent?: string;
  docStyles?: {
    fontFamily?: string;
    fontSize?: string;
    textAlign?: string;
    lineSpacing?: string;
    margins?: string;
    pageColor?: string;
  };

  // Presentation (PPT)
  slides?: SlideItem[];
  pptTheme?: string;

  // Spreadsheet (Excel)
  sheetData?: Record<string, string>;

  // Drawing
  drawingDataUrl?: string;

  // File / Image / Video / PDF / Word / PPT / ODF Upload
  fileUrl?: string;
  fileName?: string;
  fileType?: string;
  fileSize?: string;
  fileFormat?: 'pdf' | 'word' | 'ppt' | 'odf' | 'image' | 'video' | 'other';
  documentPages?: { 
    pageNumber: number; 
    title?: string; 
    content: string; 
    subtitle?: string;
    dataUrl?: string;
    width?: number;
    height?: number;
  }[];

  // Text Entry
  textResponse?: string;

  // Carnatic Music Submission
  carnaticAudioUrl?: string;
  carnaticSwaraNotation?: string;
  carnaticRaga?: string;
  carnaticTala?: string;
  carnaticShruti?: string;
  carnaticSelfAssessmentNotes?: string;
  carnaticToolsUsed?: string[];

  // Data Science / Coding Visuals (matplotlib, pandas, numpy, html)
  matplotlibPlotUrl?: string;
  pandasTableHtml?: string;
  htmlPreview?: string;
  stdinProvided?: string;

  // Typing Exam Submission
  typingSpeedWpm?: number;
  typingAccuracyPercentage?: number;
  typingCompletedText?: string;
}

export interface Submission {
  id: string;
  taskId: string;
  taskTitle: string;
  taskType: TaskType;
  taskCategory: TaskCategory;
  studentId: string;
  studentName: string;
  submittedAt: string;
  status: 'submitted' | 'evaluated' | 'returned';
  payload: SubmissionPayload;
  correction?: TeacherCorrection;
}

export interface StudentProfile {
  id: string;
  name: string;
  avatarColor: string;
  section: string;
  rollNo: string;
  classId?: string;
  attendancePercentage?: number;
  tier: StudentTier; // 'bright' | 'average' | 'failing'
  carnaticLevel?: 'beginner' | 'intermediate' | 'advanced';
}

export interface ClassGroup {
  id: string;
  name: string;
  section: string;
  subject: string;
  academicYear: string;
  createdAt: string;
  studentCount?: number;
}

export interface InterconnectedTaskBundle {
  id: string;
  title: string; // e.g. "Carnatic Music Semester Assessment"
  description?: string;
  classId?: string;
  taskIds: string[]; // e.g. ['task-carnatic-internal-40', 'task-viva-10']
  totalMaxMarks: number; // e.g. 50 (40 + 10)
  createdAt: string;
}

export interface ReportCardItem {
  taskId?: string;
  taskTitle: string;
  taskType: TaskType | string;
  category: TaskCategory | string;
  maxMarks: number;
  marksObtained: number;
  letterGrade: string;
  remarks: string;
}

export interface ReportCard {
  id: string;
  studentId: string;
  studentName: string;
  classId: string;
  className: string;
  rollNo: string;
  term: string; // e.g. "Annual Carnatic & Academic Evaluation 2026-27"
  issuedDate: string;
  institutionName: string;
  items: ReportCardItem[];
  totalMaxMarks: number;
  totalMarksObtained: number;
  percentage: number;
  overallGrade: string;
  overallStatus: 'Distinction' | 'First Class' | 'Pass' | 'Needs Improvement';
  attendancePercentage: number;
  teacherRemarks: string;
  principalSignature: string;
  evaluatorName: string;
  publishedToStudent: boolean;
  publishedAt?: string;
}
