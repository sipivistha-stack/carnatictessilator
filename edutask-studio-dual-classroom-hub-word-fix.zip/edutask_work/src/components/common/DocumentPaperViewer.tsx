import React, { useState, useEffect } from 'react';
import { Submission, SubmissionPayload, TaskType } from '../../types';
import { parsePdfPages, RenderedPdfPage } from '../../services/pdfHelper';
import { 
  FileText, 
  Presentation, 
  Table, 
  Code2, 
  FileSpreadsheet, 
  Download, 
  ExternalLink,
  BookOpen,
  ChevronDown,
  Layers,
  FileCheck,
  Eye,
  Loader2,
  RefreshCw,
  Music,
  Keyboard,
  Mic,
  Volume2
} from 'lucide-react';

interface DocumentPaperViewerProps {
  submission: Submission;
  isAnnotating?: boolean;
}

export const DocumentPaperViewer: React.FC<DocumentPaperViewerProps> = ({
  submission,
  isAnnotating = false,
}) => {
  const { payload, taskType, taskTitle, studentName } = submission;

  const [dynamicPages, setDynamicPages] = useState<RenderedPdfPage[] | null>(null);
  const [isExtractingPdf, setIsExtractingPdf] = useState<boolean>(false);
  const [activeViewMode, setActiveViewMode] = useState<'paginated' | 'embedded'>('paginated');

  // Determine file type and format
  const isPdf = 
    payload.fileFormat === 'pdf' || 
    payload.fileType?.includes('pdf') || 
    payload.fileName?.toLowerCase().endsWith('.pdf');

  const isWord = 
    taskType === 'word_doc' || 
    payload.fileFormat === 'word' || 
    payload.fileName?.toLowerCase().endsWith('.docx') || 
    payload.fileName?.toLowerCase().endsWith('.doc');

  const isPpt = 
    taskType === 'ppt' || 
    payload.fileFormat === 'ppt' || 
    payload.fileName?.toLowerCase().endsWith('.pptx') || 
    payload.fileName?.toLowerCase().endsWith('.ppt') || 
    payload.fileName?.toLowerCase().endsWith('.odp');

  const isOdf = 
    payload.fileFormat === 'odf' || 
    payload.fileName?.toLowerCase().endsWith('.odt') || 
    payload.fileName?.toLowerCase().endsWith('.ods');

  // If a real PDF data URL is uploaded, check if we need to dynamically extract all pages
  // (e.g. if the submission has 0 or only 2 pages from an older version)
  useEffect(() => {
    let isCancelled = false;

    if (isPdf && payload.fileUrl && payload.fileUrl.startsWith('data:application/pdf')) {
      const existingPagesCount = payload.documentPages?.length || 0;
      
      // If we don't have pages, or if existing pages don't have rendered images/full pages
      if (existingPagesCount <= 2) {
        setIsExtractingPdf(true);
        parsePdfPages(payload.fileUrl, payload.fileName || taskTitle)
          .then(pages => {
            if (!isCancelled && pages && pages.length > 0) {
              setDynamicPages(pages);
            }
          })
          .catch(err => {
            console.warn('Dynamic PDF extraction failed:', err);
          })
          .finally(() => {
            if (!isCancelled) setIsExtractingPdf(false);
          });
      }
    }

    return () => {
      isCancelled = true;
    };
  }, [isPdf, payload.fileUrl, payload.fileName, payload.documentPages, taskTitle]);

  // Combine pages: prefer dynamicPages if it found more pages, otherwise payload.documentPages
  const activePages = (dynamicPages && dynamicPages.length > (payload.documentPages?.length || 0))
    ? dynamicPages
    : (payload.documentPages || []);

  const totalPages = activePages.length;

  const scrollToPage = (pageIdx: number) => {
    const el = document.getElementById(`pdf-page-${pageIdx}`);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const handleDownload = () => {
    if (payload.fileUrl) {
      const a = document.createElement('a');
      a.href = payload.fileUrl;
      a.download = payload.fileName || 'submission.pdf';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    }
  };

  return (
    <div className="w-full flex flex-col items-center bg-slate-200/70 p-4 sm:p-6 rounded-xl border border-slate-300 min-h-[500px]">
      {/* Document Ribbon / Info Header */}
      <div className="w-full max-w-4xl bg-white border border-slate-300 rounded-t-xl px-4 py-2.5 flex flex-wrap items-center justify-between text-xs text-slate-700 shadow-xs mb-3 gap-2">
        <div className="flex items-center gap-2">
          {isPdf ? (
            <span className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-rose-100 text-rose-800 font-bold uppercase tracking-wider text-[10px]">
              <FileText className="w-3.5 h-3.5 text-rose-600" />
              PDF Document
            </span>
          ) : isWord ? (
            <span className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-blue-100 text-blue-800 font-bold uppercase tracking-wider text-[10px]">
              <FileText className="w-3.5 h-3.5 text-blue-600" />
              Microsoft Word Document
            </span>
          ) : isPpt ? (
            <span className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-amber-100 text-amber-800 font-bold uppercase tracking-wider text-[10px]">
              <Presentation className="w-3.5 h-3.5 text-amber-600" />
              PowerPoint / ODF Deck
            </span>
          ) : isOdf ? (
            <span className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 font-bold uppercase tracking-wider text-[10px]">
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
              OpenDocument (ODF)
            </span>
          ) : taskType === 'carnatic_music' ? (
            <span className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-amber-100 text-amber-900 font-bold uppercase tracking-wider text-[10px]">
              <Music className="w-3.5 h-3.5 text-amber-700" />
              Carnatic Classical Music
            </span>
          ) : taskType === 'typing_exam' ? (
            <span className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-indigo-100 text-indigo-900 font-bold uppercase tracking-wider text-[10px]">
              <Keyboard className="w-3.5 h-3.5 text-indigo-700" />
              Typing Examination
            </span>
          ) : taskType === 'coding' ? (
            <span className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 font-bold uppercase tracking-wider text-[10px]">
              <Code2 className="w-3.5 h-3.5 text-emerald-600" />
              Source Code & Execution
            </span>
          ) : (
            <span className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-slate-100 text-slate-800 font-bold uppercase tracking-wider text-[10px]">
              <BookOpen className="w-3.5 h-3.5" />
              Student Submission
            </span>
          )}

          <span className="font-semibold text-slate-800 truncate max-w-xs">
            {payload.fileName || payload.docTitle || taskTitle}
          </span>

          {isPdf && totalPages > 0 && (
            <span className="bg-slate-100 text-slate-700 font-semibold px-2 py-0.5 rounded text-[11px] border border-slate-200">
              {totalPages} Pages Available
            </span>
          )}
        </div>

        <div className="flex items-center gap-3 text-slate-500 text-[11px]">
          <span>Author: <strong className="text-slate-800">{studentName}</strong></span>
          {payload.fileSize && <span>Size: {payload.fileSize}</span>}
          {isAnnotating && (
            <span className="bg-red-50 text-red-600 font-bold px-2 py-0.5 rounded border border-red-200 animate-pulse">
              ✏️ In-App Annotation Active
            </span>
          )}

          {payload.fileUrl && (
            <button
              type="button"
              onClick={handleDownload}
              className="flex items-center gap-1 px-2 py-1 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium transition cursor-pointer"
              title="Download original file"
            >
              <Download className="w-3 h-3" />
              <span>Download</span>
            </button>
          )}
        </div>
      </div>

      {/* MULTI-PAGE STICKY NAVIGATION BAR (WHEN 2+ PAGES) */}
      {isPdf && totalPages > 1 && (
        <div className="sticky top-2 z-20 w-full max-w-4xl bg-white/95 backdrop-blur-xs border border-indigo-200 rounded-lg p-2.5 shadow-md mb-4 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-indigo-900 flex items-center gap-1">
              <Layers className="w-3.5 h-3.5 text-indigo-600" />
              <span>All {totalPages} Pages Preserved:</span>
            </span>
            <div className="flex items-center flex-wrap gap-1">
              {activePages.map((_, pIdx) => (
                <button
                  key={pIdx}
                  type="button"
                  onClick={() => scrollToPage(pIdx)}
                  className="px-2 py-0.5 rounded bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold text-xs border border-indigo-200 cursor-pointer transition hover:scale-105"
                  title={`Jump to Page ${pIdx + 1}`}
                >
                  {pIdx + 1}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-2">
            {isExtractingPdf && (
              <span className="flex items-center gap-1 text-[11px] text-amber-700 bg-amber-50 px-2 py-0.5 rounded border border-amber-200 animate-pulse">
                <Loader2 className="w-3 h-3 animate-spin" />
                <span>Rendering High-Res Pages...</span>
              </span>
            )}
            
            {payload.fileUrl?.startsWith('data:application/pdf') && (
              <div className="flex rounded border border-slate-200 bg-slate-100 p-0.5 text-[11px]">
                <button
                  type="button"
                  onClick={() => setActiveViewMode('paginated')}
                  className={`px-2 py-0.5 rounded font-medium cursor-pointer transition ${
                    activeViewMode === 'paginated' ? 'bg-white shadow-2xs text-indigo-700 font-bold' : 'text-slate-600'
                  }`}
                >
                  All {totalPages} Pages
                </button>
                <button
                  type="button"
                  onClick={() => setActiveViewMode('embedded')}
                  className={`px-2 py-0.5 rounded font-medium cursor-pointer transition ${
                    activeViewMode === 'embedded' ? 'bg-white shadow-2xs text-indigo-700 font-bold' : 'text-slate-600'
                  }`}
                >
                  PDF Embed
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* 1. PDF DOCUMENT PAGES */}
      {isPdf && (
        <div className="w-full max-w-4xl space-y-6">
          {activeViewMode === 'embedded' && payload.fileUrl?.startsWith('data:application/pdf') ? (
            <div className="bg-white rounded-lg shadow-md border border-slate-300 p-4 w-full">
              <iframe
                src={payload.fileUrl}
                title="Full PDF Document"
                className="w-full h-[780px] rounded border border-slate-200"
              />
            </div>
          ) : (
            /* Paginated View displaying EVERY SINGLE PAGE */
            activePages.length > 0 ? (
              activePages.map((page, idx) => (
                <div 
                  key={idx}
                  id={`pdf-page-${idx}`}
                  className="bg-white rounded-lg shadow-md border border-slate-300 p-6 sm:p-10 w-full text-slate-800 font-serif leading-relaxed relative min-h-[640px] flex flex-col justify-between scroll-mt-20"
                >
                  {/* PDF Page Header */}
                  <div>
                    <div className="flex items-center justify-between pb-3 mb-6 border-b border-slate-200 text-[11px] font-sans text-slate-400 uppercase tracking-widest">
                      <span className="font-semibold text-slate-600">{taskTitle}</span>
                      <span className="bg-slate-100 text-slate-700 px-2 py-0.5 rounded font-bold">
                        Document Page {page.pageNumber || idx + 1} of {totalPages}
                      </span>
                    </div>

                    {/* If rendered image snapshot from PDF.js exists, render with maximum fidelity */}
                    {page.dataUrl ? (
                      <div className="space-y-4 mb-4 font-sans">
                        <div className="w-full overflow-hidden rounded-md border border-slate-300 shadow-xs bg-slate-50 flex justify-center">
                          <img 
                            src={page.dataUrl} 
                            alt={`PDF Page ${page.pageNumber || idx + 1}`} 
                            className="w-full max-w-3xl h-auto object-contain block select-none pointer-events-none"
                            loading="lazy"
                          />
                        </div>
                        {page.content && !page.content.startsWith('(') && (
                          <details className="mt-3 text-xs font-serif text-slate-600 bg-slate-50 p-2.5 rounded border border-slate-200">
                            <summary className="font-sans font-semibold text-slate-700 cursor-pointer">
                              View Extracted Text Transcript (Page {idx + 1})
                            </summary>
                            <p className="mt-2 whitespace-pre-wrap leading-relaxed">
                              {page.content}
                            </p>
                          </details>
                        )}
                      </div>
                    ) : (
                      /* Formatted Typography Representation */
                      <div>
                        {page.title && (
                          <h2 className="font-sans font-black text-xl text-slate-900 mb-2">
                            {page.title}
                          </h2>
                        )}

                        {page.subtitle && (
                          <h4 className="font-sans font-semibold text-xs text-indigo-700 uppercase tracking-wider mb-4">
                            {page.subtitle}
                          </h4>
                        )}

                        <div className="text-sm whitespace-pre-wrap leading-relaxed text-slate-800 font-serif">
                          {page.content}
                        </div>
                      </div>
                    )}
                  </div>

                  {/* PDF Page Footer */}
                  <div className="pt-4 mt-8 border-t border-slate-200 flex items-center justify-between text-[11px] font-sans text-slate-400">
                    <span>Student: <strong className="text-slate-700">{studentName}</strong></span>
                    <span className="font-semibold text-slate-600">Page {idx + 1} of {totalPages}</span>
                  </div>
                </div>
              ))
            ) : (
              /* Fallback single card if no pages loaded */
              <div className="bg-white rounded-lg shadow-md border border-slate-300 p-8 sm:p-12 w-full text-slate-800 font-serif leading-relaxed relative min-h-[680px] flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between pb-3 mb-6 border-b border-slate-200 text-[11px] font-sans text-slate-400 uppercase tracking-widest">
                    <span>{taskTitle}</span>
                    <span>PDF Document Viewer · Page 1 of 1</span>
                  </div>

                  <div className="space-y-4">
                    <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg font-sans mb-4">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-slate-900 text-sm">{payload.fileName || 'Uploaded_Assignment.pdf'}</span>
                        <span className="text-xs text-emerald-700 font-semibold bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                          ✓ Loaded in Viewer
                        </span>
                      </div>
                      {payload.textResponse && (
                        <p className="text-xs text-slate-600 mt-2 italic">
                          Student Note: "{payload.textResponse}"
                        </p>
                      )}
                    </div>

                    {payload.fileUrl?.startsWith('data:application/pdf') ? (
                      <div className="rounded-lg overflow-hidden border border-slate-300 w-full min-h-[500px]">
                        <iframe 
                          src={payload.fileUrl} 
                          title="PDF Viewer" 
                          className="w-full h-[520px] border-0"
                        />
                      </div>
                    ) : (
                      <div className="space-y-3 font-serif text-sm text-slate-800">
                        <h3 className="font-sans font-bold text-lg text-slate-900">
                          {payload.docTitle || taskTitle}
                        </h3>
                        <p>
                          {payload.textResponse || 
                            'This PDF document was uploaded by the student for this assignment. Teachers can directly annotate on this paper using the red pen, green pen, highlighter, or stamps above.'}
                        </p>
                      </div>
                    )}
                  </div>
                </div>

                <div className="pt-4 mt-8 border-t border-slate-200 flex items-center justify-between text-[11px] font-sans text-slate-400">
                  <span>Submitted by: {studentName}</span>
                  <span>EduTask Studio Verified PDF</span>
                </div>
              </div>
            )
          )}
        </div>
      )}

      {/* 2. WORD DOCUMENT / ODF TEXT DOCUMENT */}
      {isWord && !isPdf && (
        <div className="w-full max-w-4xl space-y-6">
          {(payload.documentPages && payload.documentPages.length > 0) ? (
            payload.documentPages.map((page, idx) => (
              <div 
                key={idx}
                className="bg-white rounded-lg shadow-md border border-slate-300 p-8 sm:p-12 text-slate-800 font-serif leading-relaxed relative min-h-[640px] flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between pb-3 mb-6 border-b border-slate-200 text-[11px] font-sans text-slate-400 uppercase tracking-widest">
                    <span>{taskTitle}</span>
                    <span>Microsoft Word / ODT Format · Page {idx + 1} of {payload.documentPages?.length}</span>
                  </div>

                  <h1 className="font-sans font-bold text-2xl text-slate-900 mb-3 tracking-tight">
                    {page.title || payload.docTitle || payload.fileName || taskTitle}
                  </h1>

                  <div className="text-xs font-sans text-slate-500 mb-6 flex items-center gap-3">
                    <span>By {studentName}</span>
                    <span>•</span>
                    <span>Submitted {new Date(submission.submittedAt).toLocaleDateString()}</span>
                  </div>

                  <div className="font-serif text-sm leading-relaxed text-slate-800 whitespace-pre-wrap space-y-4">
                    {page.content}
                  </div>
                </div>

                <div className="pt-4 mt-8 border-t border-slate-200 flex items-center justify-between text-[11px] font-sans text-slate-400">
                  <span>Page {idx + 1} of {payload.documentPages?.length}</span>
                  <span>Verified Word Document</span>
                </div>
              </div>
            ))
          ) : (
            <div className="bg-white rounded-lg shadow-md border border-slate-300 p-8 sm:p-12 text-slate-800 font-serif leading-relaxed relative min-h-[640px] flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between pb-3 mb-6 border-b border-slate-200 text-[11px] font-sans text-slate-400 uppercase tracking-widest">
                  <span>{taskTitle}</span>
                  <span>Microsoft Word / ODT Format · A4 Page</span>
                </div>

                <h1 className="font-sans font-bold text-2xl text-slate-900 mb-3 tracking-tight">
                  {payload.docTitle || payload.fileName || taskTitle}
                </h1>

                <div className="text-xs font-sans text-slate-500 mb-6 flex items-center gap-3">
                  <span>By {studentName}</span>
                  <span>•</span>
                  <span>Submitted {new Date(submission.submittedAt).toLocaleDateString()}</span>
                </div>

                <div className="font-serif text-sm leading-relaxed text-slate-800 whitespace-pre-wrap space-y-4">
                  {payload.docContent || payload.textResponse || (
                    <div className="italic text-slate-400">No text content in document.</div>
                  )}
                </div>
              </div>

              <div className="pt-4 mt-8 border-t border-slate-200 flex items-center justify-between text-[11px] font-sans text-slate-400">
                <span>Page 1 of 1 · {(payload.docContent || '').split(/\s+/).length} words</span>
                <span>Verified Word Document</span>
              </div>
            </div>
          )}
        </div>
      )}

      {/* 3. POWERPOINT / ODF PRESENTATION (PPT / ODP) */}
      {isPpt && (
        <div className="w-full max-w-4xl space-y-6">
          {(payload.slides && payload.slides.length > 0) ? (
            payload.slides.map((slide, idx) => (
              <div 
                key={idx}
                className="aspect-video w-full rounded-2xl bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 text-white p-8 sm:p-10 shadow-lg border border-slate-800 flex flex-col justify-between relative overflow-hidden"
              >
                <div>
                  <div className="flex items-center justify-between text-xs font-bold text-indigo-400 uppercase tracking-widest mb-3">
                    <span>PowerPoint Slide {idx + 1} of {payload.slides?.length}</span>
                    <span className="text-[10px] bg-indigo-500/20 px-2 py-0.5 rounded text-indigo-300">
                      {studentName}
                    </span>
                  </div>

                  <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight mt-1">
                    {slide.title}
                  </h2>

                  <ul className="mt-6 space-y-3 text-sm sm:text-base text-indigo-100 list-disc list-inside leading-relaxed">
                    {slide.bullets.map((b, bi) => (
                      <li key={bi} className="font-sans">{b}</li>
                    ))}
                  </ul>
                </div>

                {slide.notes && (
                  <div className="border-t border-indigo-900/60 pt-3 mt-4 text-xs text-indigo-300 italic font-mono flex items-center gap-2">
                    <span className="font-bold uppercase tracking-wider not-italic text-[10px] text-indigo-400">Presenter Notes:</span>
                    <span>{slide.notes}</span>
                  </div>
                )}
              </div>
            ))
          ) : (
            <div className="aspect-video w-full rounded-2xl bg-slate-900 text-white p-8 flex flex-col items-center justify-center text-center">
              <Presentation className="w-12 h-12 text-indigo-400 mb-3" />
              <h3 className="text-lg font-bold">Presentation Deck</h3>
              <p className="text-xs text-slate-400 mt-1 max-w-md">{payload.fileName || 'Uploaded presentation'}</p>
            </div>
          )}
        </div>
      )}

      {/* 4. EXCEL SPREADSHEET */}
      {(taskType === 'excel' || payload.fileFormat === 'odf' && payload.fileName?.endsWith('.ods')) && (
        <div className="w-full max-w-4xl bg-white rounded-lg shadow-md border border-slate-300 p-6 sm:p-8">
          <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-200">
            <div className="flex items-center gap-2">
              <Table className="w-5 h-5 text-emerald-600" />
              <span className="font-bold text-slate-800 text-base">Workbook Sheet View</span>
            </div>
            <span className="text-xs text-slate-500 font-mono">Formula Enabled</span>
          </div>

          {payload.sheetData ? (
            <div className="overflow-x-auto rounded-lg border border-slate-300">
              <table className="w-full border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-100">
                    <th className="w-10 border border-slate-300 p-2 text-center text-slate-500">#</th>
                    {['A', 'B', 'C', 'D', 'E', 'F'].map(col => (
                      <th key={col} className="border border-slate-300 p-2 text-center font-bold text-slate-700 min-w-[90px]">
                        {col}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {[1, 2, 3, 4, 5, 6, 7, 8].map(row => (
                    <tr key={row}>
                      <td className="border border-slate-300 bg-slate-50 p-2 text-center font-mono text-slate-500">
                        {row}
                      </td>
                      {['A', 'B', 'C', 'D', 'E', 'F'].map(col => {
                        const cellKey = `${col}${row}`;
                        const val = payload.sheetData?.[cellKey] || '';
                        return (
                          <td key={cellKey} className="border border-slate-300 p-2 text-slate-800 font-mono bg-white">
                            {val}
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="text-center py-8 text-slate-400 italic">No spreadsheet data found.</div>
          )}
        </div>
      )}

      {/* 5. SOURCE CODE & COMPILATION TERMINAL */}
      {taskType === 'coding' && (
        <div className="w-full max-w-4xl space-y-4">
          <div className="rounded-2xl border border-slate-800 bg-[#1e1e2e] p-6 shadow-xl text-slate-100 font-mono text-xs">
            <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-700/80 text-slate-400">
              <span className="flex items-center gap-2">
                <Code2 className="w-4 h-4 text-purple-400" />
                <span className="font-bold text-sky-400 uppercase tracking-wider">
                  {payload.codeLanguage || 'python'} Source Solution
                </span>
              </span>
              <span className="text-slate-300 font-sans font-semibold">Submitted by {studentName}</span>
            </div>
            <pre className="overflow-x-auto p-3 leading-relaxed text-[#cdd6f4] bg-[#181825] rounded-xl border border-slate-800 selection:bg-indigo-500/30">
              {payload.code || '// No code submitted'}
            </pre>
          </div>

          {/* HTML Live Preview if HTML */}
          {payload.codeLanguage === 'html' && (payload.htmlPreview || payload.code) && (
            <div className="rounded-2xl border border-slate-300 bg-white p-5 shadow-lg space-y-3">
              <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                <span className="font-bold text-slate-900 text-xs flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
                  Rendered HTML/CSS Web Output:
                </span>
                <span className="text-[10px] text-slate-500 font-mono">Live Sandbox</span>
              </div>
              <div className="rounded-xl overflow-hidden border border-slate-200 min-h-[280px]">
                <iframe
                  srcDoc={payload.htmlPreview || payload.code}
                  title="Student Webpage"
                  sandbox="allow-scripts"
                  className="w-full min-h-[300px] border-0"
                />
              </div>
            </div>
          )}

          {/* Matplotlib Visual Graphic */}
          {payload.matplotlibPlotUrl && (
            <div className="rounded-2xl border border-slate-800 bg-[#0f172a] p-5 shadow-xl space-y-3">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <span className="font-bold text-white text-xs flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-purple-500"></span>
                  Matplotlib Graphical Plot Output (Figure 1):
                </span>
                <span className="text-[10px] text-purple-300 bg-purple-950 px-2 py-0.5 rounded border border-purple-800">
                  Data Science Artifact
                </span>
              </div>
              <div className="rounded-xl overflow-hidden border border-slate-800 p-2 bg-slate-950 flex items-center justify-center">
                <img
                  src={payload.matplotlibPlotUrl}
                  alt="Matplotlib Plot"
                  className="w-full max-h-[340px] object-contain rounded-lg"
                />
              </div>
            </div>
          )}

          {/* Pandas DataFrame Table */}
          {payload.pandasTableHtml && (
            <div className="rounded-2xl border border-slate-800 bg-[#111827] p-5 shadow-xl space-y-2">
              <span className="font-bold text-sky-400 text-xs block mb-1">
                Pandas DataFrame Structured Summary:
              </span>
              <div dangerouslySetInnerHTML={{ __html: payload.pandasTableHtml }} />
            </div>
          )}

          {/* Verified Stdout */}
          {payload.codeStdout && (
            <div className="rounded-2xl border border-slate-700 bg-slate-900 p-5 font-mono text-xs shadow-md">
              <div className="flex items-center gap-2 text-indigo-300 font-bold mb-2">
                <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                <span>Verified Execution Output (Stdout):</span>
              </div>
              <pre className="text-emerald-400 whitespace-pre-wrap leading-relaxed bg-black/60 p-4 rounded-xl border border-slate-800">
                {payload.codeStdout}
              </pre>
            </div>
          )}

          {payload.stdinProvided && (
            <div className="rounded-xl border border-slate-700 bg-slate-900/60 p-3 font-mono text-xs text-slate-300">
              <span className="text-slate-400 font-bold mr-2">Input args (stdin):</span>
              <span>{payload.stdinProvided}</span>
            </div>
          )}
        </div>
      )}

      {/* 6. DRAWING CANVAS / IMAGE SUBMISSION */}
      {(taskType === 'drawing' || payload.drawingDataUrl || payload.fileFormat === 'image') && (
        <div className="w-full max-w-4xl bg-white rounded-xl shadow-md border border-slate-300 p-6 flex flex-col items-center">
          <div className="w-full flex items-center justify-between pb-3 mb-4 border-b border-slate-200">
            <span className="font-bold text-slate-800 text-sm">Visual Artwork / Diagram Submission</span>
            <span className="text-xs text-slate-500">Student Canvas</span>
          </div>

          <div className="rounded-lg overflow-hidden border border-slate-300 shadow-inner max-w-full bg-slate-50">
            <img 
              src={payload.drawingDataUrl || payload.fileUrl} 
              alt="Student Drawing" 
              className="max-h-[600px] w-auto object-contain"
            />
          </div>
        </div>
      )}

      {/* 7. VIDEO SUBMISSION */}
      {payload.fileFormat === 'video' && payload.fileUrl && (
        <div className="w-full max-w-4xl bg-slate-900 rounded-xl shadow-lg border border-slate-800 p-4">
          <video 
            controls 
            src={payload.fileUrl} 
            className="w-full max-h-[500px] rounded-lg bg-black"
          />
        </div>
      )}

      {/* 8. GENERAL TEXT RESPONSE */}
      {taskType === 'text' && (
        <div className="w-full max-w-4xl bg-white rounded-xl shadow-md border border-slate-300 p-8 sm:p-12 font-serif">
          <div className="pb-3 mb-6 border-b border-slate-200 text-xs font-sans text-slate-400 uppercase tracking-widest flex justify-between">
            <span>Written Response</span>
            <span>By {studentName}</span>
          </div>
          <p className="whitespace-pre-wrap leading-relaxed text-slate-800 text-base">
            {payload.textResponse}
          </p>
        </div>
      )}

      {/* 9. CARNATIC MUSIC SUBMISSION SHEET */}
      {(taskType === 'carnatic_music' || payload.carnaticSwaraNotation || payload.carnaticAudioUrl) && (
        <div className="w-full max-w-4xl bg-gradient-to-br from-amber-50/90 via-orange-50/50 to-amber-50/90 rounded-2xl shadow-xl border-2 border-amber-300 p-8 sm:p-12 space-y-6">
          {/* Header */}
          <div className="flex flex-wrap items-center justify-between pb-4 border-b border-amber-300 gap-3">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-lg bg-amber-600 text-white flex items-center justify-center font-bold shadow-xs">
                <Music className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-amber-900 bg-amber-200/80 px-2 py-0.5 rounded">
                  Carnatic Classical Music Submission
                </span>
                <h3 className="text-base font-bold text-amber-950 mt-0.5">{taskTitle}</h3>
              </div>
            </div>

            <div className="flex flex-wrap gap-1.5 text-xs">
              {payload.carnaticRaga && (
                <span className="bg-white border border-amber-300 text-amber-900 px-2.5 py-1 rounded-md font-bold shadow-2xs">
                  Raga: {payload.carnaticRaga}
                </span>
              )}
              {payload.carnaticTala && (
                <span className="bg-white border border-amber-300 text-amber-900 px-2.5 py-1 rounded-md font-bold shadow-2xs">
                  Tala: {payload.carnaticTala}
                </span>
              )}
              {payload.carnaticShruti && (
                <span className="bg-white border border-amber-300 text-amber-900 px-2.5 py-1 rounded-md font-bold shadow-2xs">
                  Shruti: {payload.carnaticShruti}
                </span>
              )}
            </div>
          </div>

          {/* Student Tools Telemetry */}
          {payload.carnaticToolsUsed && payload.carnaticToolsUsed.length > 0 && (
            <div className="bg-amber-100/70 p-3 rounded-xl border border-amber-300 text-xs flex flex-wrap items-center gap-2">
              <span className="font-bold text-amber-950 flex items-center gap-1">
                <Music className="w-3.5 h-3.5 text-amber-700" />
                Tools Engaged by Student:
              </span>
              {payload.carnaticToolsUsed.map((tool, idx) => (
                <span key={idx} className="bg-white border border-amber-300 text-amber-900 font-semibold px-2 py-0.5 rounded-full text-[11px] shadow-2xs">
                  ✓ {tool}
                </span>
              ))}
            </div>
          )}

          {/* Audio Playback Player */}
          {payload.carnaticAudioUrl && (
            <div className="bg-white p-4 rounded-xl border border-amber-300 shadow-sm flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center gap-2 text-amber-900 font-bold text-xs">
                <Mic className="w-4 h-4 text-rose-600" />
                <span>Recorded Vocal / Instrumental Rendition:</span>
              </div>
              <audio controls src={payload.carnaticAudioUrl} className="h-9 w-full sm:w-auto" />
            </div>
          )}

          {/* Swara Notation Script */}
          {payload.carnaticSwaraNotation && (
            <div className="space-y-2">
              <span className="text-xs font-bold uppercase tracking-wider text-amber-950 block">
                Transcribed Swara Notation (Kala & Akshara Spaced):
              </span>
              <pre className="w-full bg-white p-5 rounded-xl border border-amber-200 font-mono text-xs text-amber-950 leading-relaxed shadow-inner whitespace-pre-wrap">
                {payload.carnaticSwaraNotation}
              </pre>
            </div>
          )}

          {/* Theoretical commentary */}
          {payload.textResponse && (
            <div className="space-y-2">
              <span className="text-xs font-bold uppercase tracking-wider text-amber-950 block">
                Student Theoretical Commentary & Viva Answers:
              </span>
              <div className="bg-white/80 p-4 rounded-xl border border-amber-200 text-xs text-amber-950 leading-relaxed font-serif whitespace-pre-wrap">
                {payload.textResponse}
              </div>
            </div>
          )}

          <div className="pt-4 border-t border-amber-200 flex items-center justify-between text-[11px] text-amber-800 font-sans">
            <span>Student: <strong className="text-amber-950">{studentName}</strong></span>
            <span>Verified Carnatic Sangeeth Assessment</span>
          </div>
        </div>
      )}

      {/* 10. TYPING EXAMINATION SUBMISSION SHEET */}
      {(taskType === 'typing_exam' || payload.typingSpeedWpm !== undefined) && (
        <div className="w-full max-w-4xl bg-white rounded-2xl shadow-xl border border-slate-300 p-8 sm:p-12 space-y-6">
          <div className="flex flex-wrap items-center justify-between pb-4 border-b border-slate-200 gap-3">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-lg bg-indigo-600 text-white flex items-center justify-center font-bold">
                <Keyboard className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded">
                  Examination Result Sheet
                </span>
                <h3 className="text-base font-bold text-slate-900 mt-0.5">{taskTitle}</h3>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="bg-emerald-50 border border-emerald-200 px-3 py-1.5 rounded-lg text-emerald-800 text-xs font-bold">
                Speed: {payload.typingSpeedWpm ?? 0} WPM
              </div>
              <div className="bg-blue-50 border border-blue-200 px-3 py-1.5 rounded-lg text-blue-800 text-xs font-bold">
                Accuracy: {payload.typingAccuracyPercentage ?? 100}%
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-700 block">
              Student Typed Transcript:
            </span>
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 font-mono text-xs text-slate-900 leading-relaxed whitespace-pre-wrap">
              {payload.typingCompletedText || payload.textResponse || '(Empty typing transcript)'}
            </div>
          </div>

          <div className="pt-4 border-t border-slate-200 flex items-center justify-between text-[11px] text-slate-400 font-sans">
            <span>Student: <strong className="text-slate-700">{studentName}</strong></span>
            <span>Recorded Under Controlled Examination Timer</span>
          </div>
        </div>
      )}
    </div>
  );
};
