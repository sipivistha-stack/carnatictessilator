import React, { useRef, useEffect, useState, useCallback } from 'react';
import { PenStroke, StampAnnotation } from '../../types';
import { 
  Pen, 
  Highlighter, 
  Eraser, 
  RotateCcw, 
  Trash2, 
  Check, 
  X, 
  Star, 
  HelpCircle,
  MousePointer,
  Sparkles
} from 'lucide-react';

interface CorrectionCanvasProps {
  penStrokes: PenStroke[];
  onChangePenStrokes: (strokes: PenStroke[]) => void;
  stamps?: StampAnnotation[];
  onChangeStamps?: (stamps: StampAnnotation[]) => void;
  children?: React.ReactNode;
  containerHeight?: number;
}

const PALETTE = [
  { name: 'Teacher Red', hex: '#ef4444' },
  { name: 'Emerald Green', hex: '#10b981' },
  { name: 'Royal Blue', hex: '#2563eb' },
  { name: 'Amber Gold', hex: '#f59e0b' },
  { name: 'Purple', hex: '#8b5cf6' },
];

const STROKE_WIDTHS = [
  { label: 'Fine', value: 2 },
  { label: 'Medium', value: 4 },
  { label: 'Thick', value: 8 },
];

export const CorrectionCanvas: React.FC<CorrectionCanvasProps> = ({
  penStrokes,
  onChangePenStrokes,
  stamps = [],
  onChangeStamps,
  children,
  containerHeight,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  const [activeTool, setActiveTool] = useState<'cursor' | 'pen' | 'highlighter' | 'eraser' | 'stamp'>('pen');
  const [currentColor, setCurrentColor] = useState<string>('#ef4444'); // Default teacher red
  const [currentWidth, setCurrentWidth] = useState<number>(3);
  const [selectedStamp, setSelectedStamp] = useState<'check' | 'cross' | 'star' | 'question' | 'hundred'>('check');
  const [isDrawing, setIsDrawing] = useState<boolean>(false);
  const [currentPoints, setCurrentPoints] = useState<{ x: number; y: number }[]>([]);

  // Redraw canvas whenever strokes change
  const redrawCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw saved strokes
    penStrokes.forEach(stroke => {
      if (stroke.points.length < 2) return;
      ctx.beginPath();
      ctx.strokeStyle = stroke.color;
      ctx.lineWidth = stroke.width;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';

      if (stroke.type === 'highlighter') {
        ctx.globalAlpha = 0.38;
      } else {
        ctx.globalAlpha = 1.0;
      }

      ctx.moveTo(stroke.points[0].x, stroke.points[0].y);
      for (let i = 1; i < stroke.points.length; i++) {
        ctx.lineTo(stroke.points[i].x, stroke.points[i].y);
      }
      ctx.stroke();
    });

    // Draw active drawing stroke in progress
    if (currentPoints.length > 1) {
      ctx.beginPath();
      ctx.strokeStyle = activeTool === 'eraser' ? '#ffffff' : currentColor;
      ctx.lineWidth = activeTool === 'highlighter' ? 18 : activeTool === 'eraser' ? 24 : currentWidth;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.globalAlpha = activeTool === 'highlighter' ? 0.38 : 1.0;

      ctx.moveTo(currentPoints[0].x, currentPoints[0].y);
      for (let i = 1; i < currentPoints.length; i++) {
        ctx.lineTo(currentPoints[i].x, currentPoints[i].y);
      }
      ctx.stroke();
    }

    // Reset alpha
    ctx.globalAlpha = 1.0;
  }, [penStrokes, currentPoints, currentColor, currentWidth, activeTool]);

  // Sync canvas dimensions with the actual scroll height/width of container
  useEffect(() => {
    const updateDimensions = () => {
      const canvas = canvasRef.current;
      const container = containerRef.current;
      if (canvas && container) {
        const w = container.clientWidth || container.scrollWidth;
        const h = container.clientHeight || container.scrollHeight;
        if (w > 0 && h > 0 && (canvas.width !== w || canvas.height !== h)) {
          canvas.width = w;
          canvas.height = h;
          redrawCanvas();
        }
      }
    };

    updateDimensions();

    const resizeObserver = new ResizeObserver(() => {
      updateDimensions();
    });

    if (containerRef.current) {
      resizeObserver.observe(containerRef.current);
    }

    window.addEventListener('resize', updateDimensions);
    return () => {
      resizeObserver.disconnect();
      window.removeEventListener('resize', updateDimensions);
    };
  }, [redrawCanvas]);

  useEffect(() => {
    redrawCanvas();
  }, [redrawCanvas]);

  const getCanvasCoords = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    return {
      x: e.clientX - rect.left,
      y: e.clientY - rect.top,
    };
  };

  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (activeTool === 'cursor') return;
    const coords = getCanvasCoords(e);

    if (activeTool === 'stamp') {
      if (onChangeStamps) {
        const newStamp: StampAnnotation = {
          id: 'stamp-' + Date.now(),
          x: coords.x,
          y: coords.y,
          color: currentColor,
          iconType: selectedStamp,
          text: selectedStamp === 'check' ? '✓' : selectedStamp === 'cross' ? '✗' : selectedStamp === 'star' ? '★' : selectedStamp === 'hundred' ? '100' : '?',
        };
        onChangeStamps([...stamps, newStamp]);
      }
      return;
    }

    setIsDrawing(true);
    setCurrentPoints([coords]);
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing || activeTool === 'cursor') return;
    const coords = getCanvasCoords(e);
    setCurrentPoints(prev => [...prev, coords]);
  };

  const handleMouseUp = () => {
    if (!isDrawing) return;
    setIsDrawing(false);

    if (currentPoints.length > 1) {
      if (activeTool === 'eraser') {
        const threshold = 22;
        const remaining = penStrokes.filter(stroke => {
          return !stroke.points.some(pt => 
            currentPoints.some(ept => Math.hypot(pt.x - ept.x, pt.y - ept.y) < threshold)
          );
        });
        onChangePenStrokes(remaining);
      } else {
        const newStroke: PenStroke = {
          id: 'stroke-' + Date.now(),
          color: currentColor,
          width: activeTool === 'highlighter' ? 18 : currentWidth,
          points: currentPoints,
          type: activeTool === 'highlighter' ? 'highlighter' : 'pen',
        };
        onChangePenStrokes([...penStrokes, newStroke]);
      }
    }
    setCurrentPoints([]);
  };

  const handleUndo = () => {
    if (penStrokes.length > 0) {
      onChangePenStrokes(penStrokes.slice(0, -1));
    }
  };

  const handleClear = () => {
    onChangePenStrokes([]);
    if (onChangeStamps) onChangeStamps([]);
  };

  return (
    <div className="flex flex-col rounded-xl border border-slate-300 bg-white shadow-md overflow-hidden">
      {/* Sticky Teacher Pen Correction Toolbar */}
      <div className="sticky top-0 z-30 flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 bg-slate-50/95 backdrop-blur-xs px-4 py-2.5 shadow-2xs">
        <div className="flex items-center gap-2">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-700 mr-1 flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-pulse"></span>
            Direct Annotation Tools:
          </span>

          {/* Tool Modes */}
          <div className="flex items-center rounded-lg border border-slate-200 bg-white p-0.5 shadow-2xs">
            <button
              type="button"
              onClick={() => setActiveTool('cursor')}
              className={`flex items-center gap-1 rounded-md px-2 py-1 text-xs font-medium transition cursor-pointer ${
                activeTool === 'cursor' ? 'bg-slate-200 text-slate-900 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
              }`}
              title="Browse / Select mode (interact with document without drawing)"
            >
              <MousePointer className="w-3.5 h-3.5" />
              <span>Scroll</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTool('pen')}
              className={`flex items-center gap-1.5 rounded-md px-2.5 py-1 text-xs font-medium transition cursor-pointer ${
                activeTool === 'pen' ? 'bg-red-50 text-red-700 shadow-2xs ring-1 ring-red-200' : 'text-slate-600 hover:text-slate-900'
              }`}
              title="Draw markings with colored pen"
            >
              <Pen className="w-3.5 h-3.5" />
              <span>Pen</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTool('highlighter')}
              className={`flex items-center gap-1.5 rounded-md px-2.5 py-1 text-xs font-medium transition cursor-pointer ${
                activeTool === 'highlighter' ? 'bg-amber-50 text-amber-700 shadow-2xs ring-1 ring-amber-200' : 'text-slate-600 hover:text-slate-900'
              }`}
              title="Highlight text or formulas"
            >
              <Highlighter className="w-3.5 h-3.5" />
              <span>Highlighter</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTool('eraser')}
              className={`flex items-center gap-1.5 rounded-md px-2 py-1 text-xs font-medium transition cursor-pointer ${
                activeTool === 'eraser' ? 'bg-slate-200 text-slate-800 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
              }`}
              title="Erase strokes"
            >
              <Eraser className="w-3.5 h-3.5" />
              <span>Eraser</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTool('stamp')}
              className={`flex items-center gap-1.5 rounded-md px-2.5 py-1 text-xs font-medium transition cursor-pointer ${
                activeTool === 'stamp' ? 'bg-indigo-50 text-indigo-700 shadow-2xs ring-1 ring-indigo-200' : 'text-slate-600 hover:text-slate-900'
              }`}
              title="Place quick stamps on document"
            >
              <Check className="w-3.5 h-3.5" />
              <span>Stamps</span>
            </button>
          </div>
        </div>

        {/* Ink Palette */}
        {activeTool !== 'eraser' && activeTool !== 'cursor' && (
          <div className="flex items-center gap-1.5">
            <span className="text-xs text-slate-500 font-medium mr-1">Ink:</span>
            {PALETTE.map(c => (
              <button
                key={c.hex}
                type="button"
                onClick={() => setCurrentColor(c.hex)}
                className={`w-5 h-5 rounded-full transition-transform flex items-center justify-center cursor-pointer ${
                  currentColor === c.hex ? 'scale-125 ring-2 ring-offset-1 ring-slate-500' : 'hover:scale-110'
                }`}
                style={{ backgroundColor: c.hex }}
                title={c.name}
              >
                {currentColor === c.hex && <div className="w-1.5 h-1.5 rounded-full bg-white"></div>}
              </button>
            ))}
          </div>
        )}

        {/* Thickness */}
        {activeTool === 'pen' && (
          <div className="flex items-center gap-1">
            <span className="text-xs text-slate-500 font-medium mr-1">Size:</span>
            {STROKE_WIDTHS.map(w => (
              <button
                key={w.value}
                type="button"
                onClick={() => setCurrentWidth(w.value)}
                className={`px-2 py-0.5 text-xs rounded border transition cursor-pointer ${
                  currentWidth === w.value 
                    ? 'border-slate-800 bg-slate-900 text-white font-medium' 
                    : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
                }`}
              >
                {w.label}
              </button>
            ))}
          </div>
        )}

        {/* Stamps choices */}
        {activeTool === 'stamp' && (
          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={() => setSelectedStamp('check')}
              className={`p-1.5 rounded border transition cursor-pointer ${selectedStamp === 'check' ? 'bg-emerald-50 border-emerald-500 text-emerald-600' : 'bg-white border-slate-200 text-slate-600'}`}
              title="Checkmark (Correct)"
            >
              <Check className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={() => setSelectedStamp('cross')}
              className={`p-1.5 rounded border transition cursor-pointer ${selectedStamp === 'cross' ? 'bg-red-50 border-red-500 text-red-600' : 'bg-white border-slate-200 text-slate-600'}`}
              title="Cross (Incorrect)"
            >
              <X className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={() => setSelectedStamp('star')}
              className={`p-1.5 rounded border transition cursor-pointer ${selectedStamp === 'star' ? 'bg-amber-50 border-amber-500 text-amber-600' : 'bg-white border-slate-200 text-slate-600'}`}
              title="Star (Great Work)"
            >
              <Star className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={() => setSelectedStamp('hundred')}
              className={`p-1.5 rounded border text-xs font-bold transition cursor-pointer ${selectedStamp === 'hundred' ? 'bg-red-50 border-red-500 text-red-600' : 'bg-white border-slate-200 text-slate-600'}`}
              title="100 Marks"
            >
              100
            </button>
            <button
              type="button"
              onClick={() => setSelectedStamp('question')}
              className={`p-1.5 rounded border transition cursor-pointer ${selectedStamp === 'question' ? 'bg-purple-50 border-purple-500 text-purple-600' : 'bg-white border-slate-200 text-slate-600'}`}
              title="Question mark"
            >
              <HelpCircle className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Undo and Clear */}
        <div className="flex items-center gap-1.5 ml-auto">
          <button
            type="button"
            onClick={handleUndo}
            disabled={penStrokes.length === 0}
            className="flex items-center gap-1 rounded border border-slate-200 bg-white px-2 py-1 text-xs text-slate-600 hover:bg-slate-50 disabled:opacity-40 cursor-pointer"
            title="Undo last stroke"
          >
            <RotateCcw className="w-3 h-3" />
            <span>Undo</span>
          </button>
          <button
            type="button"
            onClick={handleClear}
            disabled={penStrokes.length === 0 && stamps.length === 0}
            className="flex items-center gap-1 rounded border border-slate-200 bg-white px-2 py-1 text-xs text-rose-600 hover:bg-rose-50 disabled:opacity-40 cursor-pointer"
            title="Clear all markings"
          >
            <Trash2 className="w-3 h-3" />
            <span>Clear</span>
          </button>
        </div>
      </div>

      {/* DOCUMENT WRAPPER WITH DIRECT CANVAS OVERLAY */}
      <div 
        ref={containerRef} 
        className="relative w-full bg-slate-200/50 overflow-x-auto min-h-[480px]"
      >
        {/* The Student Content (PDF, Word, PPT, ODF, Code, etc.) is rendered here underneath the transparent canvas */}
        <div className="relative z-10 w-full">
          {children}
        </div>

        {/* Transparent Annotation Canvas sitting directly ON TOP of the document */}
        <canvas
          ref={canvasRef}
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onMouseLeave={handleMouseUp}
          className={`absolute inset-0 z-20 w-full h-full ${
            activeTool === 'cursor' ? 'pointer-events-none' : 'cursor-crosshair pointer-events-auto'
          }`}
        />

        {/* Stamps Overlay directly positioned over document */}
        {stamps.map(stamp => (
          <div
            key={stamp.id}
            className="absolute z-20 pointer-events-none transform -translate-x-1/2 -translate-y-1/2 flex items-center justify-center font-bold"
            style={{ left: stamp.x, top: stamp.y, color: stamp.color }}
          >
            {stamp.iconType === 'check' && (
              <span className="w-8 h-8 rounded-full border-2 border-emerald-500 bg-emerald-50 text-emerald-600 flex items-center justify-center text-lg font-bold shadow-md">
                ✓
              </span>
            )}
            {stamp.iconType === 'cross' && (
              <span className="w-8 h-8 rounded-full border-2 border-red-500 bg-red-50 text-red-600 flex items-center justify-center text-lg font-bold shadow-md">
                ✗
              </span>
            )}
            {stamp.iconType === 'star' && (
              <span className="w-8 h-8 rounded-full border-2 border-amber-500 bg-amber-50 text-amber-500 flex items-center justify-center text-lg font-bold shadow-md">
                ★
              </span>
            )}
            {stamp.iconType === 'hundred' && (
              <span className="px-2 py-0.5 rounded border-2 border-red-600 bg-red-50 text-red-700 text-xs font-black shadow-md">
                💯
              </span>
            )}
            {stamp.iconType === 'question' && (
              <span className="w-8 h-8 rounded-full border-2 border-purple-500 bg-purple-50 text-purple-600 flex items-center justify-center text-base font-bold shadow-md">
                ?
              </span>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};
