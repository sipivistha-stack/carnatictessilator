import React, { useRef, useEffect } from 'react';
import { Submission } from '../../types';
import { DocumentPaperViewer } from './DocumentPaperViewer';
import { Award, Calendar, CheckCircle2, User, FileText, Code2, Check, X, AlertCircle, Stamp } from 'lucide-react';

interface CorrectionSheetViewerProps {
  submission: Submission;
  onClose?: () => void;
}

export const CorrectionSheetViewer: React.FC<CorrectionSheetViewerProps> = ({
  submission,
  onClose,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  const { correction, payload, taskTitle, taskType, studentName, submittedAt } = submission;

  // Redraw teacher's pen strokes directly over the document pages
  useEffect(() => {
    const redraw = () => {
      const canvas = canvasRef.current;
      const container = containerRef.current;
      if (!canvas || !container || !correction) return;

      const w = container.clientWidth || container.scrollWidth;
      const h = container.clientHeight || container.scrollHeight;
      if (w > 0 && h > 0) {
        canvas.width = w;
        canvas.height = h;
      }

      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      ctx.clearRect(0, 0, canvas.width, canvas.height);

      (correction.penStrokes || []).forEach(stroke => {
        if (stroke.points.length < 2) return;
        ctx.beginPath();
        ctx.strokeStyle = stroke.color;
        ctx.lineWidth = stroke.width;
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';
        ctx.globalAlpha = stroke.type === 'highlighter' ? 0.38 : 1.0;

        ctx.moveTo(stroke.points[0].x, stroke.points[0].y);
        for (let i = 1; i < stroke.points.length; i++) {
          ctx.lineTo(stroke.points[i].x, stroke.points[i].y);
        }
        ctx.stroke();
      });

      ctx.globalAlpha = 1.0;
    };

    redraw();

    const resizeObserver = new ResizeObserver(() => {
      redraw();
    });

    if (containerRef.current) {
      resizeObserver.observe(containerRef.current);
    }

    window.addEventListener('resize', redraw);
    return () => {
      resizeObserver.disconnect();
      window.removeEventListener('resize', redraw);
    };
  }, [correction]);

  const percentage = correction ? Math.round((correction.grade / correction.maxPoints) * 100) : 0;

  return (
    <div className="flex flex-col gap-6">
      {/* Grade & Teacher Feedback Card */}
      {correction && (
        <div className="rounded-xl border-2 border-indigo-200 bg-gradient-to-r from-indigo-50/80 via-white to-slate-50 p-5 shadow-xs">
          <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-indigo-100">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-indigo-600 text-white flex items-center justify-center font-bold text-xl shadow-xs">
                {correction.letterGrade || 'A'}
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-lg font-bold text-slate-900">
                    Evaluation Result: {correction.grade} / {correction.maxPoints} pts
                  </span>
                  <span className="text-sm font-semibold px-2.5 py-0.5 rounded-full bg-indigo-100 text-indigo-700">
                    {percentage}%
                  </span>
                </div>
                <p className="text-xs text-slate-500 mt-0.5">
                  Evaluated by {correction.evaluatorName || 'Teacher'} · {new Date(correction.evaluatedAt).toLocaleString()}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 text-xs text-emerald-700 bg-emerald-50 px-3 py-1.5 rounded-lg border border-emerald-200">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span className="font-semibold">Teacher Evaluated Correction Sheet</span>
            </div>
          </div>

          {/* Feedback note */}
          <div className="mt-3.5">
            <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1">
              Teacher's Feedback & Comments
            </h4>
            <div className="rounded-lg bg-white p-3.5 border border-slate-200 text-sm text-slate-800 leading-relaxed font-sans shadow-2xs">
              {correction.feedback || 'Good attempt. Review the markings on your submission sheet below.'}
            </div>
          </div>
        </div>
      )}

      {/* Submission Details & Visual Correction Sheet Canvas Overlay */}
      <div className="rounded-xl border border-slate-300 bg-white overflow-hidden shadow-md">
        <div className="flex items-center justify-between border-b border-slate-200 bg-slate-50 px-4 py-3">
          <div className="flex items-center gap-2">
            <span className="text-sm font-bold text-slate-900">{taskTitle}</span>
            <span className="text-xs text-slate-500 capitalize">({taskType})</span>
            {payload.fileName && (
              <span className="text-xs font-mono text-slate-600 bg-slate-200 px-2 py-0.5 rounded">
                {payload.fileName}
              </span>
            )}
          </div>
          <div className="text-xs text-slate-500 flex items-center gap-3">
            <span>Student: <strong className="text-slate-800">{studentName}</strong></span>
            <span>Submitted: {new Date(submittedAt).toLocaleDateString()}</span>
          </div>
        </div>

        {/* Relative container holding student document AND the teacher's pen strokes canvas directly on top */}
        <div ref={containerRef} className="relative w-full bg-slate-200/50 overflow-x-auto min-h-[480px]">
          {/* Transparent Canvas with Pen Strokes directly over the document */}
          {correction && (
            <canvas
              ref={canvasRef}
              className="absolute inset-0 z-20 pointer-events-none w-full h-full"
            />
          )}

          {/* Stamps */}
          {correction?.stamps?.map(stamp => (
            <div
              key={stamp.id}
              className="absolute z-20 pointer-events-none transform -translate-x-1/2 -translate-y-1/2"
              style={{ left: stamp.x, top: stamp.y, color: stamp.color }}
            >
              {stamp.iconType === 'check' && (
                <span className="w-8 h-8 rounded-full border-2 border-emerald-500 bg-emerald-50 text-emerald-600 flex items-center justify-center text-lg font-bold shadow-md">
                  ✓
                </span>
              )}
              {stamp.iconType === 'cross' && (
                <span className="w-8 h-8 rounded-full border-2 border-red-500 bg-red-50 text-red-600 flex items-center justify-center text-lg font-bold shadow-md">
                  ✗
                </span>
              )}
              {stamp.iconType === 'star' && (
                <span className="w-8 h-8 rounded-full border-2 border-amber-500 bg-amber-50 text-amber-500 flex items-center justify-center text-lg font-bold shadow-md">
                  ★
                </span>
              )}
              {stamp.iconType === 'hundred' && (
                <span className="px-2 py-0.5 rounded border-2 border-red-600 bg-red-50 text-red-700 text-xs font-black shadow-md">
                  💯
                </span>
              )}
              {stamp.iconType === 'question' && (
                <span className="w-8 h-8 rounded-full border-2 border-purple-500 bg-purple-50 text-purple-600 flex items-center justify-center text-base font-bold shadow-md">
                  ?
                </span>
              )}
            </div>
          ))}

          {/* Actual Student Work rendered directly below the teacher markings */}
          <div className="relative z-10 w-full">
            <DocumentPaperViewer submission={submission} isAnnotating={false} />
          </div>
        </div>
      </div>
    </div>
  );
};
