import React from 'react';

interface State { hasError: boolean; message?: string }

export class AppErrorBoundary extends React.Component<React.PropsWithChildren, State> {
  state: State = { hasError: false };

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, message: error?.message || 'Unexpected application error.' };
  }

  componentDidCatch(error: Error, info: React.ErrorInfo) {
    console.error('EduTask application error:', error, info);
  }

  render() {
    if (!this.state.hasError) return this.props.children;
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
        <div className="max-w-xl w-full bg-white border border-red-200 rounded-2xl shadow-xl p-6">
          <h1 className="text-lg font-bold text-red-800">EduTask could not open this item</h1>
          <p className="mt-2 text-sm text-slate-600">The uploaded document or task data caused an unexpected error. Your other classroom data is still safe.</p>
          <pre className="mt-4 whitespace-pre-wrap text-xs bg-slate-100 rounded-lg p-3 text-slate-700">{this.state.message}</pre>
          <button type="button" onClick={() => window.location.reload()} className="mt-4 px-4 py-2 rounded-lg bg-indigo-600 text-white text-sm font-semibold">Reload Classroom</button>
        </div>
      </div>
    );
  }
}
