import React from 'react';
import { StudentProfile, Task } from '../../types';
import { 
  X, 
  AlertTriangle, 
  ShieldAlert, 
  Lock, 
  FileText, 
  UserX, 
  Clock, 
  HelpCircle,
  School,
  ArrowRight
} from 'lucide-react';

interface AttendanceGateModalProps {
  student: StudentProfile;
  examTask?: Task | null;
  onClose: () => void;
  onRequestCondonation?: () => void;
}

export const AttendanceGateModal: React.FC<AttendanceGateModalProps> = ({
  student,
  examTask,
  onClose,
  onRequestCondonation,
}) => {
  const currentAttendance = student.attendancePercentage ?? 0;
  const requiredAttendance = 75;
  const deficit = Math.max(0, requiredAttendance - currentAttendance);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="relative w-full max-w-lg rounded-2xl bg-white shadow-2xl border border-rose-200 overflow-hidden animate-scale-in">
        {/* Urgent Header */}
        <div className="bg-gradient-to-r from-rose-700 via-red-700 to-rose-800 p-6 text-white text-center relative">
          <button
            type="button"
            onClick={onClose}
            className="absolute top-4 right-4 rounded-lg p-1.5 text-rose-200 hover:bg-white/10 hover:text-white transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="w-16 h-16 rounded-2xl bg-white/10 border-2 border-white/20 mx-auto flex items-center justify-center mb-3 shadow-lg">
            <Lock className="w-8 h-8 text-rose-100 animate-bounce" />
          </div>

          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/20 text-rose-100 text-xs font-bold uppercase tracking-wider mb-1">
            <ShieldAlert className="w-4 h-4 text-amber-300" />
            <span>Academic Regulation Clause 14(B)</span>
          </div>

          <h2 className="text-xl font-black text-white tracking-tight mt-1">
            Examination Hall Entry Barred
          </h2>
          <p className="text-xs text-rose-100 mt-1 max-w-xs mx-auto">
            Mandatory minimum attendance threshold of 75.0% has not been satisfied.
          </p>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5 text-xs">
          {/* Student Status Card */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div 
                className="w-10 h-10 rounded-xl flex items-center justify-center text-white font-bold text-sm shadow-xs"
                style={{ backgroundColor: student.avatarColor || '#e11d48' }}
              >
                {student.name.slice(0, 2).toUpperCase()}
              </div>
              <div>
                <h3 className="font-bold text-slate-900 text-sm">{student.name}</h3>
                <p className="text-slate-500 font-mono text-[11px]">
                  Roll: {student.rollNo} · {student.section}
                </p>
              </div>
            </div>

            <div className="text-right">
              <span className="text-[10px] text-slate-400 font-bold uppercase block">Status</span>
              <span className="text-xs font-black text-rose-600 bg-rose-50 px-2 py-0.5 rounded border border-rose-200">
                Detained / Barred
              </span>
            </div>
          </div>

          {/* Exam Details (if applicable) */}
          {examTask && (
            <div className="bg-indigo-50/60 border border-indigo-200 rounded-xl p-3.5 space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-[10px] uppercase font-bold text-indigo-700">Target Examination</span>
                <span className="font-mono font-bold text-indigo-900">{examTask.maxPoints} Marks</span>
              </div>
              <p className="font-bold text-slate-900">{examTask.title}</p>
              <p className="text-[11px] text-slate-600 line-clamp-1">{examTask.description}</p>
            </div>
          )}

          {/* Attendance Breakdown Matrix */}
          <div className="grid grid-cols-3 gap-2 text-center">
            <div className="p-3 rounded-xl border border-rose-300 bg-rose-50">
              <span className="text-[10px] text-rose-700 font-bold uppercase block">Your Attendance</span>
              <span className="text-2xl font-black text-rose-900 mt-1 block font-mono">
                {currentAttendance}%
              </span>
              <span className="text-[10px] text-rose-600 font-semibold block mt-0.5">Shortfall</span>
            </div>

            <div className="p-3 rounded-xl border border-slate-200 bg-white">
              <span className="text-[10px] text-slate-500 font-bold uppercase block">Minimum Required</span>
              <span className="text-2xl font-black text-slate-900 mt-1 block font-mono">
                75%
              </span>
              <span className="text-[10px] text-slate-500 font-semibold block mt-0.5">Statutory Cutoff</span>
            </div>

            <div className="p-3 rounded-xl border border-amber-300 bg-amber-50">
              <span className="text-[10px] text-amber-700 font-bold uppercase block">Attendance Deficit</span>
              <span className="text-2xl font-black text-amber-900 mt-1 block font-mono">
                -{deficit}%
              </span>
              <span className="text-[10px] text-amber-700 font-semibold block mt-0.5">Under Requirement</span>
            </div>
          </div>

          {/* Institutional Bylaw Statement */}
          <div className="bg-slate-100 rounded-xl p-3.5 border border-slate-200 space-y-1.5 leading-relaxed text-slate-700">
            <div className="flex items-center gap-1.5 font-bold text-slate-900">
              <School className="w-3.5 h-3.5 text-slate-700" />
              <span>Controller of Examinations Notice:</span>
            </div>
            <p className="text-[11px] text-slate-600">
              Candidates who do not meet the minimum 75% attendance criterion cannot be issued digital hall tickets or access formal exam scripts. Your script submission will not be accepted until the instructor marks makeup sessions or grants academic condonation.
            </p>
          </div>

          {/* Remedial Steps */}
          <div className="space-y-1.5 text-slate-600">
            <span className="font-bold text-slate-800 block">How to resolve this issue:</span>
            <ul className="list-disc pl-4 space-y-1 text-[11px]">
              <li>Contact your faculty teacher (Vidwan K. Narayanaswamy) to verify physical log books.</li>
              <li>Attend scheduled makeup masterclasses or practical raga drill sessions.</li>
              <li>Submit genuine medical or duty-leave documentation to the Dean of Fine Arts.</li>
            </ul>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl border border-slate-300 bg-white font-bold text-xs text-slate-700 hover:bg-slate-100 cursor-pointer"
          >
            Acknowledge & Close
          </button>

          <button
            type="button"
            onClick={() => {
              if (onRequestCondonation) {
                onRequestCondonation();
              } else {
                alert(`Condonation request recorded for ${student.name} (Roll: ${student.rollNo}). The course instructor has been notified on the Teacher Dashboard.`);
                onClose();
              }
            }}
            className="flex items-center gap-1.5 px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow-md transition active:scale-95 cursor-pointer"
          >
            <span>Request Faculty Review</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
