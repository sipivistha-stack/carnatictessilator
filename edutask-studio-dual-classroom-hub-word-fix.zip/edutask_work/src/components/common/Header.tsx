import React from 'react';
import { Role, StudentProfile } from '../../types';
import { 
  GraduationCap, 
  School, 
  User, 
  Check, 
  Sparkles,
  ChevronDown
} from 'lucide-react';

interface HeaderProps {
  currentRole: Role;
  onSelectRole: (role: Role) => void;
  currentStudent: StudentProfile;
  students: StudentProfile[];
  onSelectStudent: (student: StudentProfile) => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentRole,
  onSelectRole,
  currentStudent,
  students,
  onSelectStudent,
}) => {
  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-200 bg-white/95 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        {/* Brand */}
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-600 to-indigo-700 text-white flex items-center justify-center font-black shadow-xs">
            <GraduationCap className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-sm font-black text-slate-900 tracking-tight">EduTask</span>
              <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-700 bg-indigo-50 px-1.5 py-0.2 rounded border border-indigo-100">
                STUDIO
              </span>
            </div>
            <p className="text-[10px] text-slate-400 font-medium">Dual Classroom & Evaluation Hub</p>
          </div>
        </div>

        {/* Central Role Selector: "Are you Teacher or Student?" */}
        <div className="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200 shadow-2xs">
          <span className="text-xs font-semibold text-slate-500 px-2 hidden sm:inline select-none">
            Are you:
          </span>
          <button
            type="button"
            onClick={() => onSelectRole('student')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
              currentRole === 'student'
                ? 'bg-white text-indigo-700 shadow-xs ring-1 ring-slate-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <GraduationCap className="w-3.5 h-3.5 text-indigo-600" />
            <span>Student Dashboard</span>
          </button>

          <button
            type="button"
            onClick={() => onSelectRole('teacher')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
              currentRole === 'teacher'
                ? 'bg-white text-indigo-700 shadow-xs ring-1 ring-slate-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <School className="w-3.5 h-3.5 text-indigo-600" />
            <span>Teacher Dashboard</span>
          </button>
        </div>

        {/* Right side persona details */}
        <div className="flex items-center gap-2">
          {currentRole === 'student' ? (
            <div className="flex items-center gap-2 text-xs">
              <span className="text-slate-400 hidden md:inline">Logged in as:</span>
              <div className="relative group">
                <button
                  type="button"
                  className="flex items-center gap-2 px-2.5 py-1 rounded-lg border border-slate-200 bg-slate-50 hover:bg-slate-100 transition cursor-pointer"
                >
                  <div
                    className="w-5 h-5 rounded-full text-white flex items-center justify-center text-[10px] font-bold"
                    style={{ backgroundColor: currentStudent.avatarColor || '#3b82f6' }}
                  >
                    {currentStudent.name.slice(0, 1)}
                  </div>
                  <span className="font-semibold text-slate-800">{currentStudent.name}</span>
                  <ChevronDown className="w-3 h-3 text-slate-400" />
                </button>

                {/* Dropdown to switch student persona */}
                <div className="absolute right-0 mt-1 w-52 rounded-xl bg-white border border-slate-200 shadow-lg p-1 hidden group-hover:block z-50">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 px-2 py-1 block">
                    Switch Student Persona
                  </span>
                  {students.map(s => (
                    <button
                      key={s.id}
                      type="button"
                      onClick={() => onSelectStudent(s)}
                      className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-xs text-left transition ${
                        currentStudent.id === s.id
                          ? 'bg-indigo-50 text-indigo-700 font-bold'
                          : 'text-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <div
                          className="w-4 h-4 rounded-full text-white text-[9px] flex items-center justify-center font-bold"
                          style={{ backgroundColor: s.avatarColor || '#3b82f6' }}
                        >
                          {s.name.slice(0, 1)}
                        </div>
                        <span>{s.name}</span>
                      </div>
                      {currentStudent.id === s.id && <Check className="w-3 h-3 text-indigo-600" />}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="flex items-center gap-2 text-xs">
              <div className="flex items-center gap-2 px-2.5 py-1 rounded-lg border border-indigo-200 bg-indigo-50 text-indigo-900 font-semibold">
                <div className="w-2 h-2 rounded-full bg-indigo-600 animate-pulse"></div>
                <span>Lead Faculty: Vidwan K. Narayanaswamy</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
