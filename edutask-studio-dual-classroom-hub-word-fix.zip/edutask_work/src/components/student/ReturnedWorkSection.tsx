import React, { useState } from 'react';
import { Submission, StudentProfile } from '../../types';
import { CorrectionSheetViewer } from '../common/CorrectionSheetViewer';
import { Award, FileCheck, CheckCircle2, Eye, Calendar, Sparkles, X } from 'lucide-react';

interface ReturnedWorkSectionProps {
  submissions: Submission[];
  currentStudent: StudentProfile;
}

export const ReturnedWorkSection: React.FC<ReturnedWorkSectionProps> = ({
  submissions,
  currentStudent,
}) => {
  const [selectedSubForViewer, setSelectedSubForViewer] = useState<Submission | null>(null);

  // Filter returned work for current student
  const returnedWork = submissions.filter(
    s => (s.studentId === currentStudent.id || s.studentName.toLowerCase() === currentStudent.name.toLowerCase()) &&
         s.status === 'returned' &&
         s.correction
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-xs">
        <div className="flex items-center gap-2">
          <span className="text-xs font-bold uppercase tracking-wider text-emerald-600 bg-emerald-50 px-2.5 py-0.5 rounded-full">
            Evaluations & Feedback
          </span>
          <span className="text-xs text-slate-400">· Teacher Correction Sheets</span>
        </div>
        <h2 className="text-xl font-black text-slate-900 mt-1">Returned Work & Visual Correction Sheets</h2>
        <p className="text-xs text-slate-500 mt-0.5">
          View graded assignments, teacher handwritten pen annotations, stamps, and formal constructive remarks.
        </p>
      </div>

      {returnedWork.length === 0 ? (
        <div className="rounded-2xl border-2 border-dashed border-slate-200 bg-white p-12 text-center">
          <div className="w-14 h-14 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center mx-auto mb-3">
            <Award className="w-7 h-7" />
          </div>
          <h3 className="text-base font-bold text-slate-800">No returned assignments yet</h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto mt-1">
            Once you submit tasks and your teacher evaluates them using the correction pen tool, your graded correction sheets will be displayed here.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {returnedWork.map(sub => {
            const corr = sub.correction!;
            const percentage = Math.round((corr.grade / corr.maxPoints) * 100);

            return (
              <div
                key={sub.id}
                className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs hover:border-slate-300 transition flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded ${
                        sub.taskCategory === 'temporary_task' ? 'bg-amber-100 text-amber-800' : 'bg-blue-100 text-blue-800'
                      }`}>
                        {sub.taskCategory === 'temporary_task' ? 'Task' : 'Assignment'}
                      </span>
                      <span className="text-xs font-semibold text-slate-500 capitalize">{sub.taskType}</span>
                    </div>

                    <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Returned</span>
                    </div>
                  </div>

                  <h3 className="text-base font-bold text-slate-900 mt-2.5">{sub.taskTitle}</h3>

                  {/* Grade Badge Banner */}
                  <div className="mt-3.5 p-3.5 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center font-bold text-base shadow-xs">
                        {corr.letterGrade || 'A'}
                      </div>
                      <div>
                        <span className="text-xs font-bold text-slate-800">
                          {corr.grade} / {corr.maxPoints} pts ({percentage}%)
                        </span>
                        <p className="text-[11px] text-slate-400">
                          Evaluated by {corr.evaluatorName || 'Teacher'}
                        </p>
                      </div>
                    </div>

                    <div className="text-right text-[11px] text-slate-400">
                      <span>{corr.penStrokes?.length || 0} pen marks</span>
                    </div>
                  </div>

                  {/* Teacher Feedback snippet */}
                  <div className="mt-3">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                      Teacher's Feedback:
                    </span>
                    <p className="text-xs text-slate-700 line-clamp-2 italic bg-slate-50/50 p-2.5 rounded-lg border border-slate-100">
                      "{corr.feedback || 'Well done!'}"
                    </p>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                  <span className="text-xs text-slate-400">
                    {new Date(corr.evaluatedAt).toLocaleDateString()}
                  </span>

                  <button
                    type="button"
                    onClick={() => setSelectedSubForViewer(sub)}
                    className="flex items-center gap-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white px-3.5 py-1.5 text-xs font-bold shadow-xs transition active:scale-95 cursor-pointer"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>Open Correction Sheet</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Interactive Correction Sheet Modal */}
      {selectedSubForViewer && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-950/70 backdrop-blur-xs overflow-y-auto">
          <div className="relative w-full max-w-5xl rounded-2xl bg-white shadow-2xl border border-slate-200 overflow-hidden my-6 flex flex-col max-h-[92vh]">
            <div className="flex items-center justify-between border-b border-slate-200 bg-slate-50 px-6 py-4">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-indigo-700 bg-indigo-100 px-2.5 py-0.5 rounded-full">
                  Correction Sheet
                </span>
                <h3 className="text-base font-bold text-slate-900">{selectedSubForViewer.taskTitle}</h3>
              </div>
              <button
                type="button"
                onClick={() => setSelectedSubForViewer(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 overflow-y-auto flex-1">
              <CorrectionSheetViewer
                submission={selectedSubForViewer}
                onClose={() => setSelectedSubForViewer(null)}
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
