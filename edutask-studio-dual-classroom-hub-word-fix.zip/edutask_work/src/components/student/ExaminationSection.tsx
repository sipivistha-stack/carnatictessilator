import React, { useState } from 'react';
import { Task, Submission, StudentProfile } from '../../types';
import { 
  FileSpreadsheet, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  Play, 
  Award, 
  ShieldCheck, 
  Music, 
  Keyboard, 
  Code2, 
  FileText,
  Lock,
  AlertTriangle,
  ShieldAlert
} from 'lucide-react';
import { AttendanceGateModal } from '../common/AttendanceGateModal';

interface ExaminationSectionProps {
  tasks: Task[];
  submissions: Submission[];
  currentStudent: StudentProfile;
  onOpenWorkspace: (task: Task) => void;
  onViewResults: () => void;
}

export const ExaminationSection: React.FC<ExaminationSectionProps> = ({
  tasks,
  submissions,
  currentStudent,
  onOpenWorkspace,
  onViewResults,
}) => {
  const [filter, setFilter] = useState<'all' | 'active' | 'completed'>('all');
  const [barredExamTarget, setBarredExamTarget] = useState<Task | null>(null);

  const studentAttendance = currentStudent.attendancePercentage ?? 85;
  const isEligibleForExam = studentAttendance >= 75;

  // Filter tasks that belong to category 'examination'
  const examTasks = tasks.filter(t => t.category === 'examination' && t.status === 'active');

  const filteredExams = examTasks.filter(task => {
    const sub = submissions.find(s => s.taskId === task.id && s.studentId === currentStudent.id);
    if (filter === 'completed') return !!sub;
    if (filter === 'active') return !sub;
    return true;
  });

  const handleAttemptExam = (exam: Task) => {
    if (!isEligibleForExam) {
      setBarredExamTarget(exam);
      return;
    }
    onOpenWorkspace(exam);
  };

  return (
    <div className="space-y-6">
      {/* Attendance Eligibility Alert if Barred */}
      {!isEligibleForExam && (
        <div className="rounded-2xl border-2 border-rose-300 bg-rose-50 p-5 shadow-md flex flex-col sm:flex-row sm:items-center justify-between gap-4 animate-pulse">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-rose-600 text-white flex items-center justify-center font-bold shrink-0 shadow-xs">
              <ShieldAlert className="w-7 h-7 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-black uppercase tracking-wider text-rose-800 bg-rose-200/80 px-2 py-0.5 rounded">
                  Academic Regulation Clause 14(B)
                </span>
                <span className="text-xs font-bold text-rose-700">
                  Hall Ticket Denied
                </span>
              </div>
              <h3 className="text-base font-black text-rose-950 mt-0.5">
                Examination Hall Entry Barred: Insufficient Attendance ({studentAttendance}% &lt; 75%)
              </h3>
              <p className="text-xs text-rose-800 mt-0.5">
                Students are required to have at least <strong>75% cumulative attendance</strong> to write formal semester examinations. You have a <strong>{75 - studentAttendance}% deficit</strong>.
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setBarredExamTarget(examTasks[0] || null)}
            className="whitespace-nowrap px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow-xs cursor-pointer"
          >
            View Regulation Details
          </button>
        </div>
      )}

      {/* Examination Hall Banner */}
      <div className="rounded-2xl border border-indigo-200 bg-gradient-to-r from-indigo-900 via-slate-900 to-indigo-950 text-white p-6 sm:p-8 shadow-lg">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className={`w-2.5 h-2.5 rounded-full ${isEligibleForExam ? 'bg-emerald-400 animate-pulse' : 'bg-rose-400'}`}></span>
              <span className="text-xs font-bold uppercase tracking-widest text-indigo-300">
                Live Examination Hall · Controlled Assessment
              </span>
            </div>
            <h2 className="text-2xl font-black text-white tracking-tight">
              Formal Examinations & Practical Assessments
            </h2>
            <p className="text-xs text-indigo-200 max-w-2xl leading-relaxed">
              Examinations conducted by your faculty (Carnatic Music internal theory, singing viva, typing examinations, and algorithmic tests) appear here. Adhere strictly to the time limit and examination rules.
            </p>
          </div>

          <div className="flex items-center gap-3">
            {/* Student's Current Eligibility Status Card */}
            <div className={`p-4 rounded-xl border backdrop-blur-md text-center min-w-[150px] ${
              isEligibleForExam 
                ? 'bg-emerald-950/40 border-emerald-400/40 text-emerald-200' 
                : 'bg-rose-950/50 border-rose-400/40 text-rose-200'
            }`}>
              <span className="text-[10px] block uppercase font-bold tracking-wider">
                Your Attendance
              </span>
              <span className="text-3xl font-black text-white font-mono">{studentAttendance}%</span>
              <span className={`text-[11px] block mt-1 font-bold ${isEligibleForExam ? 'text-emerald-300' : 'text-rose-300'}`}>
                {isEligibleForExam ? '✓ Exam Eligible (≥75%)' : '✗ Barred (<75%)'}
              </span>
            </div>

            <div className="bg-white/10 backdrop-blur-md p-4 rounded-xl border border-white/20 text-center min-w-[130px]">
              <span className="text-[10px] text-indigo-200 block uppercase font-bold tracking-wider">Scheduled</span>
              <span className="text-3xl font-black text-white">{examTasks.length}</span>
              <span className="text-[11px] text-emerald-300 block mt-1 font-semibold">Active Sessions</span>
            </div>
          </div>
        </div>

        {/* Examination Rules Bar */}
        <div className="mt-6 pt-4 border-t border-white/10 flex flex-wrap items-center gap-4 text-xs text-indigo-200 font-sans">
          <span className="flex items-center gap-1.5 font-semibold text-white">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Honour Code Enforced</span>
          </span>
          <span>•</span>
          <span>Camera & Microphone Access for Music Viva</span>
          <span>•</span>
          <span>Automatic Timestamped Script Submission</span>
          <span>•</span>
          <span className="text-amber-300 font-semibold">Strict 75% Attendance Requirement</span>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center justify-between border-b border-slate-200 pb-3">
        <div className="flex items-center gap-2">
          {(['all', 'active', 'completed'] as const).map(tab => (
            <button
              key={tab}
              type="button"
              onClick={() => setFilter(tab)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold capitalize transition cursor-pointer ${
                filter === tab
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {tab === 'all' ? `All Exams (${examTasks.length})` : tab}
            </button>
          ))}
        </div>

        <button
          type="button"
          onClick={onViewResults}
          className="flex items-center gap-1 text-xs font-bold text-indigo-600 hover:text-indigo-800 hover:underline cursor-pointer"
        >
          <Award className="w-4 h-4" />
          <span>View Evaluated Results & Report Card →</span>
        </button>
      </div>

      {/* Exams Grid */}
      {filteredExams.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {filteredExams.map(exam => {
            const sub = submissions.find(s => s.taskId === exam.id && s.studentId === currentStudent.id);
            const isCompleted = !!sub;
            const isReturned = sub?.status === 'returned' || sub?.status === 'evaluated';

            return (
              <div
                key={exam.id}
                className={`rounded-2xl border p-6 flex flex-col justify-between transition shadow-xs ${
                  isCompleted
                    ? 'bg-slate-50/80 border-slate-200'
                    : 'bg-white border-indigo-200 hover:border-indigo-400 shadow-sm'
                }`}
              >
                <div>
                  {/* Card Header */}
                  <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-100">
                    <div className="flex items-center gap-2">
                      <span className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold ${
                        exam.type === 'carnatic_music' ? 'bg-amber-100 text-amber-800' :
                        exam.type === 'typing_exam' ? 'bg-indigo-100 text-indigo-800' :
                        'bg-blue-100 text-blue-800'
                      }`}>
                        {exam.type === 'carnatic_music' ? <Music className="w-4 h-4" /> :
                         exam.type === 'typing_exam' ? <Keyboard className="w-4 h-4" /> :
                         <FileText className="w-4 h-4" />}
                      </span>
                      <span className="text-xs font-bold uppercase tracking-wider text-indigo-700">
                        {exam.type.replace('_', ' ')}
                      </span>
                    </div>

                    <span className="font-mono font-black text-xs text-indigo-900 bg-indigo-50 px-2.5 py-1 rounded-md border border-indigo-200">
                      {exam.maxPoints} Marks
                    </span>
                  </div>

                  <h3 className="text-base font-bold text-slate-900 leading-snug">
                    {exam.title}
                  </h3>
                  <p className="text-xs text-slate-600 mt-2 line-clamp-3 leading-relaxed">
                    {exam.description}
                  </p>

                  {/* Carnatic / Exam details */}
                  {exam.carnaticConfig && (
                    <div className="mt-3 bg-amber-50/70 border border-amber-200 p-2.5 rounded-lg text-[11px] text-amber-900 space-y-1">
                      <p><strong>Raga:</strong> {exam.carnaticConfig.raga}</p>
                      <p><strong>Tala:</strong> {exam.carnaticConfig.tala}</p>
                      <p><strong>Aspect:</strong> {exam.carnaticConfig.taskAspect.replace('_', ' ').toUpperCase()}</p>
                    </div>
                  )}

                  {exam.timeLimitMinutes && (
                    <div className="flex items-center gap-1.5 text-xs text-slate-500 font-semibold mt-3">
                      <Clock className="w-3.5 h-3.5 text-indigo-600" />
                      <span>Duration: {exam.timeLimitMinutes} Minutes</span>
                    </div>
                  )}
                </div>

                {/* Card Action Footer */}
                <div className="pt-5 mt-5 border-t border-slate-100 flex items-center justify-between">
                  {isReturned ? (
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded border border-emerald-200">
                        Score: {sub.correction?.grade} / {sub.correction?.maxPoints} pts ({sub.correction?.letterGrade})
                      </span>
                      <button
                        type="button"
                        onClick={onViewResults}
                        className="text-xs font-bold text-indigo-600 hover:underline cursor-pointer"
                      >
                        Inspect Script →
                      </button>
                    </div>
                  ) : isCompleted ? (
                    <div className="flex items-center gap-2 text-xs font-semibold text-slate-500">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      <span>Script Submitted · Under Evaluation</span>
                    </div>
                  ) : isEligibleForExam ? (
                    <button
                      type="button"
                      onClick={() => onOpenWorkspace(exam)}
                      className="w-full flex items-center justify-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs py-2.5 rounded-xl shadow-xs transition active:scale-95 cursor-pointer"
                    >
                      <Play className="w-3.5 h-3.5 fill-current" />
                      <span>Enter Examination Hall & Begin</span>
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => setBarredExamTarget(exam)}
                      className="w-full flex items-center justify-center gap-2 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs py-2.5 rounded-xl shadow-xs transition active:scale-95 cursor-pointer"
                      title="You cannot write this exam because your attendance is below 75%"
                    >
                      <Lock className="w-3.5 h-3.5" />
                      <span>Entry Barred: Attendance ({studentAttendance}% &lt; 75%)</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="rounded-xl border border-dashed border-slate-300 bg-white p-12 text-center space-y-2">
          <Clock className="w-10 h-10 text-slate-400 mx-auto" />
          <h4 className="text-sm font-bold text-slate-800">No Examinations Found</h4>
          <p className="text-xs text-slate-500 max-w-md mx-auto">
            Your faculty has not scheduled any examinations currently in this category. Check back during official exam hours.
          </p>
        </div>
      )}

      {/* Attendance Gate Modal */}
      {barredExamTarget && (
        <AttendanceGateModal
          student={currentStudent}
          examTask={barredExamTarget}
          onClose={() => setBarredExamTarget(null)}
        />
      )}
    </div>
  );
};
