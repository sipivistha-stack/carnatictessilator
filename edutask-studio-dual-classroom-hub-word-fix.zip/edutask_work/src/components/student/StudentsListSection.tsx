import React, { useState } from 'react';
import { StudentProfile, Submission } from '../../types';
import { Users, CheckCircle2, UserCheck, Sparkles, Plus, Edit2 } from 'lucide-react';

interface StudentsListSectionProps {
  students: StudentProfile[];
  currentStudent: StudentProfile;
  submissions: Submission[];
  onSelectStudent: (student: StudentProfile) => void;
  onCustomStudentName: (name: string) => void;
}

export const StudentsListSection: React.FC<StudentsListSectionProps> = ({
  students,
  currentStudent,
  submissions,
  onSelectStudent,
  onCustomStudentName,
}) => {
  const [customNameInput, setCustomNameInput] = useState<string>('');
  const [isEditingCustom, setIsEditingCustom] = useState<boolean>(false);

  const handleAddCustom = (e: React.FormEvent) => {
    e.preventDefault();
    if (customNameInput.trim()) {
      onCustomStudentName(customNameInput.trim());
      setCustomNameInput('');
      setIsEditingCustom(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header and Switcher banner */}
      <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 bg-indigo-50 px-2.5 py-0.5 rounded-full">
                Classroom Section A
              </span>
              <span className="text-xs text-slate-400">· Computer Science Lab</span>
            </div>
            <h2 className="text-xl font-black text-slate-900 mt-1">Students List & Activity Tracking</h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Current active student persona: <strong className="text-slate-900 font-bold">{currentStudent.name}</strong> ({currentStudent.rollNo}). Submissions you make will appear under this name on the Teacher Dashboard.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setIsEditingCustom(!isEditingCustom)}
              className="flex items-center gap-1.5 rounded-xl border border-indigo-200 bg-indigo-50 text-indigo-700 px-3.5 py-2 text-xs font-semibold hover:bg-indigo-100 transition cursor-pointer"
            >
              <UserCheck className="w-4 h-4 text-indigo-600" />
              <span>{isEditingCustom ? 'Close' : 'Set Custom Student Name'}</span>
            </button>
          </div>
        </div>

        {/* Custom student name form */}
        {isEditingCustom && (
          <form onSubmit={handleAddCustom} className="mt-4 p-4 rounded-xl bg-slate-50 border border-slate-200 flex flex-wrap items-center gap-3">
            <label className="text-xs font-semibold text-slate-700">Enter custom student name:</label>
            <input
              type="text"
              required
              value={customNameInput}
              onChange={e => setCustomNameInput(e.target.value)}
              placeholder="e.g. Jordan Rivera, Emily Vance..."
              className="rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs text-slate-900 focus:outline-hidden focus:border-indigo-500"
            />
            <button
              type="submit"
              className="rounded-lg bg-indigo-600 text-white px-4 py-1.5 text-xs font-bold hover:bg-indigo-700 transition"
            >
              Switch Identity
            </button>
          </form>
        )}
      </div>

      {/* Students List Roster Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {students.map(std => {
          const isCurrent = currentStudent.id === std.id || currentStudent.name.toLowerCase() === std.name.toLowerCase();
          
          // Submissions for this student
          const stdSubmissions = submissions.filter(
            s => s.studentId === std.id || s.studentName.toLowerCase() === std.name.toLowerCase()
          );

          const completedTasksCount = stdSubmissions.filter(s => s.taskCategory === 'temporary_task').length;
          const completedAssignmentsCount = stdSubmissions.filter(s => s.taskCategory === 'assignment').length;
          const totalCompleted = completedTasksCount + completedAssignmentsCount;
          const evaluatedCount = stdSubmissions.filter(s => s.status === 'returned').length;

          return (
            <div
              key={std.id}
              className={`rounded-2xl border p-5 transition flex flex-col justify-between shadow-xs ${
                isCurrent
                  ? 'border-indigo-600 bg-white ring-2 ring-indigo-500/20'
                  : 'border-slate-200 bg-white hover:border-slate-300'
              }`}
            >
              <div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div
                      className="w-11 h-11 rounded-xl text-white flex items-center justify-center font-bold text-sm shadow-xs"
                      style={{ backgroundColor: std.avatarColor || '#3b82f6' }}
                    >
                      {std.name.slice(0, 2).toUpperCase()}
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <h3 className="text-sm font-bold text-slate-900">{std.name}</h3>
                        {isCurrent && (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-700">
                            YOU
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-500">{std.rollNo} · {std.section}</p>
                    </div>
                  </div>
                </div>

                {/* Progress Indicators */}
                <div className="mt-5 grid grid-cols-3 gap-2 p-3 rounded-xl bg-slate-50 border border-slate-100 text-center">
                  <div>
                    <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider block">Tasks</span>
                    <strong className="text-base font-black text-slate-800">{completedTasksCount}</strong>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider block">Assignments</span>
                    <strong className="text-base font-black text-slate-800">{completedAssignmentsCount}</strong>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider block">Evaluated</span>
                    <strong className="text-base font-black text-emerald-600">{evaluatedCount}</strong>
                  </div>
                </div>
              </div>

              {/* Action */}
              <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-between">
                <span className="text-xs text-slate-500">
                  {totalCompleted > 0 ? `${totalCompleted} total submissions` : 'No submissions yet'}
                </span>

                {!isCurrent && (
                  <button
                    type="button"
                    onClick={() => onSelectStudent(std)}
                    className="text-xs font-bold text-indigo-600 hover:text-indigo-800 py-1 px-2 rounded hover:bg-indigo-50 transition cursor-pointer"
                  >
                    Act as {std.name.split(' ')[0]} →
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
