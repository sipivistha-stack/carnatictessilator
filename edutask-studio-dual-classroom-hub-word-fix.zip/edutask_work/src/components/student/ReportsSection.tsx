import React from 'react';
import { Task, Submission, StudentProfile } from '../../types';
import { Award, CheckCircle, Clock, BarChart3, TrendingUp, FileText, Code2, AlertCircle } from 'lucide-react';

interface ReportsSectionProps {
  tasks: Task[];
  submissions: Submission[];
  currentStudent: StudentProfile;
  onOpenCorrectionSheet: (submission: Submission) => void;
}

export const ReportsSection: React.FC<ReportsSectionProps> = ({
  tasks,
  submissions,
  currentStudent,
  onOpenCorrectionSheet,
}) => {
  // Filter submissions for this student
  const studentSubs = submissions.filter(
    s => s.studentId === currentStudent.id || s.studentName.toLowerCase() === currentStudent.name.toLowerCase()
  );

  const returnedSubs = studentSubs.filter(s => s.status === 'returned' && s.correction);

  // Compute metrics
  const totalSubmissions = studentSubs.length;
  const totalTasks = tasks.length;
  const completionRate = totalTasks > 0 ? Math.round((totalSubmissions / totalTasks) * 100) : 0;

  const totalPointsEarned = returnedSubs.reduce((acc, curr) => acc + (curr.correction?.grade || 0), 0);
  const totalMaxPoints = returnedSubs.reduce((acc, curr) => acc + (curr.correction?.maxPoints || 100), 0);
  const averagePercentage = totalMaxPoints > 0 ? Math.round((totalPointsEarned / totalMaxPoints) * 100) : 0;

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 bg-indigo-50 px-2.5 py-0.5 rounded-full">
                Academic Performance
              </span>
              <span className="text-xs text-slate-400">· Comprehensive Reports</span>
            </div>
            <h2 className="text-xl font-black text-slate-900 mt-1">Student Progress & Evaluation Report</h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Detailed performance metrics, grade analytics, and submission history for <strong className="text-slate-900">{currentStudent.name}</strong>.
            </p>
          </div>
        </div>

        {/* Metric Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-5 border-t border-slate-100">
          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
            <span className="text-xs text-slate-500 font-medium">Completed Activities</span>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-2xl font-black text-slate-900">{totalSubmissions}</span>
              <span className="text-xs text-slate-500">of {totalTasks} assigned</span>
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
            <span className="text-xs text-slate-500 font-medium">Completion Rate</span>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-2xl font-black text-indigo-600">{completionRate}%</span>
              <span className="text-xs text-slate-400">total tasks</span>
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
            <span className="text-xs text-slate-500 font-medium">Evaluated Work</span>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-2xl font-black text-emerald-600">{returnedSubs.length}</span>
              <span className="text-xs text-slate-400">returned</span>
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
            <span className="text-xs text-slate-500 font-medium">Average Grade</span>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-2xl font-black text-slate-900">
                {returnedSubs.length > 0 ? `${averagePercentage}%` : 'N/A'}
              </span>
              {returnedSubs.length > 0 && (
                <span className="text-xs font-bold text-emerald-600">
                  {averagePercentage >= 90 ? 'A' : averagePercentage >= 80 ? 'B' : 'C'}
                </span>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Submission Reports Log */}
      <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-xs space-y-4">
        <h3 className="text-base font-bold text-slate-900">Submissions & Evaluation Log</h3>

        {studentSubs.length === 0 ? (
          <div className="p-8 text-center border-2 border-dashed border-slate-200 rounded-xl">
            <FileText className="w-8 h-8 text-slate-400 mx-auto mb-2" />
            <p className="text-xs text-slate-500">No submissions submitted yet by {currentStudent.name}.</p>
            <p className="text-xs text-slate-400 mt-1">Open the Dashboard or Assignments section to do your assigned tasks.</p>
          </div>
        ) : (
          <div className="overflow-x-auto rounded-xl border border-slate-200">
            <table className="w-full text-xs text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 text-slate-600 border-b border-slate-200 select-none">
                  <th className="p-3 font-bold">Activity Title</th>
                  <th className="p-3 font-bold">Category</th>
                  <th className="p-3 font-bold">Format</th>
                  <th className="p-3 font-bold">Submitted Date</th>
                  <th className="p-3 font-bold">Status</th>
                  <th className="p-3 font-bold">Grade & Score</th>
                  <th className="p-3 font-bold text-right">Correction Sheet</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {studentSubs.map(sub => {
                  const isReturned = sub.status === 'returned';

                  return (
                    <tr key={sub.id} className="hover:bg-slate-50 transition">
                      <td className="p-3 font-semibold text-slate-900">{sub.taskTitle}</td>
                      <td className="p-3">
                        <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded ${
                          sub.taskCategory === 'temporary_task' ? 'bg-amber-100 text-amber-800' : 'bg-blue-100 text-blue-800'
                        }`}>
                          {sub.taskCategory === 'temporary_task' ? 'Task' : 'Assignment'}
                        </span>
                      </td>
                      <td className="p-3 font-mono capitalize text-slate-600">{sub.taskType}</td>
                      <td className="p-3 text-slate-500">
                        {new Date(sub.submittedAt).toLocaleDateString()} {new Date(sub.submittedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </td>
                      <td className="p-3">
                        {isReturned ? (
                          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                            <CheckCircle className="w-3 h-3" />
                            Evaluated
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-amber-700 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                            <Clock className="w-3 h-3" />
                            In Review
                          </span>
                        )}
                      </td>
                      <td className="p-3 font-bold text-slate-800">
                        {sub.correction ? (
                          <span className="flex items-center gap-1.5">
                            <span className="px-1.5 py-0.5 rounded bg-indigo-100 text-indigo-700 text-xs">
                              {sub.correction.letterGrade}
                            </span>
                            <span>{sub.correction.grade} / {sub.correction.maxPoints} pts</span>
                          </span>
                        ) : (
                          <span className="text-slate-400 font-normal">Pending</span>
                        )}
                      </td>
                      <td className="p-3 text-right">
                        {isReturned ? (
                          <button
                            type="button"
                            onClick={() => onOpenCorrectionSheet(sub)}
                            className="inline-flex items-center gap-1 rounded bg-indigo-50 text-indigo-700 hover:bg-indigo-100 px-2.5 py-1 font-bold text-xs border border-indigo-200 transition cursor-pointer"
                          >
                            <span>View Sheet</span>
                          </button>
                        ) : (
                          <span className="text-slate-400">—</span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
