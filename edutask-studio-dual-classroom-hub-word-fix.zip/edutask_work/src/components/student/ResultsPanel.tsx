import React, { useState } from 'react';
import { 
  StudentProfile, 
  Submission, 
  Task, 
  ReportCard, 
  InterconnectedTaskBundle,
  ClassGroup 
} from '../../types';
import { getReportCardsForStudent } from '../../data/storage';
import { 
  Award, 
  CheckCircle2, 
  FileText, 
  Printer, 
  Eye, 
  School, 
  Sparkles, 
  Calendar, 
  Star, 
  Clock, 
  Check, 
  ChevronRight,
  TrendingUp,
  Link2
} from 'lucide-react';
import { CorrectionSheetViewer } from '../common/CorrectionSheetViewer';

interface ResultsPanelProps {
  currentStudent: StudentProfile;
  tasks: Task[];
  submissions: Submission[];
  bundles: InterconnectedTaskBundle[];
  currentClass: ClassGroup;
}

export const ResultsPanel: React.FC<ResultsPanelProps> = ({
  currentStudent,
  tasks,
  submissions,
  bundles,
  currentClass,
}) => {
  const [selectedSubmissionForScript, setSelectedSubmissionForScript] = useState<Submission | null>(null);

  // Fetch report cards published specifically for this student
  const studentReportCards = getReportCardsForStudent(currentStudent.id);
  const latestReportCard = studentReportCards[0];

  // Evaluated submissions for this student
  const evaluatedSubmissions = submissions.filter(
    s => s.studentId === currentStudent.id && (s.status === 'evaluated' || s.status === 'returned')
  );

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="rounded-2xl border border-amber-300 bg-gradient-to-r from-amber-50 via-orange-50 to-amber-50 p-6 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-xl bg-amber-600 text-white flex items-center justify-center font-bold shadow-xs">
              <Award className="w-6 h-6" />
            </div>
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-amber-900 bg-amber-200/80 px-2.5 py-0.5 rounded">
                Official Examination & Performance Portal
              </span>
              <h2 className="text-xl font-black text-amber-950 mt-1">
                Academic Results & Faculty Report Cards
              </h2>
              <p className="text-xs text-amber-800 mt-0.5">
                Review your published report cards, interconnected marks totals, and inspect evaluated answer scripts with teacher pen markings.
              </p>
            </div>
          </div>

          <div className="text-right text-xs bg-white/90 p-3 rounded-xl border border-amber-200 shadow-2xs font-sans">
            <p className="font-bold text-slate-800">{currentStudent.name}</p>
            <p className="text-slate-500 font-mono">Roll: {currentStudent.rollNo} · {currentClass.name}</p>
            <p className="text-emerald-700 font-bold mt-1">
              ✓ {evaluatedSubmissions.length} Evaluated Tasks
            </p>
          </div>
        </div>
      </div>

      {/* 1. OFFICIAL FACULTY REPORT CARD (IF PUBLISHED) */}
      {latestReportCard ? (
        <div className="bg-white rounded-2xl border-4 border-amber-600/40 p-6 sm:p-10 shadow-xl relative overflow-hidden">
          {/* Certificate Header */}
          <div className="border-b-2 border-amber-800/20 pb-5 text-center space-y-1.5">
            <div className="flex items-center justify-center gap-2 text-amber-800 font-bold text-xs uppercase tracking-widest">
              <School className="w-4 h-4 text-amber-700" />
              <span>Official Institutional Progress Certificate</span>
            </div>
            <h3 className="font-serif text-2xl sm:text-3xl font-black text-amber-950">
              {latestReportCard.institutionName}
            </h3>
            <p className="text-xs font-sans font-bold text-amber-800 uppercase tracking-wider">
              {latestReportCard.term}
            </p>
            <p className="text-[11px] text-slate-400">
              Issued on: {latestReportCard.issuedDate} · Verification Ref: {latestReportCard.id}
            </p>
          </div>

          {/* Student Biodata Summary */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 py-5 border-b border-slate-200 text-xs font-sans">
            <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200">
              <span className="text-slate-500 font-semibold block">Student Name</span>
              <span className="font-bold text-slate-900 text-sm">{latestReportCard.studentName}</span>
            </div>
            <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200">
              <span className="text-slate-500 font-semibold block">Roll Number</span>
              <span className="font-bold text-slate-900 text-sm font-mono">{latestReportCard.rollNo}</span>
            </div>
            <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200">
              <span className="text-slate-500 font-semibold block">Class & Academic Year</span>
              <span className="font-bold text-slate-900 text-sm">{latestReportCard.className}</span>
            </div>
            <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200">
              <span className="text-slate-500 font-semibold block">Attendance Record</span>
              <span className="font-bold text-emerald-700 text-sm">{latestReportCard.attendancePercentage}% (Regular)</span>
            </div>
          </div>

          {/* Marks Breakdown Table */}
          <div className="py-5 space-y-3">
            <h4 className="text-xs font-black uppercase tracking-wider text-slate-700">
              Coursework & Examination Evaluation:
            </h4>

            <div className="overflow-x-auto rounded-lg border border-slate-300">
              <table className="w-full text-left text-xs border-collapse font-sans">
                <thead>
                  <tr className="bg-amber-100/70 text-amber-950 font-bold border-b border-amber-300">
                    <th className="p-2.5">Subject / Task</th>
                    <th className="p-2.5 text-center">Category</th>
                    <th className="p-2.5 text-center">Max Marks</th>
                    <th className="p-2.5 text-center">Marks Scored</th>
                    <th className="p-2.5 text-center">Grade</th>
                    <th className="p-2.5">Faculty Evaluation Remarks</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {latestReportCard.items.map((item, idx) => (
                    <tr key={idx} className="hover:bg-slate-50">
                      <td className="p-2.5 font-bold text-slate-900">{item.taskTitle}</td>
                      <td className="p-2.5 text-center capitalize text-slate-600 font-medium">
                        {item.category.replace('_', ' ')}
                      </td>
                      <td className="p-2.5 text-center font-mono font-bold text-slate-700">{item.maxMarks}</td>
                      <td className="p-2.5 text-center font-mono font-black text-indigo-700">{item.marksObtained}</td>
                      <td className="p-2.5 text-center">
                        <span className="font-bold text-xs bg-indigo-50 text-indigo-800 px-2 py-0.5 rounded border border-indigo-200">
                          {item.letterGrade}
                        </span>
                      </td>
                      <td className="p-2.5 text-slate-600 italic text-[11px]">{item.remarks}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Result Highlights */}
          <div className="bg-gradient-to-r from-amber-500/10 via-amber-500/20 to-amber-500/10 rounded-xl p-5 border border-amber-300 grid grid-cols-2 sm:grid-cols-4 gap-4 text-center my-3">
            <div>
              <span className="text-xs text-amber-900 font-semibold block">Total Marks Scored</span>
              <span className="text-xl font-black text-amber-950">
                {latestReportCard.totalMarksObtained} / {latestReportCard.totalMaxMarks}
              </span>
            </div>
            <div>
              <span className="text-xs text-amber-900 font-semibold block">Cumulative Aggregate</span>
              <span className="text-xl font-black text-amber-950">{latestReportCard.percentage}%</span>
            </div>
            <div>
              <span className="text-xs text-amber-900 font-semibold block">Final Letter Grade</span>
              <span className="text-xl font-black text-indigo-700">{latestReportCard.overallGrade}</span>
            </div>
            <div>
              <span className="text-xs text-amber-900 font-semibold block">Academic Standing</span>
              <span className="text-xl font-black text-emerald-700">{latestReportCard.overallStatus}</span>
            </div>
          </div>

          {/* Teacher Remarks */}
          <div className="py-4">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-700 block mb-1">
              Class Guru & Faculty Appraisal:
            </span>
            <div className="rounded-lg bg-slate-50 p-3.5 border border-slate-200 text-xs text-slate-800 leading-relaxed font-sans italic">
              "{latestReportCard.teacherRemarks}"
            </div>
          </div>

          {/* Signatures */}
          <div className="pt-6 mt-4 border-t-2 border-slate-200 grid grid-cols-2 sm:grid-cols-3 gap-6 items-end text-xs font-sans text-center">
            <div>
              <span className="font-bold text-slate-900 block pb-1 border-b border-slate-300">
                {latestReportCard.evaluatorName}
              </span>
              <span className="text-slate-400 text-[10px] uppercase tracking-wider mt-1 block">
                Evaluator / Lead Faculty
              </span>
            </div>

            <div className="flex flex-col items-center">
              <div className="w-14 h-14 rounded-full border-2 border-dashed border-amber-600 flex items-center justify-center text-[9px] font-bold text-amber-800 uppercase text-center p-1">
                ACCREDITED
              </div>
              <span className="text-slate-400 text-[10px] uppercase tracking-wider mt-1">Institutional Seal</span>
            </div>

            <div>
              <span className="font-bold text-slate-900 block pb-1 border-b border-slate-300">
                {latestReportCard.principalSignature}
              </span>
              <span className="text-slate-400 text-[10px] uppercase tracking-wider mt-1 block">
                Director & Principal
              </span>
            </div>
          </div>

          {/* Print button */}
          <div className="mt-6 pt-4 border-t border-slate-200 flex justify-end">
            <button
              type="button"
              onClick={() => window.print()}
              className="flex items-center gap-1.5 px-4 py-2 rounded-lg border border-slate-300 bg-white hover:bg-slate-100 text-slate-700 font-bold text-xs shadow-2xs cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print Official Report Card</span>
            </button>
          </div>
        </div>
      ) : (
        <div className="rounded-xl border border-dashed border-slate-300 bg-white p-8 text-center space-y-2">
          <Award className="w-10 h-10 text-amber-500 mx-auto" />
          <h4 className="text-sm font-bold text-slate-800">No Report Card Published Yet</h4>
          <p className="text-xs text-slate-500 max-w-md mx-auto">
            Once your teacher prepares and issues your official report card, it will appear here with your institutional seal, cumulative scores, and distinction status.
          </p>
        </div>
      )}

      {/* 2. INTERCONNECTED TASK BUNDLES & AGGREGATE SCORES */}
      {bundles.length > 0 && (
        <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-200 pb-3">
            <Link2 className="w-5 h-5 text-indigo-600" />
            <div>
              <h3 className="text-sm font-bold text-slate-900">Interconnected Assessment Bundles</h3>
              <p className="text-xs text-slate-500">
                Composite evaluation combining multiple exam components (e.g. Theory Exam + Viva)
              </p>
            </div>
          </div>

          <div className="space-y-4">
            {bundles.map(bundle => {
              const bundleTasks = tasks.filter(t => bundle.taskIds.includes(t.id));
              let totalScored = 0;
              const taskBreakdown = bundleTasks.map(bt => {
                const sub = evaluatedSubmissions.find(s => s.taskId === bt.id);
                const score = sub?.correction?.grade ?? 0;
                totalScored += score;
                return { task: bt, score, hasSub: !!sub };
              });

              const pct = bundle.totalMaxMarks > 0 
                ? Math.round((totalScored / bundle.totalMaxMarks) * 100) 
                : 0;

              return (
                <div key={bundle.id} className="rounded-xl border border-indigo-100 bg-indigo-50/40 p-4 space-y-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <h4 className="text-sm font-bold text-indigo-950">{bundle.title}</h4>
                      <p className="text-xs text-indigo-700">{bundle.description}</p>
                    </div>

                    <div className="flex items-center gap-3">
                      <div className="bg-white px-3 py-1.5 rounded-lg border border-indigo-200 text-right">
                        <span className="text-[10px] text-slate-500 block uppercase font-bold">Total Scored</span>
                        <span className="text-sm font-black text-indigo-700 font-mono">
                          {totalScored} / {bundle.totalMaxMarks} ({pct}%)
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Component Breakdown Pills */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                    {taskBreakdown.map((tb, i) => (
                      <div key={i} className="bg-white p-2.5 rounded-lg border border-slate-200 flex items-center justify-between">
                        <span className="font-semibold text-slate-800 truncate pr-2">{tb.task.title}</span>
                        <span className="font-mono font-bold text-slate-700 shrink-0">
                          {tb.hasSub ? `${tb.score} / ${tb.task.maxPoints} pts` : `Pending / ${tb.task.maxPoints} pts`}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 3. EVALUATED SUBMISSIONS & ANSWER SCRIPT VIEWER */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs space-y-4">
        <div className="flex items-center justify-between border-b border-slate-200 pb-3">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-600" />
            <div>
              <h3 className="text-sm font-bold text-slate-900">Evaluated Tasks & Corrected Answer Scripts</h3>
              <p className="text-xs text-slate-500">
                Click any assignment below to inspect the teacher’s handwritten pen corrections, stamps, and feedback.
              </p>
            </div>
          </div>

          <span className="text-xs font-bold text-slate-600 bg-slate-100 px-3 py-1 rounded-lg">
            {evaluatedSubmissions.length} Available Scripts
          </span>
        </div>

        {evaluatedSubmissions.length > 0 ? (
          <div className="divide-y divide-slate-200">
            {evaluatedSubmissions.map(sub => {
              const grade = sub.correction?.grade ?? 0;
              const max = sub.correction?.maxPoints ?? 100;
              const pct = Math.round((grade / max) * 100);

              return (
                <div key={sub.id} className="py-4 flex flex-wrap items-center justify-between gap-4 hover:bg-slate-50/80 p-2 rounded-lg transition">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <h4 className="text-sm font-bold text-slate-900">{sub.taskTitle}</h4>
                      <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-indigo-50 text-indigo-700">
                        {sub.taskType}
                      </span>
                    </div>
                    <p className="text-xs text-slate-500">
                      Evaluated by <strong>{sub.correction?.evaluatorName || 'Teacher'}</strong> · {new Date(sub.correction?.evaluatedAt || sub.submittedAt).toLocaleDateString()}
                    </p>
                    {sub.correction?.feedback && (
                      <p className="text-xs text-slate-600 italic">
                        Teacher Feedback: "{sub.correction.feedback}"
                      </p>
                    )}
                  </div>

                  <div className="flex items-center gap-4">
                    <div className="text-right font-mono">
                      <span className="text-base font-black text-indigo-700 block">
                        {grade} / {max} pts
                      </span>
                      <span className="text-xs font-bold text-slate-500">
                        {pct}% ({sub.correction?.letterGrade || 'A'})
                      </span>
                    </div>

                    <button
                      type="button"
                      onClick={() => setSelectedSubmissionForScript(sub)}
                      className="flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs px-3.5 py-2 rounded-lg shadow-xs transition cursor-pointer"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>View Corrected Answer Script</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-8 text-slate-400 text-xs italic">
            No submissions have been evaluated yet. Complete tasks in the Dashboard, Assignments, or Examination section.
          </div>
        )}
      </div>

      {/* Answer Script Viewer Modal */}
      {selectedSubmissionForScript && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-950/80 backdrop-blur-xs overflow-y-auto">
          <div className="relative w-full max-w-6xl rounded-2xl bg-white shadow-2xl border border-slate-200 overflow-hidden my-4 flex flex-col max-h-[92vh]">
            <div className="flex items-center justify-between border-b border-slate-200 bg-slate-50 px-6 py-3 shrink-0">
              <div className="flex items-center gap-2">
                <span className="font-bold text-slate-900 text-sm">
                  Corrected Answer Script: {selectedSubmissionForScript.taskTitle}
                </span>
                <span className="text-xs bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded">
                  Score: {selectedSubmissionForScript.correction?.grade} / {selectedSubmissionForScript.correction?.maxPoints} pts
                </span>
              </div>

              <button
                type="button"
                onClick={() => setSelectedSubmissionForScript(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200 transition cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-6 bg-slate-100/70">
              <CorrectionSheetViewer submission={selectedSubmissionForScript} />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
