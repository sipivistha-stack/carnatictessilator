import React, { useState } from 'react';
import { Task, Submission, StudentProfile, SubmissionPayload, InterconnectedTaskBundle, ClassGroup } from '../../types';
import { StudentsListSection } from './StudentsListSection';
import { ReportsSection } from './ReportsSection';
import { ReturnedWorkSection } from './ReturnedWorkSection';
import { ResultsPanel } from './ResultsPanel';
import { ExaminationSection } from './ExaminationSection';
import { CorrectionSheetViewer } from '../common/CorrectionSheetViewer';
import { getCurrentClass, getTaskBundles, getAnnouncements } from '../../data/storage';
import { AttendanceGateModal } from '../common/AttendanceGateModal';

// Workspaces for doing tasks
import { CodingWorkspace } from '../workspaces/CodingWorkspace';
import { McqWorkspace } from '../workspaces/McqWorkspace';
import { DocWorkspace } from '../workspaces/DocWorkspace';
import { PptWorkspace } from '../workspaces/PptWorkspace';
import { ExcelWorkspace } from '../workspaces/ExcelWorkspace';
import { DrawingWorkspace } from '../workspaces/DrawingWorkspace';
import { UploadWorkspace } from '../workspaces/UploadWorkspace';
import { TextWorkspace } from '../workspaces/TextWorkspace';
import { CarnaticMusicWorkspace } from '../workspaces/CarnaticMusicWorkspace';
import { TypingWorkspace } from '../workspaces/TypingWorkspace';

import { 
  LayoutDashboard, 
  BookOpen, 
  Users, 
  BarChart3, 
  FileCheck2, 
  Play, 
  Clock, 
  CheckCircle, 
  Sparkles, 
  Eye, 
  Award,
  ShieldCheck,
  Music,
  Keyboard,
  CheckCircle2,
  X,
  Megaphone,
  AlertTriangle,
  Pin,
  Info
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface StudentDashboardProps {
  tasks: Task[];
  submissions: Submission[];
  students: StudentProfile[];
  currentStudent: StudentProfile;
  onSelectStudent: (student: StudentProfile) => void;
  onCustomStudentName: (name: string) => void;
  onSubmitTask: (submission: Submission) => void;
}

export const StudentDashboard: React.FC<StudentDashboardProps> = ({
  tasks,
  submissions,
  students,
  currentStudent,
  onSelectStudent,
  onCustomStudentName,
  onSubmitTask,
}) => {
  const [activeSection, setActiveSection] = useState<
    'dashboard' | 'assignments' | 'examinations' | 'results' | 'students' | 'reports' | 'returned' | 'announcements'
  >('dashboard');

  const [activeTaskToExecute, setActiveTaskToExecute] = useState<Task | null>(null);
  const [selectedReturnedSub, setSelectedReturnedSub] = useState<Submission | null>(null);
  const [barredExamTask, setBarredExamTask] = useState<Task | null>(null);

  const currentClass = getCurrentClass();
  const bundles = getTaskBundles();
  const announcements = getAnnouncements(currentClass.id);
  const topAnnouncement = announcements.find(a => a.pinned || a.priority === 'exam_alert') || announcements[0];

  const studentAttendance = currentStudent.attendancePercentage ?? 85;
  const isEligibleForExam = studentAttendance >= 75;

  // Temporary Tasks for Dashboard Section
  const temporaryTasks = tasks.filter(
    t => t.category === 'temporary_task' && t.status === 'active'
  );

  // Assignments Section
  const assignments = tasks.filter(
    t => t.category === 'assignment' && t.status === 'active'
  );

  // Submissions by this student
  const studentSubs = submissions.filter(
    s => s.studentId === currentStudent.id || s.studentName.toLowerCase() === currentStudent.name.toLowerCase()
  );

  const isTaskSubmittedByMe = (taskId: string) => {
    return studentSubs.find(s => s.taskId === taskId);
  };

  const handleOpenTask = (task: Task) => {
    if (task.category === 'examination' && !isEligibleForExam) {
      setBarredExamTask(task);
      return;
    }
    setActiveTaskToExecute(task);
  };

  const handleTaskSubmit = (payload: SubmissionPayload) => {
    if (!activeTaskToExecute) return;

    const newSubmission: Submission = {
      id: 'sub-' + Date.now(),
      taskId: activeTaskToExecute.id,
      taskTitle: activeTaskToExecute.title,
      taskType: activeTaskToExecute.type,
      taskCategory: activeTaskToExecute.category,
      studentId: currentStudent.id,
      studentName: currentStudent.name,
      submittedAt: new Date().toISOString(),
      status: 'submitted',
      payload,
    };

    onSubmitTask(newSubmission);
    confetti({
      particleCount: 75,
      spread: 70,
      origin: { y: 0.6 },
    });
    setActiveTaskToExecute(null);
  };

  return (
    <div className="space-y-6">
      {/* Student Welcome Banner */}
      <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div 
              className="w-14 h-14 rounded-2xl flex items-center justify-center text-white font-bold text-xl shadow-md"
              style={{ backgroundColor: currentStudent.avatarColor || '#3b82f6' }}
            >
              {currentStudent.name.slice(0, 2).toUpperCase()}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold uppercase tracking-wider text-indigo-700 bg-indigo-50 px-2.5 py-0.5 rounded-full">
                  Student Learning Portal
                </span>
                <span className="text-xs text-slate-500 font-mono">
                  Roll: {currentStudent.rollNo} · {currentClass.name}
                </span>
              </div>
              <h1 className="text-2xl font-black text-slate-900 mt-1">
                Namaste, {currentStudent.name}!
              </h1>
              <p className="text-xs text-slate-500 mt-0.5">
                Complete assigned Carnatic music tasks, submit coursework, take formal examinations, and view your official report cards.
              </p>

              {/* Attendance Eligibility Pill */}
              <div className="flex flex-wrap items-center gap-2 mt-2">
                <span className={`px-2.5 py-1 rounded-full text-xs font-bold font-mono inline-flex items-center gap-1.5 shadow-2xs ${
                  isEligibleForExam
                    ? 'bg-emerald-100 text-emerald-900 border border-emerald-300'
                    : 'bg-rose-100 text-rose-900 border border-rose-300 animate-pulse'
                }`}>
                  {isEligibleForExam ? (
                    <>
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Attendance: {studentAttendance}% (Exam Eligible ≥75%)</span>
                    </>
                  ) : (
                    <>
                      <AlertTriangle className="w-3.5 h-3.5 text-rose-600" />
                      <span>Attendance: {studentAttendance}% (Barred from Exam &lt;75%)</span>
                    </>
                  )}
                </span>
                {!isEligibleForExam && (
                  <button
                    type="button"
                    onClick={() => setBarredExamTask(tasks.find(t => t.category === 'examination') || null)}
                    className="text-[11px] font-bold text-rose-700 bg-rose-50 hover:bg-rose-100 px-2 py-0.5 rounded border border-rose-200 cursor-pointer"
                  >
                    View 75% Rule Notice →
                  </button>
                )}
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => setActiveSection('announcements')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-50 text-amber-900 border border-amber-300 font-bold text-xs hover:bg-amber-100 cursor-pointer shadow-2xs"
            >
              <Megaphone className="w-3.5 h-3.5 text-amber-600" />
              <span>Notices ({announcements.length})</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveSection('examinations')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-50 text-indigo-900 border border-indigo-200 font-bold text-xs hover:bg-indigo-100 cursor-pointer shadow-2xs"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-indigo-600" />
              <span>Examination Hall</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveSection('results')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-purple-50 text-purple-900 border border-purple-200 font-bold text-xs hover:bg-purple-100 cursor-pointer shadow-2xs"
            >
              <Award className="w-3.5 h-3.5 text-purple-600" />
              <span>Results & Report Card</span>
            </button>
          </div>
        </div>

        {/* Top Priority Announcement Banner */}
        {topAnnouncement && (
          <div className={`mt-4 rounded-xl border p-4 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-3 ${
            topAnnouncement.priority === 'exam_alert'
              ? 'bg-rose-50 border-rose-300 text-rose-950'
              : topAnnouncement.priority === 'important'
              ? 'bg-amber-50 border-amber-300 text-amber-950'
              : 'bg-blue-50 border-blue-200 text-blue-950'
          }`}>
            <div className="flex items-start gap-3">
              <div className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold shrink-0 shadow-xs ${
                topAnnouncement.priority === 'exam_alert' ? 'bg-rose-600 text-white' :
                topAnnouncement.priority === 'important' ? 'bg-amber-600 text-white' :
                'bg-blue-600 text-white'
              }`}>
                <Megaphone className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <span className={`text-[10px] uppercase font-black px-2 py-0.5 rounded-full border font-mono ${
                    topAnnouncement.priority === 'exam_alert' ? 'bg-rose-100 text-rose-900 border-rose-300' :
                    topAnnouncement.priority === 'important' ? 'bg-amber-100 text-amber-900 border-amber-300' :
                    'bg-blue-100 text-blue-900 border-blue-300'
                  }`}>
                    {topAnnouncement.priority.replace('_', ' ')}
                  </span>
                  <span className="text-xs font-bold text-slate-900">{topAnnouncement.title}</span>
                </div>
                <p className="text-xs text-slate-700 mt-1 line-clamp-2 leading-relaxed">
                  {topAnnouncement.content}
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setActiveSection('announcements')}
              className="whitespace-nowrap px-3.5 py-1.5 rounded-xl bg-white border border-slate-300 hover:bg-slate-50 font-bold text-xs text-slate-800 shadow-2xs cursor-pointer self-end md:self-center"
            >
              All Circulars ({announcements.length}) →
            </button>
          </div>
        )}

        {/* Section Navigation Tabs */}
        <div className="flex flex-wrap items-center gap-1.5 mt-6 pt-5 border-t border-slate-100 text-xs">
          <button
            type="button"
            onClick={() => setActiveSection('dashboard')}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl font-bold transition cursor-pointer ${
              activeSection === 'dashboard' ? 'bg-indigo-600 text-white shadow-xs' : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <LayoutDashboard className="w-4 h-4" />
            <span>Dashboard (Temporary Tasks)</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveSection('assignments')}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl font-bold transition cursor-pointer ${
              activeSection === 'assignments' ? 'bg-indigo-600 text-white shadow-xs' : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>Assignments Section ({assignments.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveSection('examinations')}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl font-bold transition cursor-pointer ${
              activeSection === 'examinations' ? 'bg-indigo-600 text-white shadow-xs' : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <ShieldCheck className="w-4 h-4" />
            <span>Examination Section</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveSection('announcements')}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl font-bold transition cursor-pointer ${
              activeSection === 'announcements' ? 'bg-amber-600 text-white shadow-xs' : 'text-amber-900 bg-amber-50 hover:bg-amber-100 border border-amber-200'
            }`}
          >
            <Megaphone className="w-4 h-4" />
            <span>Announcements ({announcements.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveSection('results')}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl font-bold transition cursor-pointer ${
              activeSection === 'results' ? 'bg-purple-600 text-white shadow-xs' : 'text-purple-900 bg-purple-50 hover:bg-purple-100 border border-purple-200'
            }`}
          >
            <Award className="w-4 h-4" />
            <span>Results & Report Card</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveSection('students')}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl font-bold transition cursor-pointer ${
              activeSection === 'students' ? 'bg-indigo-600 text-white shadow-xs' : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>Classmates Roster (15 Indian Students)</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveSection('reports')}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl font-bold transition cursor-pointer ${
              activeSection === 'reports' ? 'bg-indigo-600 text-white shadow-xs' : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <BarChart3 className="w-4 h-4" />
            <span>Reports</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveSection('returned')}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl font-bold transition cursor-pointer ${
              activeSection === 'returned' ? 'bg-indigo-600 text-white shadow-xs' : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <FileCheck2 className="w-4 h-4" />
            <span>Returned Work</span>
          </button>
        </div>
      </div>

      {/* SECTION 1: DASHBOARD (TEMPORARY TASKS) */}
      {activeSection === 'dashboard' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-slate-900">Live Temporary Tasks</h2>
              <p className="text-xs text-slate-500">
                Tasks actively broadcast by your instructor. Stopped tasks are automatically removed.
              </p>
            </div>
            <span className="text-xs font-bold text-indigo-700 bg-indigo-50 px-2.5 py-1 rounded-md">
              {temporaryTasks.length} Live Tasks
            </span>
          </div>

          {temporaryTasks.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {temporaryTasks.map(task => {
                const mySub = isTaskSubmittedByMe(task.id);
                return (
                  <div
                    key={task.id}
                    className="p-5 rounded-2xl border border-slate-200 bg-white shadow-2xs hover:shadow-xs transition flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-100 text-xs">
                        <span className="font-bold text-indigo-600 uppercase tracking-wider text-[10px]">
                          {task.type}
                        </span>
                        <span className="font-mono font-bold text-slate-700">{task.maxPoints} pts</span>
                      </div>
                      <h3 className="text-sm font-bold text-slate-900">{task.title}</h3>
                      <p className="text-xs text-slate-500 mt-1 line-clamp-3">{task.description}</p>
                    </div>

                    <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-between">
                      {mySub ? (
                        <div className="flex items-center gap-1.5 text-xs text-emerald-700 font-semibold">
                          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                          <span>Submitted</span>
                        </div>
                      ) : (
                        <button
                          type="button"
                          onClick={() => handleOpenTask(task)}
                          className="flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs px-3.5 py-2 rounded-xl shadow-xs transition active:scale-95 cursor-pointer"
                        >
                          <Play className="w-3.5 h-3.5 fill-current" />
                          <span>Do Task Now</span>
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="rounded-xl border border-dashed border-slate-300 bg-white p-10 text-center space-y-1">
              <Clock className="w-8 h-8 text-slate-400 mx-auto" />
              <h4 className="text-sm font-bold text-slate-700">No Temporary Tasks Active</h4>
              <p className="text-xs text-slate-400 max-w-sm mx-auto">
                Your teacher has not activated any temporary tasks right now. Check back during live sessions.
              </p>
            </div>
          )}
        </div>
      )}

      {/* SECTION 2: ASSIGNMENTS */}
      {activeSection === 'assignments' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-slate-900">Regular Coursework Assignments</h2>
              <p className="text-xs text-slate-500">Complete assignments before the specified due dates.</p>
            </div>
            <span className="text-xs font-bold text-blue-700 bg-blue-50 px-2.5 py-1 rounded-md">
              {assignments.length} Assignments
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {assignments.map(task => {
              const mySub = isTaskSubmittedByMe(task.id);
              return (
                <div
                  key={task.id}
                  className="p-5 rounded-2xl border border-slate-200 bg-white shadow-2xs hover:shadow-xs transition flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-100 text-xs">
                      <span className="font-bold text-blue-600 uppercase tracking-wider text-[10px]">
                        {task.type}
                      </span>
                      <span className="font-mono font-bold text-slate-700">{task.maxPoints} pts</span>
                    </div>
                    <h3 className="text-sm font-bold text-slate-900">{task.title}</h3>
                    <p className="text-xs text-slate-500 mt-1 line-clamp-3">{task.description}</p>
                    {task.dueDate && (
                      <p className="text-[11px] text-slate-400 mt-2 font-mono">
                        Due: {new Date(task.dueDate).toLocaleDateString()}
                      </p>
                    )}
                  </div>

                  <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-between">
                    {mySub ? (
                      <span className="text-xs text-emerald-700 font-bold flex items-center gap-1">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                        <span>Submitted</span>
                      </span>
                    ) : (
                      <button
                        type="button"
                        onClick={() => handleOpenTask(task)}
                        className="flex items-center gap-1.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs px-3.5 py-2 rounded-xl shadow-xs transition active:scale-95 cursor-pointer"
                      >
                        <Play className="w-3.5 h-3.5 fill-current" />
                        <span>Start Assignment</span>
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* SECTION 3: EXAMINATION SECTION */}
      {activeSection === 'examinations' && (
        <ExaminationSection
          tasks={tasks}
          submissions={submissions}
          currentStudent={currentStudent}
          onOpenWorkspace={handleOpenTask}
          onViewResults={() => setActiveSection('results')}
        />
      )}

      {/* SECTION: ANNOUNCEMENTS BULLETIN */}
      {activeSection === 'announcements' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-200">
            <div>
              <h2 className="text-base font-bold text-slate-900">Faculty Announcements & Circulars</h2>
              <p className="text-xs text-slate-500">Official circulars, examination eligibility notices, and assignment guidance.</p>
            </div>
            <span className="text-xs font-bold text-amber-800 bg-amber-50 border border-amber-200 px-2.5 py-1 rounded-md">
              {announcements.length} Active Circulars
            </span>
          </div>

          <div className="space-y-3">
            {announcements.map(ann => {
              const isExamAlert = ann.priority === 'exam_alert';
              const isImportant = ann.priority === 'important';

              return (
                <div
                  key={ann.id}
                  className={`p-5 rounded-2xl border transition shadow-xs ${
                    isExamAlert
                      ? 'bg-rose-50/70 border-rose-300'
                      : isImportant
                      ? 'bg-amber-50/70 border-amber-300'
                      : 'bg-white border-slate-200'
                  }`}
                >
                  <div className="flex flex-wrap items-center justify-between gap-2 pb-3 mb-2 border-b border-slate-200/80">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider flex items-center gap-1 ${
                        isExamAlert ? 'bg-rose-600 text-white' :
                        isImportant ? 'bg-amber-600 text-white' :
                        'bg-blue-600 text-white'
                      }`}>
                        {isExamAlert ? <AlertTriangle className="w-3 h-3" /> :
                         isImportant ? <Megaphone className="w-3 h-3" /> :
                         <Info className="w-3 h-3" />}
                        <span>{ann.priority.replace('_', ' ')}</span>
                      </span>

                      {ann.pinned && (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-300 flex items-center gap-1">
                          <Pin className="w-3 h-3 text-amber-700" />
                          <span>Pinned Notice</span>
                        </span>
                      )}

                      <span className="text-[11px] text-slate-500 font-mono">
                        {new Date(ann.postedAt).toLocaleString()}
                      </span>
                    </div>

                    <span className="text-[11px] text-slate-500 font-medium">
                      Issued by: <strong>{ann.postedBy}</strong>
                    </span>
                  </div>

                  <h3 className="text-sm font-bold text-slate-900 leading-snug">
                    {ann.title}
                  </h3>

                  <p className="text-xs text-slate-700 mt-2 leading-relaxed whitespace-pre-wrap">
                    {ann.content}
                  </p>

                  {ann.tags && ann.tags.length > 0 && (
                    <div className="flex items-center gap-1 flex-wrap mt-3 pt-3 border-t border-slate-200/60">
                      {ann.tags.map((tg, idx) => (
                        <span key={idx} className="bg-slate-200/80 text-slate-700 px-2 py-0.5 rounded font-mono text-[10px]">
                          #{tg}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* SECTION 4: RESULTS & OFFICIAL REPORT CARDS */}
      {activeSection === 'results' && (
        <ResultsPanel
          currentStudent={currentStudent}
          tasks={tasks}
          submissions={submissions}
          bundles={bundles}
          currentClass={currentClass}
        />
      )}

      {/* SECTION 5: STUDENTS LIST (15 INDIAN STUDENTS) */}
      {activeSection === 'students' && (
        <StudentsListSection
          students={students}
          submissions={submissions}
          currentStudent={currentStudent}
          onSelectStudent={onSelectStudent}
          onCustomStudentName={onCustomStudentName}
        />
      )}

      {/* SECTION 6: REPORTS */}
      {activeSection === 'reports' && (
        <ReportsSection
          currentStudent={currentStudent}
          tasks={tasks}
          submissions={submissions}
          onOpenCorrectionSheet={(sub) => setSelectedReturnedSub(sub)}
        />
      )}

      {/* SECTION 7: RETURNED WORK (CORRECTION SHEETS) */}
      {activeSection === 'returned' && (
        <ReturnedWorkSection
          currentStudent={currentStudent}
          submissions={submissions}
        />
      )}

      {/* ACTIVE WORKSPACE MODAL (Supports Carnatic Music, Typing, Word, PPT, Coding, etc.) */}
      {activeTaskToExecute && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-950/80 backdrop-blur-xs overflow-y-auto">
          <div className="relative w-full max-w-6xl rounded-2xl bg-white shadow-2xl border border-slate-200 overflow-hidden my-4 flex flex-col max-h-[92vh]">
            <div className="flex items-center justify-between border-b border-slate-200 bg-slate-50 px-6 py-3 shrink-0">
              <div className="flex items-center gap-2">
                <span className="font-bold text-slate-900 text-sm">
                  {activeTaskToExecute.title}
                </span>
                <span className="text-xs bg-indigo-100 text-indigo-800 font-bold px-2 py-0.5 rounded uppercase">
                  {activeTaskToExecute.type.replace('_', ' ')}
                </span>
              </div>
              <button
                type="button"
                onClick={() => setActiveTaskToExecute(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200 transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-6 bg-slate-100/70">
              {activeTaskToExecute.type === 'carnatic_music' ? (
                <CarnaticMusicWorkspace
                  task={activeTaskToExecute}
                  onSubmit={handleTaskSubmit}
                  onCancel={() => setActiveTaskToExecute(null)}
                />
              ) : activeTaskToExecute.type === 'typing_exam' ? (
                <TypingWorkspace
                  task={activeTaskToExecute}
                  onSubmit={handleTaskSubmit}
                  onCancel={() => setActiveTaskToExecute(null)}
                />
              ) : activeTaskToExecute.type === 'word_doc' ? (
                <DocWorkspace
                  task={activeTaskToExecute}
                  onSubmit={handleTaskSubmit}
                  onCancel={() => setActiveTaskToExecute(null)}
                />
              ) : activeTaskToExecute.type === 'ppt' ? (
                <PptWorkspace
                  task={activeTaskToExecute}
                  onSubmit={handleTaskSubmit}
                  onCancel={() => setActiveTaskToExecute(null)}
                />
              ) : activeTaskToExecute.type === 'coding' ? (
                <CodingWorkspace
                  task={activeTaskToExecute}
                  onSubmit={handleTaskSubmit}
                  onCancel={() => setActiveTaskToExecute(null)}
                />
              ) : activeTaskToExecute.type === 'mcq' || activeTaskToExecute.type === 'quiz' ? (
                <McqWorkspace
                  task={activeTaskToExecute}
                  onSubmit={handleTaskSubmit}
                  onCancel={() => setActiveTaskToExecute(null)}
                />
              ) : activeTaskToExecute.type === 'excel' ? (
                <ExcelWorkspace
                  task={activeTaskToExecute}
                  onSubmit={handleTaskSubmit}
                  onCancel={() => setActiveTaskToExecute(null)}
                />
              ) : activeTaskToExecute.type === 'drawing' ? (
                <DrawingWorkspace
                  task={activeTaskToExecute}
                  onSubmit={handleTaskSubmit}
                  onCancel={() => setActiveTaskToExecute(null)}
                />
              ) : activeTaskToExecute.type === 'upload' || activeTaskToExecute.type === 'image' || activeTaskToExecute.type === 'video' ? (
                <UploadWorkspace
                  task={activeTaskToExecute}
                  onSubmit={handleTaskSubmit}
                  onCancel={() => setActiveTaskToExecute(null)}
                />
              ) : (
                <TextWorkspace
                  task={activeTaskToExecute}
                  onSubmit={handleTaskSubmit}
                  onCancel={() => setActiveTaskToExecute(null)}
                />
              )}
            </div>
          </div>
        </div>
      )}

      {/* RETURNED WORK CORRECTION SHEET MODAL */}
      {selectedReturnedSub && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-950/80 backdrop-blur-xs overflow-y-auto">
          <div className="relative w-full max-w-6xl rounded-2xl bg-white shadow-2xl border border-slate-200 overflow-hidden my-4 flex flex-col max-h-[92vh]">
            <div className="flex items-center justify-between border-b border-slate-200 bg-slate-50 px-6 py-3 shrink-0">
              <span className="font-bold text-slate-900 text-sm">
                Correction Sheet: {selectedReturnedSub.taskTitle}
              </span>
              <button
                type="button"
                onClick={() => setSelectedReturnedSub(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200 transition cursor-pointer"
              >
                ✕
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-6 bg-slate-100/70">
              <CorrectionSheetViewer submission={selectedReturnedSub} />
            </div>
          </div>
        </div>
      )}

      {/* ATTENDANCE GATE MODAL (75% Attendance Requirement) */}
      {barredExamTask && (
        <AttendanceGateModal
          student={currentStudent}
          examTask={barredExamTask}
          onClose={() => setBarredExamTask(null)}
        />
      )}
    </div>
  );
};
