import React, { useState, useMemo } from 'react';
import { Task, SubmissionPayload } from '../../types';
import { Table, FunctionSquare, Send, Check } from 'lucide-react';

interface ExcelWorkspaceProps {
  task: Task;
  onSubmit: (payload: SubmissionPayload) => void;
  onCancel: () => void;
}

const COLS = ['A', 'B', 'C', 'D', 'E', 'F'];
const ROWS = Array.from({ length: 12 }, (_, i) => i + 1);

export const ExcelWorkspace: React.FC<ExcelWorkspaceProps> = ({
  task,
  onSubmit,
  onCancel,
}) => {
  // Initialize grid from task sampleRows or empty
  const [data, setData] = useState<Record<string, string>>(() => {
    const initial: Record<string, string> = {};
    if (task.excelConfig?.headers) {
      task.excelConfig.headers.forEach((h, idx) => {
        if (COLS[idx]) initial[`${COLS[idx]}1`] = h;
      });
    }
    if (task.excelConfig?.sampleRows) {
      task.excelConfig.sampleRows.forEach((row, rIdx) => {
        const rowNum = rIdx + 2;
        row.forEach((val, cIdx) => {
          if (COLS[cIdx]) initial[`${COLS[cIdx]}${rowNum}`] = val;
        });
      });
    }
    return initial;
  });

  const [activeCell, setActiveCell] = useState<string>('A1');
  const [formulaValue, setFormulaValue] = useState<string>(data['A1'] || '');

  const handleCellSelect = (cellKey: string) => {
    setActiveCell(cellKey);
    setFormulaValue(data[cellKey] || '');
  };

  const handleCellChange = (cellKey: string, val: string) => {
    setData(prev => ({ ...prev, [cellKey]: val }));
    if (cellKey === activeCell) {
      setFormulaValue(val);
    }
  };

  const handleFormulaInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setFormulaValue(val);
    setData(prev => ({ ...prev, [activeCell]: val }));
  };

  // Evaluate formula: evaluates =SUM(A1:A5), =AVERAGE, or =B2*C2
  const computedData = useMemo(() => {
    const result: Record<string, string> = {};

    const getRawNumeric = (cellKey: string): number => {
      const v = data[cellKey];
      if (!v) return 0;
      if (v.startsWith('=')) return Number(result[cellKey]) || 0;
      const num = parseFloat(v.replace(/[^0-9.-]+/g, ''));
      return isNaN(num) ? 0 : num;
    };

    // First pass for static values
    Object.keys(data).forEach(k => {
      if (!data[k].startsWith('=')) {
        result[k] = data[k];
      }
    });

    // Second pass for formulas
    Object.keys(data).forEach(k => {
      const expr = data[k];
      if (expr.startsWith('=')) {
        const formula = expr.slice(1).trim().toUpperCase();

        // Handle SUM(A2:A5)
        const sumMatch = formula.match(/SUM\(([A-F][0-9]+):([A-F][0-9]+)\)/);
        if (sumMatch) {
          const startCol = sumMatch[1].charAt(0);
          const startRow = parseInt(sumMatch[1].slice(1));
          const endCol = sumMatch[2].charAt(0);
          const endRow = parseInt(sumMatch[2].slice(1));

          let sum = 0;
          for (let r = startRow; r <= endRow; r++) {
            const cell = `${startCol}${r}`;
            sum += getRawNumeric(cell);
          }
          result[k] = String(sum);
          return;
        }

        // Handle AVERAGE(A2:A5)
        const avgMatch = formula.match(/AVERAGE\(([A-F][0-9]+):([A-F][0-9]+)\)/);
        if (avgMatch) {
          const startCol = avgMatch[1].charAt(0);
          const startRow = parseInt(avgMatch[1].slice(1));
          const endRow = parseInt(avgMatch[2].slice(1));
          let sum = 0;
          let count = 0;
          for (let r = startRow; r <= endRow; r++) {
            sum += getRawNumeric(`${startCol}${r}`);
            count++;
          }
          result[k] = count > 0 ? (sum / count).toFixed(2) : '0';
          return;
        }

        // Handle simple arithmetic: e.g. B2*C2 or A1+B1
        try {
          let replaced = formula;
          // replace cell references like B2, C3 with numeric values
          replaced = replaced.replace(/([A-F][0-9]+)/g, (_, cellRef) => {
            return String(getRawNumeric(cellRef));
          });
          const evalRes = Function(`"use strict"; return (${replaced});`)();
          result[k] = String(evalRes);
        } catch {
          result[k] = '#VALUE!';
        }
      }
    });

    return result;
  }, [data]);

  const handleSubmit = () => {
    const payload: SubmissionPayload = {
      sheetData: data,
    };
    onSubmit(payload);
  };

  return (
    <div className="flex flex-col gap-4 max-w-5xl mx-auto">
      {/* Header */}
      <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs flex flex-wrap items-center justify-between gap-3">
        <div>
          <span className="text-xs font-semibold px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 uppercase tracking-wide">
            Excel Spreadsheet Assignment
          </span>
          <h2 className="text-base font-bold text-slate-900 mt-1">{task.title}</h2>
          <p className="text-xs text-slate-500">{task.excelConfig?.prompt || task.description}</p>
        </div>

        <div className="text-xs text-slate-500 bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200">
          Formulas supported: <code>=SUM(A1:A5)</code>, <code>=AVERAGE(A1:A5)</code>, <code>=B2*C2</code>
        </div>
      </div>

      {/* Formula Bar */}
      <div className="flex items-center gap-2 rounded-xl border border-slate-300 bg-white p-2 shadow-xs">
        <div className="flex items-center gap-1.5 px-3 py-1 bg-slate-100 rounded text-xs font-mono font-bold text-slate-700 w-16 justify-center">
          {activeCell}
        </div>
        <div className="h-5 w-px bg-slate-200"></div>
        <div className="flex items-center gap-2 flex-1">
          <FunctionSquare className="w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={formulaValue}
            onChange={handleFormulaInputChange}
            placeholder="Type value or formula (e.g. =SUM(B2:B5))..."
            className="w-full text-xs font-mono text-slate-800 bg-transparent focus:outline-hidden"
          />
        </div>
      </div>

      {/* Spreadsheet Grid */}
      <div className="rounded-xl border border-slate-300 bg-white overflow-x-auto shadow-xs">
        <table className="w-full border-collapse text-xs">
          <thead>
            <tr className="bg-slate-100 text-slate-700 select-none">
              <th className="w-12 border-b border-r border-slate-300 p-2 text-center font-mono font-bold bg-slate-200/70">
                #
              </th>
              {COLS.map(col => (
                <th
                  key={col}
                  className="border-b border-r border-slate-300 p-2 text-center font-mono font-bold w-36"
                >
                  {col}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {ROWS.map(row => (
              <tr key={row} className="border-b border-slate-200">
                {/* Row number header */}
                <td className="w-12 border-r border-slate-300 bg-slate-100 p-2 text-center font-mono font-bold text-slate-500 select-none">
                  {row}
                </td>

                {/* Cells */}
                {COLS.map(col => {
                  const cellKey = `${col}${row}`;
                  const isSelected = activeCell === cellKey;
                  const displayVal = computedData[cellKey] !== undefined ? computedData[cellKey] : '';
                  const isFormula = (data[cellKey] || '').startsWith('=');

                  return (
                    <td
                      key={col}
                      onClick={() => handleCellSelect(cellKey)}
                      className={`border-r border-slate-200 p-0 relative transition cursor-cell ${
                        isSelected ? 'ring-2 ring-emerald-500 bg-emerald-50/30 z-10' : 'hover:bg-slate-50'
                      }`}
                    >
                      <input
                        type="text"
                        value={isSelected ? data[cellKey] || '' : displayVal}
                        onChange={e => handleCellChange(cellKey, e.target.value)}
                        onFocus={() => handleCellSelect(cellKey)}
                        className={`w-full h-full p-2 font-mono text-xs bg-transparent focus:outline-hidden text-right ${
                          isFormula ? 'font-semibold text-emerald-700' : 'text-slate-800'
                        }`}
                      />
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Action Footer */}
      <div className="flex items-center justify-between rounded-xl border border-slate-200 bg-white p-4 shadow-xs">
        <button
          type="button"
          onClick={onCancel}
          className="rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50"
        >
          Cancel
        </button>

        <button
          type="button"
          onClick={handleSubmit}
          className="flex items-center gap-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2 text-xs font-bold shadow-xs transition active:scale-95"
        >
          <Send className="w-3.5 h-3.5" />
          <span>Submit Spreadsheet to Teacher</span>
        </button>
      </div>
    </div>
  );
};
