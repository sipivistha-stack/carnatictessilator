import React, { useState } from 'react';
import { Task, SubmissionPayload } from '../../types';
import { parsePdfPages } from '../../services/pdfHelper';
import { parseDocxPages } from '../../services/docxParser';
import { 
  UploadCloud, 
  File, 
  Image, 
  Video, 
  CheckCircle, 
  Send, 
  X, 
  FileText, 
  Presentation, 
  FileSpreadsheet,
  Sparkles,
  Loader2,
  Layers
} from 'lucide-react';

interface UploadWorkspaceProps {
  task: Task;
  onSubmit: (payload: SubmissionPayload) => void;
  onCancel: () => void;
}

export const UploadWorkspace: React.FC<UploadWorkspaceProps> = ({
  task,
  onSubmit,
  onCancel,
}) => {
  const [file, setFile] = useState<{
    name: string;
    type: string;
    size: string;
    dataUrl: string;
    format: 'pdf' | 'word' | 'ppt' | 'odf' | 'image' | 'video' | 'other';
    documentPages?: { 
      pageNumber: number; 
      title?: string; 
      subtitle?: string; 
      content: string;
      dataUrl?: string;
      width?: number;
      height?: number;
    }[];
  } | null>(null);

  const [notes, setNotes] = useState<string>('');
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [isParsing, setIsParsing] = useState<boolean>(false);
  const [parsingStatus, setParsingStatus] = useState<string>('');

  const detectFormat = (fileName: string, mimeType: string): 'pdf' | 'word' | 'ppt' | 'odf' | 'image' | 'video' | 'other' => {
    const lower = fileName.toLowerCase();
    if (lower.endsWith('.pdf') || mimeType.includes('pdf')) return 'pdf';
    if (lower.endsWith('.docx') || lower.endsWith('.doc') || mimeType.includes('word')) return 'word';
    if (lower.endsWith('.pptx') || lower.endsWith('.ppt') || mimeType.includes('presentation')) return 'ppt';
    if (lower.endsWith('.odt') || lower.endsWith('.odp') || lower.endsWith('.ods')) return 'odf';
    if (mimeType.includes('image') || lower.endsWith('.png') || lower.endsWith('.jpg') || lower.endsWith('.jpeg')) return 'image';
    if (mimeType.includes('video') || lower.endsWith('.mp4') || lower.endsWith('.mov')) return 'video';
    return 'other';
  };

  const handleFile = async (f: File) => {
    const format = detectFormat(f.name, f.type || '');
    setIsParsing(true);
    setParsingStatus(`Opening ${f.name}…`);

    try {
      let pages: any = undefined;
      const dataUrl = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result || ''));
        reader.onerror = () => reject(new Error('The browser could not read this file.'));
        reader.readAsDataURL(f);
      });

      if (format === 'pdf') {
        setParsingStatus('Analyzing PDF structure and extracting all pages…');
        pages = await parsePdfPages(dataUrl, f.name);
      } else if (format === 'word') {
        setParsingStatus('Reading the uploaded Word document…');
        pages = await parseDocxPages(f);
      }

      setFile({
        name: f.name,
        type: f.type || 'application/octet-stream',
        size: `${(f.size / 1024).toFixed(1)} KB`,
        dataUrl,
        format,
        documentPages: pages,
      });
      setParsingStatus(format === 'word' ? `Imported ${pages?.length || 0} Word page section(s).` : 'File loaded successfully.');
    } catch (err) {
      console.error('Error reading uploaded file:', err);
      setFile(null);
      setParsingStatus('The file could not be read.');
      alert(err instanceof Error ? err.message : 'Unable to read this file.');
    } finally {
      setIsParsing(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  // Quick Preset Sample: Complete 10-Page Research Thesis
  const loadSample10PagePdf = () => {
    const tenPages = [
      {
        pageNumber: 1,
        title: 'Quantum Logic Gate Realization & Multi-Qubit Fidelity Analysis',
        subtitle: 'Page 1 of 10 · Executive Abstract, Project Scope & Nomenclature',
        content: `Abstract:\nThis 10-page thesis presents empirical laboratory findings regarding superconducting transmon qubits operated in a dilution refrigerator environment. We systematically investigate single-qubit Clifford gate fidelities and two-qubit entanglement dynamics using randomized benchmarking protocols.\n\n1. Introduction & Theoretical Motivation:\nSolid-state quantum computation requires balancing gate execution speed against environmental decoherence. Microwave drive lines and dispersive readout resonators allow non-destructive quantum state measurements.\n\nKey Parameters Investigated:\n• Base temperature: T_base = 12.4 mK\n• Transmon charging energy: E_C = 280 MHz\n• Josephson energy: E_J / E_C = 74.2\n• Readout cavity frequency: omega_r = 7.12 GHz`
      },
      {
        pageNumber: 2,
        title: 'Theoretical Formalism & Hamiltonian Evolution',
        subtitle: 'Page 2 of 10 · Mathematical Framework of the Transmon Regime',
        content: `2. Qubit Hamiltonian Formulation:\nThe transmon qubit is modeled by the standard multi-level Hamiltonian:\nH = 4*E_C*(n - n_g)^2 - E_J*cos(phi)\n\nIn the weakly anharmonic approximation, this evolves into a Duffing oscillator:\nH / hbar = omega_01 * a_dagger * a + (alpha / 2) * a_dagger^2 * a^2\n\nWhere alpha = -E_C represents the negative anharmonicity parameter essential for addressing the computational subspace {|0>, |1>} without leaking into higher leakage states {|2>, |3>}.\n\nNumerical simulation demonstrates that spectral leakage remains below 0.04% for pulse envelopes exceeding 16 ns width.`
      },
      {
        pageNumber: 3,
        title: 'Cryogenic Apparatus & Microwave Attenuation Scheme',
        subtitle: 'Page 3 of 10 · Experimental Instrumentation & Thermal Shielding',
        content: `3. Cryogenic Configuration & Shielding:\nThe experimental device was mounted within an Oxford Instruments Triton dilution refrigerator. Cryostat stage breakdown:\n• Room Temperature (300 K): FPGA pulse synthesis and DAC/ADC conversion\n• 50 K Stage: 20 dB thermal attenuators, stainless steel coaxial cabling\n• 4 K Stage: High-electron-mobility transistor (HEMT) amplifiers with 38 dB gain\n• 100 mK Still Stage: Low-pass reflective filtering\n• Base Plate (12.4 mK): Cryoperm magnetic shielding and infrared absorptive filters\n\nThermal photon population on the drive line was benchmarked at n_th < 0.008 photons/mode, mitigating spurious dephasing.`
      },
      {
        pageNumber: 4,
        title: 'Rabi Oscillations & Single-Qubit Gate Calibration',
        subtitle: 'Page 4 of 10 · Pulse Amplitude Tuning & Quadrature Optimization',
        content: `4. Rabi Flopping & Pi-Pulse Calibration:\nA continuous-wave microwave signal resonant with omega_01 was applied with variable duration tau from 0 to 200 ns. The excited state population P_1 exhibited damped sinusoidal oscillation:\nP_1(tau) = 0.5 * [1 - exp(-tau / T_decay) * cos(Omega_Rabi * tau)]\n\nBy measuring the oscillation frequency as a function of drive amplitude, the pi-pulse duration was calibrated to exactly 20.0 ns. DRAG (Derivative Removal by Adiabatic Gate) pulsing was applied to suppress quadrature phase distortion, reducing Phase Error from 1.2% to 0.08%.`
      },
      {
        pageNumber: 5,
        title: 'Decoherence Spectroscopy: T1 and T2* Measurements',
        subtitle: 'Page 5 of 10 · Energy Relaxation & Ramsey Fringe Decay',
        content: `5. Longitudinal Relaxation (T1) Measurements:\nFollowing a calibrated pi-pulse, the qubit was allowed to relax for delay time Delta_t before readout. Fitting to exp(-Delta_t / T1) yielded:\nT1 = 84.6 ± 2.1 microseconds across 1,000 averages.\n\n6. Transverse Dephasing (T2* and T2_echo):\nRamsey interferometry was conducted using two pi/2 pulses separated by variable delay. Artificial detuning Delta_f = 2.0 MHz produced characteristic oscillations with envelope:\nT2* = 52.3 ± 1.8 microseconds.\n\nApplying a Hahn echo pi-refocusing pulse extended the coherence time to T2_echo = 114.8 ± 3.4 microseconds, confirming that low-frequency 1/f magnetic flux noise dominates pure dephasing.`
      },
      {
        pageNumber: 6,
        title: 'Cross-Resonance Hamiltonian & Two-Qubit Entanglement',
        subtitle: 'Page 6 of 10 · Cross-Resonance Drive Dynamics & Echo Pulses',
        content: `7. Two-Qubit Gate Architecture:\nQubits Q0 (control, 4.88 GHz) and Q1 (target, 5.12 GHz) were coupled via a fixed-frequency bus resonator with coupling constant g = 18 MHz. Driving Q0 at Q1's resonance frequency activates the effective cross-resonance interaction:\nH_CR = (Omega_CR / 2) * (Z_0 * X_1) + (Omega_IX / 2) * (I_0 * X_1)\n\n8. Echoed Cross-Resonance Sequence:\nTo eliminate unwanted Z_0 * I_1 and I_0 * X_1 terms, an active echo cancellation sequence was interleaved. The resulting conditional phase accumulation reached pi/2 at drive time tau_CR = 180 ns, synthesizing an entangling CNOT equivalent.`
      },
      {
        pageNumber: 7,
        title: 'Quantum State Tomography of Maximally Entangled Bell State',
        subtitle: 'Page 7 of 10 · Density Matrix Reconstruction & Concurrence',
        content: `9. Quantum State Tomography:\nStarting from ground state |00>, the CNOT gate produced the Bell state |Phi+> = (|00> + |11>) / sqrt(2). Over-complete state tomography was performed by applying 16 Pauli projection operators {I, X/2, Y/2, X} on both registers.\n\nReconstructed Density Matrix rho elements:\n• rho_{00,00} = 0.488\n• rho_{11,11} = 0.472\n• rho_{00,11} = 0.461 + 0.021i (off-diagonal coherence)\n• State fidelity F = <Phi+| rho |Phi+> = 96.2 ± 0.6%\n• Concurrence C = 0.924, verifying genuine multipartite quantum entanglement.`
      },
      {
        pageNumber: 8,
        title: 'Clifford Randomized Benchmarking (RB) Protocols',
        subtitle: 'Page 8 of 10 · Gate Error Rates & Scalable Error Mitigation',
        content: `10. Clifford Group Characterization:\nRandomized benchmarking was executed by applying random sequences of m Clifford gates chosen uniformly from the 24-element single-qubit Clifford group, followed by a unique reversal gate.\n\nSequence lengths were varied: m = [2, 4, 8, 16, 32, 64, 128, 256, 512].\n\nFitting the average sequence fidelity to F(m) = A * p^m + B:\n• Single-qubit depolarizing parameter: p = 0.99962\n• Average single-qubit gate error: r = (1 - p) * (d - 1) / d = 0.00019 (99.981% fidelity)\n• Two-qubit interleaved RB gate fidelity for CNOT: 98.42%.\n\nThis performance surpasses the minimum fault-tolerance threshold for 2D topological surface code parity checks.`
      },
      {
        pageNumber: 9,
        title: 'Scalability Roadmaps & Cryostat Thermal Management',
        subtitle: 'Page 9 of 10 · Multi-Node Routing & Dissipation Thresholds',
        content: `11. Scalability Constraints at the 1,000-Qubit Frontier:\nInterconnecting thousands of transmon qubits introduces stringent thermal dissipation ceilings. The total cooling power of modern dilution fridges at 100 mK is roughly 400 microwatts, and at 15 mK is approximately 20 microwatts.\n\nThermal Load Budgeting:\n• Superconducting flex cabling: 1.2 nW per line\n• Attenuator thermal anchoring dissipation: 4.8 microwatts at 4 K stage\n• Cryogenic CMOS control integration: Enables multiplexed readout lines by 16:1 ratio, drastically reducing passive heat leaks through wiring harnesses.\n\nFuture iterations will deploy 3D flip-chip bump bonding to isolate microwave control routing from the computational qubit die.`
      },
      {
        pageNumber: 10,
        title: 'Conclusions, Student Acknowledgments & Academic Citations',
        subtitle: 'Page 10 of 10 · Synthesis, Review Signatures & References',
        content: `12. Final Synthesis & Conclusions:\nIn this 10-page study, we demonstrated superconducting qubit coherence exceeding 110 microseconds and two-qubit gate fidelities reaching 98.4%. The implemented error mitigation protocols provide a viable substrate for fault-tolerant surface code syndromes.\n\nStudent Declaration:\nAll experimental data and tomography measurements were gathered and analyzed independently in accordance with academic integrity guidelines.\n\nAcademic References:\n[1] Barends et al., "Superconducting quantum circuits at the surface code threshold for fault tolerance," Nature 508, 500–503 (2014).\n[2] Gambetta et al., "Analytic approach to high-fidelity gates with derivative removal by adiabatic gate (DRAG)," Phys. Rev. A 83, 012308 (2011).\n[3] Koch et al., "Charge-insensitive qubit design derived from the Cooper pair box," Phys. Rev. A 76, 042319 (2007).\n[4] IEEE Transactions on Quantum Engineering, Vol. 5, 2024.`
      }
    ];

    setFile({
      name: 'Physics_Quantum_Computing_Thesis_10Pages.pdf',
      type: 'application/pdf',
      size: '480.0 KB',
      dataUrl: 'data:application/pdf;base64,JVBERi0xLjQK...',
      format: 'pdf',
      documentPages: tenPages,
    });
    setNotes('Attached is my full 10-page quantum physics thesis report covering pages 1 through 10 with all diagrams, Hamiltonian equations, and experimental benchmarking.');
  };

  const loadSampleWord = () => {
    setFile({
      name: 'CS101_Operating_Systems_Analysis.docx',
      type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      size: '115.2 KB',
      dataUrl: 'data:application/msword;base64,...',
      format: 'word',
      documentPages: [
        {
          pageNumber: 1,
          title: 'Comparative Analysis of UNIX vs Windows NT Kernel Architecture',
          subtitle: 'Page 1 of 2 · Term Paper Submission · Computer Systems Course',
          content: `Executive Summary:\nThis term paper explores the monolithic architecture of Unix-derived kernels contrasted with the hybrid microkernel design of Windows NT.\n\n1. Process Management & Context Switches:\nUnix systems utilize fork() and exec() semantics with copy-on-write page tables. In contrast, Windows NT utilizes CreateProcess() with explicit security descriptors and subsystem initialization.\n\n2. Virtual Memory Management:\nBoth systems implement demand-paged virtual memory, but differ in page replacement heuristics. Linux relies on the Two-List Active/Inactive algorithm, while NT employs working set trimming.`
        },
        {
          pageNumber: 2,
          title: 'Microkernel Performance & System Call Overhead',
          subtitle: 'Page 2 of 2 · Synthesis & Benchmarking Conclusions',
          content: `3. IPC Overhead Comparison:\nMach-style message passing in early microkernels incurred severe cache thrashing. Modern NT hybrid models mitigate this by executing graphics drivers (win32k.sys) inside kernel space.\n\n4. Conclusion:\nModern hybrid architectures increasingly blend the raw speed of monolithic drivers with the security isolation of microkernel services.\n\nReferences:\n[1] Silberschatz, Operating System Concepts (10th ed.).\n[2] Russinovich, Windows Internals (7th ed.).`
        }
      ]
    });
    setNotes('Uploaded Word document (.docx) detailing OS kernel internals across 2 pages.');
  };

  const loadSamplePpt = () => {
    setFile({
      name: 'Distributed_Consensus_Algorithms.pptx',
      type: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
      size: '420.0 KB',
      dataUrl: 'data:application/vnd.ms-powerpoint;base64,...',
      format: 'ppt',
      documentPages: [
        {
          pageNumber: 1,
          title: 'Distributed Consensus: Raft vs Paxos',
          subtitle: 'Slide 1: Problem Definition',
          content: `Key Objectives:\n• State machine replication in untrusted networks\n• Leader election and heartbeat timeouts\n• Byzantine fault tolerance thresholds`
        },
        {
          pageNumber: 2,
          title: 'Log Replication & Safety Invariants',
          subtitle: 'Slide 2: Commit Index Mechanics',
          content: `Safety Rules:\n• Leader completeness property\n• State Machine Safety: At most one log entry applied per index\n• Follower append entries RPC handling`
        }
      ]
    });
    setNotes('Presentation slide deck submitted for classroom presentation.');
  };

  const loadSampleOdf = () => {
    setFile({
      name: 'Lab_Report_Circuits.odt',
      type: 'application/vnd.oasis.opendocument.text',
      size: '94.0 KB',
      dataUrl: 'data:application/vnd.oasis.opendocument.text;base64,...',
      format: 'odf',
      documentPages: [
        {
          pageNumber: 1,
          title: 'Kirchhoff Voltage Law & RLC Circuit Analysis',
          subtitle: 'OpenDocument Format (.odt) Lab Submission',
          content: `Experiment Summary:\nUsing an oscilloscope and function generator, resonance frequency was calculated at f_0 = 1 / (2 * pi * sqrt(L * C)).\n\nMeasurements:\nR = 220 ohms, L = 10 mH, C = 100 nF. Measured peak voltage matched theoretical calculations within 1.8% error margin.`
        }
      ]
    });
    setNotes('ODF document (.odt) completed in LibreOffice.');
  };

  const handleSubmit = () => {
    if (!file && !notes) {
      alert('Please upload a file or write a note before submitting.');
      return;
    }

    const payload: SubmissionPayload = {
      fileUrl: file?.dataUrl,
      fileName: file?.name || 'Uploaded_Assignment_Submission',
      fileType: file?.type || 'file',
      fileSize: file?.size || '24 KB',
      fileFormat: file?.format || 'other',
      documentPages: file?.documentPages,
      textResponse: notes,
      docTitle: file?.name ? file.name.replace(/\.[^/.]+$/, '') : task.title,
      docContent: file?.documentPages?.map(p => p.content).join('\n\n') || notes,
    };

    onSubmit(payload);
  };

  return (
    <div className="flex flex-col gap-4 max-w-4xl mx-auto">
      {/* Header */}
      <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs">
        <span className="text-xs font-semibold px-2 py-0.5 rounded bg-blue-50 text-blue-700 uppercase tracking-wide">
          {task.type === 'video' ? 'Video Submission' : task.type === 'image' ? 'Image Upload' : 'Document & File Upload'}
        </span>
        <h2 className="text-base font-bold text-slate-900 mt-1">{task.title}</h2>
        <p className="text-xs text-slate-500">{task.uploadConfig?.prompt || task.description}</p>
      </div>

      {/* Quick Sample File Presets */}
      <div className="rounded-xl border border-indigo-100 bg-indigo-50/60 p-3.5 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-1.5 text-indigo-900 font-semibold">
          <Sparkles className="w-4 h-4 text-indigo-600" />
          <span>Quick Test: Try Loading Sample Academic Documents:</span>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={loadSample10PagePdf}
            className="flex items-center gap-1 bg-white hover:bg-rose-50 text-rose-700 border border-rose-200 px-2.5 py-1 rounded-lg font-bold transition shadow-2xs cursor-pointer"
            title="Load complete 10-page academic report"
          >
            <FileText className="w-3.5 h-3.5" />
            <span>📄 10-Page Research Thesis (.pdf)</span>
          </button>
          <button
            type="button"
            onClick={loadSampleWord}
            className="flex items-center gap-1 bg-white hover:bg-blue-50 text-blue-700 border border-blue-200 px-2.5 py-1 rounded-lg font-bold transition shadow-2xs cursor-pointer"
          >
            <FileText className="w-3.5 h-3.5" />
            <span>📝 Kernel_Essay.docx</span>
          </button>
          <button
            type="button"
            onClick={loadSamplePpt}
            className="flex items-center gap-1 bg-white hover:bg-amber-50 text-amber-700 border border-amber-200 px-2.5 py-1 rounded-lg font-bold transition shadow-2xs cursor-pointer"
          >
            <Presentation className="w-3.5 h-3.5" />
            <span>📊 Consensus.pptx</span>
          </button>
          <button
            type="button"
            onClick={loadSampleOdf}
            className="flex items-center gap-1 bg-white hover:bg-emerald-50 text-emerald-700 border border-emerald-200 px-2.5 py-1 rounded-lg font-bold transition shadow-2xs cursor-pointer"
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            <span>📋 Circuits.odt (ODF)</span>
          </button>
        </div>
      </div>

      {/* Upload Drop Zone */}
      <div
        onDragOver={e => { e.preventDefault(); setIsDragging(true); }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={handleDrop}
        className={`rounded-2xl border-2 border-dashed p-8 text-center transition flex flex-col items-center justify-center min-h-[220px] ${
          isDragging ? 'border-indigo-500 bg-indigo-50/60' : 'border-slate-300 bg-white hover:border-slate-400'
        }`}
      >
        {isParsing ? (
          <div className="flex flex-col items-center gap-3 py-6">
            <Loader2 className="w-10 h-10 text-indigo-600 animate-spin" />
            <div>
              <p className="text-sm font-bold text-slate-800">Processing Multi-Page Document...</p>
              <p className="text-xs text-slate-500 mt-1">{parsingStatus || 'Extracting all pages with 100% preservation...'}</p>
            </div>
          </div>
        ) : file ? (
          <div className="flex flex-col items-center gap-3">
            <div className={`w-14 h-14 rounded-2xl flex items-center justify-center shadow-xs ${
              file.format === 'pdf' ? 'bg-rose-50 text-rose-600' :
              file.format === 'word' ? 'bg-blue-50 text-blue-600' :
              file.format === 'ppt' ? 'bg-amber-50 text-amber-600' :
              file.format === 'odf' ? 'bg-emerald-50 text-emerald-600' :
              file.format === 'image' ? 'bg-purple-50 text-purple-600' :
              'bg-slate-100 text-slate-700'
            }`}>
              {file.format === 'pdf' ? <FileText className="w-7 h-7" /> :
               file.format === 'word' ? <FileText className="w-7 h-7" /> :
               file.format === 'ppt' ? <Presentation className="w-7 h-7" /> :
               file.format === 'image' ? <Image className="w-7 h-7" /> :
               file.format === 'video' ? <Video className="w-7 h-7" /> :
               <File className="w-7 h-7" />}
            </div>

            <div>
              <div className="flex items-center justify-center gap-2">
                <p className="text-sm font-bold text-slate-900">{file.name}</p>
                <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-slate-100 text-slate-700 border">
                  {file.format.toUpperCase()}
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">{file.type} · {file.size}</p>
            </div>

            {/* Document Pages Indicator: Shows EXACT page count preserved */}
            {file.documentPages && file.documentPages.length > 0 && (
              <div className="flex items-center gap-2 text-xs font-bold text-emerald-800 bg-emerald-50 px-3.5 py-1.5 rounded-lg border border-emerald-300 shadow-2xs">
                <CheckCircle className="w-4 h-4 text-emerald-600" />
                <span>All {file.documentPages.length} Pages Extracted & Ready for Teacher In-App Annotation</span>
              </div>
            )}

            {/* Preview image if image */}
            {file.format === 'image' && file.dataUrl && (
              <img src={file.dataUrl} alt="Preview" className="max-h-48 rounded-lg border border-slate-200 shadow-2xs mt-2" />
            )}

            <button
              type="button"
              onClick={() => setFile(null)}
              className="text-xs text-rose-600 hover:underline flex items-center gap-1 mt-2 cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
              <span>Remove and choose another file</span>
            </button>
          </div>
        ) : (
          <div className="flex flex-col items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center text-slate-500">
              <UploadCloud className="w-6 h-6" />
            </div>
            <div>
              <p className="text-sm font-semibold text-slate-800">
                Drag and drop your document here, or{' '}
                <label className="text-indigo-600 hover:underline cursor-pointer font-bold">
                  browse local files
                  <input
                    type="file"
                    className="hidden"
                    onChange={e => e.target.files?.[0] && handleFile(e.target.files[0])}
                  />
                </label>
              </p>
              <p className="text-xs text-slate-400 mt-1">
                Supports PDF (.pdf — all pages preserved), Word (.docx, .doc), PowerPoint (.pptx, .ppt), OpenDocument (.odt, .odp), and media files
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Accompanying Notes */}
      <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs">
        <label className="text-xs font-semibold text-slate-700 block mb-1">
          Submission Comments or Notes for Teacher:
        </label>
        <textarea
          value={notes}
          onChange={e => setNotes(e.target.value)}
          rows={3}
          placeholder="Include any comments, instructions, or citations for the teacher..."
          className="w-full text-xs text-slate-800 p-2.5 rounded-lg border border-slate-200 focus:outline-hidden focus:border-indigo-500"
        />
      </div>

      {/* Action Footer */}
      <div className="flex items-center justify-between rounded-xl border border-slate-200 bg-white p-4 shadow-xs">
        <button
          type="button"
          onClick={onCancel}
          className="rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
        >
          Cancel
        </button>

        <button
          type="button"
          onClick={handleSubmit}
          disabled={isParsing}
          className="flex items-center gap-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white px-5 py-2 text-xs font-bold shadow-xs transition active:scale-95 cursor-pointer"
        >
          <Send className="w-3.5 h-3.5" />
          <span>Submit Document to Teacher</span>
        </button>
      </div>
    </div>
  );
};
