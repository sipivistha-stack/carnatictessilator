import React, { useState, useEffect, useRef } from 'react';
import { Task, SubmissionPayload } from '../../types';
import { getCurrentStudent } from '../../data/storage';
import { 
  Music, 
  Play, 
  Square, 
  Volume2, 
  Mic, 
  Radio, 
  Send, 
  Clock, 
  Sparkles, 
  Check, 
  Upload,
  RefreshCw,
  Sliders,
  BookOpen
} from 'lucide-react';

interface CarnaticMusicWorkspaceProps {
  task: Task;
  onSubmit: (payload: SubmissionPayload) => void;
  onCancel: () => void;
}

// Shruti Pitch Mapping in Hz (based on A4 = 440Hz standard concert pitch)
const SHRUTI_MAP: Record<string, { note: string; freq: number }> = {
  '1 Kattai (C)': { note: 'C', freq: 130.81 },
  '1.5 Kattai (C#)': { note: 'C#', freq: 138.59 },
  '2 Kattai (D)': { note: 'D', freq: 146.83 },
  '2.5 Kattai (D#)': { note: 'D#', freq: 155.56 },
  '3 Kattai (E)': { note: 'E', freq: 164.81 },
  '4 Kattai (F)': { note: 'F', freq: 174.61 },
  '4.5 Kattai (F#)': { note: 'F#', freq: 185.00 },
  '5 Kattai (G)': { note: 'G', freq: 196.00 },
  '5.5 Kattai (G#)': { note: 'G#', freq: 207.65 },
  '6 Kattai (A)': { note: 'A', freq: 220.00 },
};

// Swara Interval Ratio from Sa
const SWARA_RATIOS: Record<string, number> = {
  'S': 1.0,
  'R1': 16 / 15,
  'R2': 9 / 8,
  'G2': 6 / 5,
  'G3': 5 / 4,
  'M1': 4 / 3,
  'M2': 45 / 32,
  'P': 3 / 2,
  'D1': 8 / 5,
  'D2': 5 / 3,
  'N2': 9 / 5,
  'N3': 15 / 8,
};

// Tala Kriya definitions
interface TalaDefinition {
  name: string;
  totalAksharas: number;
  kriyas: { name: string; symbol: string; count: number }[];
}

const TALAS: Record<string, TalaDefinition> = {
  'Adi Tala': {
    name: 'Adi Tala (Chatusra Jathi Triputa)',
    totalAksharas: 8,
    kriyas: [
      { name: 'Laghu Beat 1', symbol: '👏 Beat', count: 1 },
      { name: 'Laghu Little Finger', symbol: '☝️ Finger', count: 2 },
      { name: 'Laghu Ring Finger', symbol: '✌️ Finger', count: 3 },
      { name: 'Laghu Middle Finger', symbol: '🖐️ Finger', count: 4 },
      { name: 'Dhrutam Beat', symbol: '👏 Beat', count: 5 },
      { name: 'Dhrutam Wave (Usiru)', symbol: '👋 Wave', count: 6 },
      { name: 'Dhrutam Beat', symbol: '👏 Beat', count: 7 },
      { name: 'Dhrutam Wave (Usiru)', symbol: '👋 Wave', count: 8 },
    ],
  },
  'Rupaka Tala': {
    name: 'Rupaka Tala (Dhrutam + Laghu)',
    totalAksharas: 6,
    kriyas: [
      { name: 'Dhrutam Beat', symbol: '👏 Beat', count: 1 },
      { name: 'Dhrutam Wave', symbol: '👋 Wave', count: 2 },
      { name: 'Laghu Beat', symbol: '👏 Beat', count: 3 },
      { name: 'Laghu Little Finger', symbol: '☝️ Finger', count: 4 },
      { name: 'Laghu Ring Finger', symbol: '✌️ Finger', count: 5 },
      { name: 'Laghu Middle Finger', symbol: '🖐️ Finger', count: 6 },
    ],
  },
  'Mishra Chapu': {
    name: 'Mishra Chapu (3 + 2 + 2)',
    totalAksharas: 7,
    kriyas: [
      { name: 'Ta (Beat)', symbol: '👏 1', count: 1 },
      { name: 'Ki (Beat)', symbol: '👏 2', count: 2 },
      { name: 'Ta (Wave)', symbol: '👋 3', count: 3 },
      { name: 'Dhi (Beat)', symbol: '👏 4', count: 4 },
      { name: 'Mi (Wave)', symbol: '👋 5', count: 5 },
      { name: 'Ta (Beat)', symbol: '👏 6', count: 6 },
      { name: 'Ka (Wave)', symbol: '👋 7', count: 7 },
    ],
  },
  'Khanda Chapu': {
    name: 'Khanda Chapu (2 + 3)',
    totalAksharas: 5,
    kriyas: [
      { name: 'Ta (Beat)', symbol: '👏 1', count: 1 },
      { name: 'Ka (Wave)', symbol: '👋 2', count: 2 },
      { name: 'Ta (Beat)', symbol: '👏 3', count: 3 },
      { name: 'Ki (Beat)', symbol: '👏 4', count: 4 },
      { name: 'Ta (Wave)', symbol: '👋 5', count: 5 },
    ],
  },
};

const POPULAR_RAGAS: Record<string, { name: string; arohana: string; avarohana: string; janya?: string }> = {
  'Mayamalavagowla': {
    name: 'Mayamalavagowla (15th Melakarta)',
    arohana: 'S R1 G3 M1 P D1 N3 S',
    avarohana: 'S N3 D1 P M1 G3 R1 S',
    janya: 'Malahari, Saveri, Bauli',
  },
  'Kalyani': {
    name: 'Mechakalyani (65th Melakarta)',
    arohana: 'S R2 G3 M2 P D2 N3 S',
    avarohana: 'S N3 D2 P M2 G3 R2 S',
    janya: 'Mohanakalyani, Saranga, Hamirkalyani',
  },
  'Shankarabharanam': {
    name: 'Dheerasankarabharanam (29th Melakarta)',
    arohana: 'S R2 G3 M1 P D2 N3 S',
    avarohana: 'S N3 D2 P M1 G3 R2 S',
    janya: 'Hamsadhwani, Bilahari, Kedaragowla',
  },
  'Mohanam': {
    name: 'Mohanam (Audava Raga)',
    arohana: 'S R2 G3 P D2 S',
    avarohana: 'S D2 P G3 R2 S',
    janya: 'Janya of Harikambhoji',
  },
  'Hamsadhwani': {
    name: 'Hamsadhwani (Audava Raga)',
    arohana: 'S R2 G3 P N3 S',
    avarohana: 'S N3 P G3 R2 S',
    janya: 'Janya of Shankarabharanam',
  },
  'Kharaharapriya': {
    name: 'Kharaharapriya (22nd Melakarta)',
    arohana: 'S R2 G2 M1 P D2 N2 S',
    avarohana: 'S N2 D2 P M1 G2 R2 S',
    janya: 'Abheri, Sriranjani, Madhyamavati',
  }
};

export const CarnaticMusicWorkspace: React.FC<CarnaticMusicWorkspaceProps> = ({
  task,
  onSubmit,
  onCancel,
}) => {
  const carnaticConfig = task.carnaticConfig;
  const currentStudent = getCurrentStudent();
  const musicLevel = currentStudent.carnaticLevel || (currentStudent.tier === 'bright' ? 'advanced' : currentStudent.tier === 'average' ? 'intermediate' : 'beginner');
  const prescribedLyrics = carnaticConfig?.lyricsByLevel?.[musicLevel] || '';
  const singingActivity = Boolean(carnaticConfig?.singingActivity);
  const recordingRequired = Boolean(carnaticConfig?.recordingRequired);

  // Selected Shruti & Raga & Tala
  const [selectedShruti, setSelectedShruti] = useState<string>('1 Kattai (C)');
  const [selectedRaga, setSelectedRaga] = useState<string>('Mayamalavagowla');
  const [selectedTalaName, setSelectedTalaName] = useState<string>('Adi Tala');

  // Tanpura state
  const [isTanpuraPlaying, setIsTanpuraPlaying] = useState<boolean>(false);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const oscillatorsRef = useRef<OscillatorNode[]>([]);
  const gainNodeRef = useRef<GainNode | null>(null);

  // Tala Metronome state
  const [isTalaPlaying, setIsTalaPlaying] = useState<boolean>(false);
  const [currentBeat, setCurrentBeat] = useState<number>(0);
  const [bpm, setBpm] = useState<number>(72);
  const [kalaSpeed, setKalaSpeed] = useState<'1st' | '2nd' | '3rd'>('1st');

  // Swara Notation Editor
  const [notationText, setNotationText] = useState<string>(
    carnaticConfig?.sampleNotation ||
    `|| S , R1 | G3 M1 P , || M1 P D1 | P , M1 G3 ||\n|| R1 G3 R1 | S , . . ||`
  );
  const [octaveSthayi, setOctaveSthayi] = useState<'mandra' | 'madhya' | 'tara'>('madhya');

  // Voice Recording state
  const [isRecording, setIsRecording] = useState<boolean>(false);
  const [recordedAudioUrl, setRecordedAudioUrl] = useState<string | null>(null);
  const [recordDuration, setRecordDuration] = useState<number>(0);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const timerIntervalRef = useRef<any>(null);

  // Theory Answers / Student Notes
  const [studentNotes, setStudentNotes] = useState<string>('');

  // 1. WEB AUDIO TANPURA DRONE SYNTHESIZER
  const toggleTanpura = () => {
    if (isTanpuraPlaying) {
      stopTanpura();
    } else {
      startTanpura();
    }
  };

  const startTanpura = () => {
    try {
      if (!audioCtxRef.current) {
        audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      const ctx = audioCtxRef.current;
      if (ctx.state === 'suspended') {
        ctx.resume();
      }

      const baseFreq = SHRUTI_MAP[selectedShruti]?.freq || 130.81;

      // 4 harmonic strings of Tanpura: Pa (3/2), Sa' (2.0), Sa' (2.0), Sa (1.0)
      const freqs = [
        baseFreq * 1.5, // Pa
        baseFreq * 2.0, // Sa high
        baseFreq * 2.0 * 1.002, // Sa high slightly chorused
        baseFreq, // Sa base
      ];

      const masterGain = ctx.createGain();
      masterGain.gain.setValueAtTime(0.12, ctx.currentTime);
      masterGain.connect(ctx.destination);
      gainNodeRef.current = masterGain;

      oscillatorsRef.current = freqs.map((freq, i) => {
        const osc = ctx.createOscillator();
        const stringGain = ctx.createGain();
        osc.type = i === 3 ? 'sawtooth' : 'triangle';
        osc.frequency.setValueAtTime(freq, ctx.currentTime);

        // LFO for continuous strumming shimmer
        const lfo = ctx.createOscillator();
        const lfoGain = ctx.createGain();
        lfo.frequency.setValueAtTime(0.25 + i * 0.1, ctx.currentTime);
        lfoGain.gain.setValueAtTime(0.04, ctx.currentTime);
        lfo.connect(lfoGain.gain);

        osc.connect(stringGain);
        stringGain.connect(masterGain);
        osc.start();
        return osc;
      });

      setIsTanpuraPlaying(true);
    } catch (e) {
      console.warn('AudioContext not allowed yet:', e);
    }
  };

  const stopTanpura = () => {
    oscillatorsRef.current.forEach(osc => {
      try { osc.stop(); osc.disconnect(); } catch {}
    });
    oscillatorsRef.current = [];
    setIsTanpuraPlaying(false);
  };

  useEffect(() => {
    return () => {
      stopTanpura();
      if (audioCtxRef.current) {
        audioCtxRef.current.close().catch(() => {});
      }
    };
  }, []);

  // Update Tanpura pitch dynamically
  useEffect(() => {
    if (isTanpuraPlaying) {
      stopTanpura();
      startTanpura();
    }
  }, [selectedShruti]);

  // 2. PLAY INDIVIDUAL SWARA AUDIO NOTE
  const playSwaraNote = (swara: string) => {
    try {
      if (!audioCtxRef.current) {
        audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      const ctx = audioCtxRef.current;
      if (ctx.state === 'suspended') ctx.resume();

      const baseFreq = SHRUTI_MAP[selectedShruti]?.freq || 130.81;
      const ratio = SWARA_RATIOS[swara] || 1.0;
      let multiplier = 1.0;
      if (octaveSthayi === 'mandra') multiplier = 0.5;
      if (octaveSthayi === 'tara') multiplier = 2.0;

      const targetFreq = baseFreq * ratio * multiplier;

      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(targetFreq, ctx.currentTime);

      gain.gain.setValueAtTime(0.2, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 1.2);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start();
      osc.stop(ctx.currentTime + 1.2);

      // Append Swara into Notation Text
      const sthayiSymbol = octaveSthayi === 'mandra' ? `${swara}̣ ` : octaveSthayi === 'tara' ? `${swara}̇ ` : `${swara} `;
      setNotationText(prev => prev + sthayiSymbol);
    } catch (e) {
      console.warn(e);
    }
  };

  // 3. TALA METRONOME & KRIYA RUNNER
  useEffect(() => {
    if (!isTalaPlaying) {
      setCurrentBeat(0);
      return;
    }

    const currentTalaDef = TALAS[selectedTalaName] || TALAS['Adi Tala'];
    const totalBeats = currentTalaDef.totalAksharas;

    let multiplier = 1;
    if (kalaSpeed === '2nd') multiplier = 2;
    if (kalaSpeed === '3rd') multiplier = 4;

    const intervalMs = (60 / (bpm * multiplier)) * 1000;

    const interval = setInterval(() => {
      setCurrentBeat(prev => {
        const next = (prev + 1) % totalBeats;
        // Audio click on each beat
        try {
          if (audioCtxRef.current) {
            const ctx = audioCtxRef.current;
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.frequency.setValueAtTime(next === 0 ? 880 : 440, ctx.currentTime);
            gain.gain.setValueAtTime(0.15, ctx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.08);
            osc.connect(gain);
            gain.connect(ctx.destination);
            osc.start();
            osc.stop(ctx.currentTime + 0.08);
          }
        } catch {}
        return next;
      });
    }, intervalMs);

    return () => clearInterval(interval);
  }, [isTalaPlaying, bpm, selectedTalaName, kalaSpeed]);

  // 4. MICROPHONE VOICE / INSTRUMENTAL RECORDER
  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      audioChunksRef.current = [];
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;

      mediaRecorder.ondataavailable = e => {
        if (e.data.size > 0) audioChunksRef.current.push(e.data);
      };

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        const reader = new FileReader();
        reader.onloadend = () => {
          setRecordedAudioUrl(reader.result as string);
        };
        reader.readAsDataURL(audioBlob);
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
      setRecordDuration(0);

      timerIntervalRef.current = setInterval(() => {
        setRecordDuration(prev => {
          const next = prev + 1;
          if (recordingRequired && carnaticConfig?.recordingMaxSeconds && next >= carnaticConfig.recordingMaxSeconds) {
            setTimeout(() => stopRecording(), 0);
          }
          return next;
        });
      }, 1000);
    } catch (err) {
      alert('Microphone access unavailable. You can also upload a recorded audio file below.');
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      clearInterval(timerIntervalRef.current);
    }
  };

  const handleAudioUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        setRecordedAudioUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // Submit Handler
  const handleSubmit = () => {
    if (singingActivity && recordingRequired && !recordedAudioUrl) {
      alert('This singing activity requires an audio recording before submission.');
      return;
    }
    const payload: SubmissionPayload = {
      carnaticRaga: selectedRaga,
      carnaticTala: selectedTalaName,
      carnaticShruti: selectedShruti,
      carnaticSwaraNotation: notationText,
      carnaticAudioUrl: recordedAudioUrl || undefined,
      textResponse: studentNotes,
    };
    onSubmit(payload);
  };

  const activeTala = TALAS[selectedTalaName] || TALAS['Adi Tala'];

  return (
    <div className="flex flex-col gap-5 max-w-5xl mx-auto">
      {/* Top Banner: Carnatic Assessment Header */}
      <div className="rounded-xl border border-amber-300 bg-gradient-to-r from-amber-50 via-orange-50 to-amber-50 p-5 shadow-xs">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-amber-600 to-amber-800 text-white flex items-center justify-center font-bold shadow-xs">
              <Music className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold uppercase tracking-wider text-amber-900 bg-amber-200/80 px-2.5 py-0.5 rounded">
                  Carnatic Classical Music Portal
                </span>
                <span className="text-xs font-bold text-amber-800 bg-white px-2 py-0.5 rounded border border-amber-300">
                  Total: {task.maxPoints} Marks
                </span>
              </div>
              <h2 className="text-lg font-bold text-amber-950 mt-1">{task.title}</h2>
              <p className="text-xs text-amber-800 mt-0.5">{task.description}</p>
            </div>
          </div>

          {carnaticConfig && (
            <div className="text-right text-xs text-amber-900 bg-white/90 p-3 rounded-lg border border-amber-200 shadow-2xs">
              <p><strong>Prescribed Raga:</strong> {carnaticConfig.raga}</p>
              <p><strong>Prescribed Tala:</strong> {carnaticConfig.tala}</p>
              <p><strong>Base Shruti:</strong> {carnaticConfig.baseShruti}</p>
            </div>
          )}
        </div>
      </div>

      {singingActivity && (
        <div className="rounded-xl border-2 border-violet-300 bg-violet-50 p-5 shadow-xs">
          <div className="flex flex-wrap items-start justify-between gap-3 mb-4">
            <div>
              <div className="flex items-center gap-2 text-violet-900 font-black text-sm">
                <Mic className="w-5 h-5" />
                AI Voice Recorder · Level-Based Singing Activity
              </div>
              <p className="text-[11px] text-violet-800 mt-1">Your assigned level: <strong className="uppercase">{musicLevel}</strong>. Sing only the teacher-provided lyrics below. The recording is submitted as-is; no automatic correction or rewriting is applied.</p>
            </div>
            <span className="px-2 py-1 rounded-full bg-white border border-violet-200 text-violet-800 text-[10px] font-bold">{recordingRequired ? 'Recording required' : 'Recording optional'}</span>
          </div>
          <div className="rounded-xl bg-white border border-violet-200 p-4 mb-4">
            <div className="text-[10px] font-black uppercase tracking-wider text-violet-600 mb-2">Prescribed Lyrics</div>
            <pre className="whitespace-pre-wrap font-serif text-sm leading-relaxed text-slate-900">{prescribedLyrics || 'No lyrics have been supplied for this level yet. Follow the teacher’s written task instructions.'}</pre>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <button type="button" onClick={isRecording ? stopRecording : startRecording} className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-black text-white cursor-pointer ${isRecording ? 'bg-rose-600 hover:bg-rose-700' : 'bg-violet-600 hover:bg-violet-700'}`}>
              {isRecording ? <Square className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
              {isRecording ? 'Stop Recording' : 'Start Singing Recording'}
            </button>
            <span className="font-mono text-xs text-slate-600">{recordDuration}s{carnaticConfig?.recordingMaxSeconds ? ` / ${carnaticConfig.recordingMaxSeconds}s` : ''}</span>
            {recordedAudioUrl && <audio controls src={recordedAudioUrl} className="h-9 max-w-full" />}
            <label className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-violet-200 bg-white text-violet-800 text-xs font-bold cursor-pointer">
              Upload recording
              <input type="file" accept="audio/*" className="hidden" onChange={handleAudioUpload} />
            </label>
          </div>
        </div>
      )}

      {/* TOOL 1: INTEGRATED SHRUTI BOX (TANPURA DRONE) & TUNER */}
      <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 pb-3 mb-4">
          <div className="flex items-center gap-2">
            <Radio className="w-5 h-5 text-amber-600" />
            <h3 className="text-sm font-bold text-slate-900">1. Tanpura Drone & Shruti Box</h3>
            <span className="text-xs text-slate-500 font-mono">(Continuous Sa - Pa - Sa' Drone)</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={toggleTanpura}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg font-bold text-xs shadow-xs transition cursor-pointer ${
                isTanpuraPlaying 
                  ? 'bg-rose-600 hover:bg-rose-700 text-white animate-pulse' 
                  : 'bg-amber-600 hover:bg-amber-700 text-white'
              }`}
            >
              {isTanpuraPlaying ? <Square className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
              <span>{isTanpuraPlaying ? 'Stop Tanpura Drone' : 'Start Tanpura Drone'}</span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
          {Object.entries(SHRUTI_MAP).map(([kattai, data]) => (
            <button
              key={kattai}
              type="button"
              onClick={() => setSelectedShruti(kattai)}
              className={`p-2.5 rounded-lg border text-xs font-semibold flex flex-col items-center gap-1 transition cursor-pointer ${
                selectedShruti === kattai
                  ? 'bg-amber-500 text-white border-amber-600 shadow-xs'
                  : 'bg-slate-50 hover:bg-amber-50 text-slate-700 border-slate-200'
              }`}
            >
              <span className="font-bold">{kattai}</span>
              <span className="text-[11px] opacity-80">{data.freq.toFixed(1)} Hz</span>
            </button>
          ))}
        </div>
      </div>

      {/* TOOL 2: INTERACTIVE TALA METRONOME & KRIYA VISUALIZER */}
      <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 pb-3 mb-4">
          <div className="flex items-center gap-2">
            <Clock className="w-5 h-5 text-indigo-600" />
            <h3 className="text-sm font-bold text-slate-900">2. Tala Metronome & Live Kriya Visualizer</h3>
          </div>

          <div className="flex flex-wrap items-center gap-3 text-xs">
            {/* Tala Selector */}
            <select
              value={selectedTalaName}
              onChange={e => setSelectedTalaName(e.target.value)}
              className="rounded-lg border border-slate-300 p-1.5 text-xs font-semibold text-slate-800 bg-white"
            >
              {Object.keys(TALAS).map(t => (
                <option key={t} value={t}>{t}</option>
              ))}
            </select>

            {/* Kala Speed */}
            <div className="flex rounded border border-slate-200 bg-slate-100 p-0.5">
              {(['1st', '2nd', '3rd'] as const).map(k => (
                <button
                  key={k}
                  type="button"
                  onClick={() => setKalaSpeed(k)}
                  className={`px-2 py-0.5 rounded text-[11px] font-bold cursor-pointer ${
                    kalaSpeed === k ? 'bg-white shadow-2xs text-indigo-700' : 'text-slate-600'
                  }`}
                >
                  {k} Kala
                </button>
              ))}
            </div>

            {/* BPM Slider */}
            <div className="flex items-center gap-2 bg-slate-50 px-2.5 py-1 rounded-lg border border-slate-200">
              <span className="font-mono text-slate-600">{bpm} BPM</span>
              <input
                type="range"
                min={40}
                max={140}
                value={bpm}
                onChange={e => setBpm(Number(e.target.value))}
                className="w-20 accent-indigo-600"
              />
            </div>

            {/* Metronome Toggle */}
            <button
              type="button"
              onClick={() => setIsTalaPlaying(!isTalaPlaying)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold text-xs cursor-pointer text-white ${
                isTalaPlaying ? 'bg-rose-600' : 'bg-indigo-600 hover:bg-indigo-700'
              }`}
            >
              {isTalaPlaying ? <Square className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
              <span>{isTalaPlaying ? 'Stop Tala' : 'Keep Tala'}</span>
            </button>
          </div>
        </div>

        {/* Live Kriya Beats Grid */}
        <div className="grid grid-cols-4 sm:grid-cols-8 gap-2">
          {activeTala.kriyas.map((kriya, idx) => {
            const isActive = isTalaPlaying && currentBeat === idx;
            return (
              <div
                key={idx}
                className={`p-3 rounded-xl border flex flex-col items-center justify-center text-center transition-all ${
                  isActive
                    ? 'bg-indigo-600 text-white border-indigo-700 shadow-md scale-105 ring-2 ring-indigo-400'
                    : 'bg-slate-50 border-slate-200 text-slate-700'
                }`}
              >
                <span className="text-xs font-black mb-1">Beat {idx + 1}</span>
                <span className="text-sm font-bold">{kriya.symbol}</span>
                <span className="text-[10px] opacity-80 mt-1">{kriya.name.split(' ')[0]}</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* TOOL 3: INTERACTIVE SWARAS KEYBOARD & NOTATION TRANSCRIBER */}
      <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 pb-3 mb-4">
          <div className="flex items-center gap-2">
            <Sliders className="w-5 h-5 text-emerald-600" />
            <h3 className="text-sm font-bold text-slate-900">3. Swaras Keyboard & Notation Transcriber</h3>
          </div>

          <div className="flex items-center gap-2">
            {/* Raga Presets */}
            <select
              value={selectedRaga}
              onChange={e => setSelectedRaga(e.target.value)}
              className="rounded-lg border border-slate-300 p-1.5 text-xs font-semibold text-slate-800 bg-white"
            >
              {Object.keys(POPULAR_RAGAS).map(r => (
                <option key={r} value={r}>{r}</option>
              ))}
            </select>

            {/* Sthayi Octave selector */}
            <div className="flex rounded border border-slate-200 bg-slate-100 p-0.5 text-xs">
              {(['mandra', 'madhya', 'tara'] as const).map(s => (
                <button
                  key={s}
                  type="button"
                  onClick={() => setOctaveSthayi(s)}
                  className={`px-2 py-0.5 rounded capitalize font-medium cursor-pointer ${
                    octaveSthayi === s ? 'bg-white text-emerald-700 font-bold shadow-2xs' : 'text-slate-600'
                  }`}
                >
                  {s} Sthayi
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Selected Raga Scale Reference */}
        {POPULAR_RAGAS[selectedRaga] && (
          <div className="mb-4 bg-emerald-50/70 border border-emerald-200 rounded-lg p-3 text-xs text-emerald-950 flex flex-wrap items-center justify-between gap-2">
            <div>
              <p><strong>Arohana:</strong> {POPULAR_RAGAS[selectedRaga].arohana}</p>
              <p><strong>Avarohana:</strong> {POPULAR_RAGAS[selectedRaga].avarohana}</p>
            </div>
            <span className="text-[11px] font-semibold text-emerald-800 bg-white px-2 py-1 rounded border border-emerald-200">
              {POPULAR_RAGAS[selectedRaga].name}
            </span>
          </div>
        )}

        {/* Swara Key Buttons: Click to play and insert */}
        <div className="grid grid-cols-4 sm:grid-cols-6 lg:grid-cols-12 gap-1.5 mb-4">
          {Object.keys(SWARA_RATIOS).map(swara => (
            <button
              key={swara}
              type="button"
              onClick={() => playSwaraNote(swara)}
              className="p-3 rounded-lg border border-emerald-300 bg-emerald-50 hover:bg-emerald-600 hover:text-white text-emerald-900 font-black text-sm flex flex-col items-center justify-center shadow-2xs transition active:scale-95 cursor-pointer"
            >
              <span>{swara}</span>
              <span className="text-[9px] font-normal opacity-75 mt-0.5">
                {swara === 'S' ? 'Shadjam' : swara.startsWith('R') ? 'Rishabha' : swara.startsWith('G') ? 'Gandhara' : swara.startsWith('M') ? 'Madhyama' : swara === 'P' ? 'Panchama' : swara.startsWith('D') ? 'Dhaivatha' : 'Nishadha'}
              </span>
            </button>
          ))}
        </div>

        {/* Notation Formatting Helpers */}
        <div className="flex flex-wrap items-center gap-1.5 mb-3 text-xs">
          <span className="text-slate-500 font-semibold mr-1">Insert Rhythm:</span>
          {[
            { label: 'Karvai ( , )', val: ' , ' },
            { label: '2-Akshara ( ; )', val: ' ; ' },
            { label: 'Anga Pipe ( | )', val: ' | ' },
            { label: 'Avartanam ( || )', val: ' || ' },
            { label: 'New Line', val: '\n' },
          ].map(h => (
            <button
              key={h.label}
              type="button"
              onClick={() => setNotationText(prev => prev + h.val)}
              className="px-2.5 py-1 rounded bg-slate-100 hover:bg-slate-200 text-slate-800 font-mono text-xs cursor-pointer border border-slate-200"
            >
              {h.label}
            </button>
          ))}
          <button
            type="button"
            onClick={() => setNotationText('')}
            className="ml-auto text-xs text-rose-600 hover:underline cursor-pointer"
          >
            Clear Notation
          </button>
        </div>

        {/* Written Notation Textarea */}
        <textarea
          value={notationText}
          onChange={e => setNotationText(e.target.value)}
          rows={5}
          className="w-full rounded-lg border border-slate-300 p-3 font-mono text-xs text-slate-900 leading-relaxed bg-slate-50/50 focus:outline-hidden focus:border-emerald-500"
          placeholder="Swara notation will be automatically typed here as you play, or you can write manually..."
        />
      </div>

      {/* TOOL 4: AUDIO / VOCAL RECORDING & UPLOAD */}
      <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs">
        <div className="flex items-center gap-2 border-b border-slate-200 pb-3 mb-4">
          <Mic className="w-5 h-5 text-rose-600" />
          <h3 className="text-sm font-bold text-slate-900">4. Live Vocal / Instrumental Audio Recording</h3>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-4 p-4 rounded-xl bg-slate-50 border border-slate-200">
          <div className="flex items-center gap-3">
            {isRecording ? (
              <button
                type="button"
                onClick={stopRecording}
                className="flex items-center gap-2 px-4 py-2 rounded-lg bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow-xs animate-pulse cursor-pointer"
              >
                <Square className="w-4 h-4" />
                <span>Stop Recording ({recordDuration}s)</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={startRecording}
                className="flex items-center gap-2 px-4 py-2 rounded-lg bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow-xs cursor-pointer"
              >
                <Mic className="w-4 h-4" />
                <span>Start Microphone Recording</span>
              </button>
            )}

            <span className="text-xs text-slate-500">or</span>

            <label className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-white border border-slate-300 text-slate-700 hover:bg-slate-100 font-semibold text-xs cursor-pointer shadow-2xs">
              <Upload className="w-3.5 h-3.5" />
              <span>Upload Audio File</span>
              <input type="file" accept="audio/*" className="hidden" onChange={handleAudioUpload} />
            </label>
          </div>

          {recordedAudioUrl && (
            <div className="flex items-center gap-3">
              <span className="text-xs font-bold text-emerald-700 flex items-center gap-1">
                <Check className="w-4 h-4 text-emerald-600" />
                Recording Attached
              </span>
              <audio controls src={recordedAudioUrl} className="h-8" />
            </div>
          )}
        </div>
      </div>

      {/* TOOL 5: THEORY ANSWERS & ESSAY COMMENTS */}
      <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs">
        <label className="text-xs font-bold text-slate-900 block mb-2">
          5. Written Theory Answers & Viva Notes:
        </label>
        <textarea
          value={studentNotes}
          onChange={e => setStudentNotes(e.target.value)}
          rows={4}
          placeholder="Explain the Raga Lakshana, Vadi, Samvadi, Dhyana Shlokam, or notes regarding your vocal rendition for the teacher..."
          className="w-full rounded-lg border border-slate-300 p-3 text-xs text-slate-800 focus:outline-hidden focus:border-amber-500"
        />
      </div>

      {/* Action Footer */}
      <div className="flex items-center justify-between rounded-xl border border-slate-200 bg-white p-4 shadow-xs">
        <button
          type="button"
          onClick={onCancel}
          className="rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
        >
          Cancel
        </button>

        <button
          type="button"
          onClick={handleSubmit}
          className="flex items-center gap-2 rounded-lg bg-amber-600 hover:bg-amber-700 text-white px-6 py-2.5 text-xs font-bold shadow-xs transition active:scale-95 cursor-pointer"
        >
          <Send className="w-4 h-4" />
          <span>Submit Carnatic Task Solution</span>
        </button>
      </div>
    </div>
  );
};
