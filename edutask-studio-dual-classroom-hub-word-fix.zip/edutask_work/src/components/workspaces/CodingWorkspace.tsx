import React, { useState, useEffect } from 'react';
import { Task, ProgrammingLanguage, SubmissionPayload } from '../../types';
import { executeCode, ExecutionResult } from '../../services/codeRunner';
import { 
  Play, 
  Send, 
  Terminal, 
  CheckCircle2, 
  AlertTriangle, 
  RotateCcw,
  Sparkles,
  Cpu,
  BarChart3,
  Table as TableIcon,
  Globe,
  Palette,
  Layers,
  HelpCircle,
  Clock,
  ArrowRight
} from 'lucide-react';

interface CodingWorkspaceProps {
  task: Task;
  onSubmit: (payload: SubmissionPayload) => void;
  onCancel: () => void;
}

const STARTER_TEMPLATES: Record<ProgrammingLanguage, string> = {
  python: `import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# 1. Carnatic Swara frequency ratios
swaras = ['Sa', 'Ri1', 'Ga3', 'Ma1', 'Pa', 'Dha1', 'Ni3', 'Sa_high']
ratios = [1.0, 16/15, 5/4, 4/3, 3/2, 8/5, 15/8, 2.0]
base_frequency = 130.81  # 1 Kattai (C)

# 2. Build Pandas DataFrame
df = pd.DataFrame({
    'Swara': swaras,
    'Ratio': ratios,
    'Frequency_Hz': np.round(np.array(ratios) * base_frequency, 2)
})

print("=== CARNATIC SWARA SPECTRUM (Pandas & NumPy) ===")
print(df)

# 3. Matplotlib Visual Plot
plt.figure(figsize=(8, 4))
plt.plot(df['Swara'], df['Frequency_Hz'], marker='o', color='#818cf8')
plt.title('Raga Mayamalavagowla Acoustic Spectrum')
plt.ylabel('Frequency (Hz)')
plt.grid(True)
plt.show()`,

  html: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <style>
    body {
      font-family: system-ui, -apple-system, sans-serif;
      background: linear-gradient(135deg, #0f172a, #1e1b4b);
      color: #f8fafc;
      padding: 30px;
      margin: 0;
    }
    .card {
      background: rgba(30, 41, 59, 0.8);
      backdrop-filter: blur(10px);
      border: 1px solid #4338ca;
      border-radius: 16px;
      padding: 28px;
      box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.4);
    }
    .badge {
      background: #4f46e5;
      color: #e0e7ff;
      padding: 4px 12px;
      border-radius: 9999px;
      font-size: 12px;
      font-weight: 700;
      letter-spacing: 0.05em;
      text-transform: uppercase;
    }
    h1 {
      color: #38bdf8;
      font-size: 26px;
      margin-top: 12px;
      margin-bottom: 8px;
    }
    p {
      color: #94a3b8;
      line-height: 1.6;
    }
    .stats-grid {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 16px;
      margin-top: 24px;
    }
    .stat-item {
      background: #0f172a;
      border: 1px solid #334155;
      padding: 16px;
      border-radius: 10px;
      text-align: center;
    }
    .stat-val { font-size: 20px; font-weight: 800; color: #a855f7; }
    .stat-lbl { font-size: 11px; color: #64748b; margin-top: 4px; }
  </style>
</head>
<body>
  <div class="card">
    <span class="badge">Live Web Application</span>
    <h1>Classical Sangeeth & Musicology Dashboard</h1>
    <p>Interactive web layout designed with responsive CSS Grid and contemporary glassmorphism.</p>
    
    <div class="stats-grid">
      <div class="stat-item">
        <div class="stat-val">72</div>
        <div class="stat-lbl">Melakarta Ragas</div>
      </div>
      <div class="stat-item">
        <div class="stat-val">35</div>
        <div class="stat-lbl">Tala Variations</div>
      </div>
      <div class="stat-item">
        <div class="stat-val">130.8 Hz</div>
        <div class="stat-lbl">1 Kattai Pitch</div>
      </div>
    </div>
  </div>
</body>
</html>`,

  c: `#include <stdio.h>

int factorial(int n) {
    if (n <= 1) return 1;
    return n * factorial(n - 1);
}

int main() {
    int num = 5;
    printf("=== C COMPUTATIONAL BENCHMARK ===\\n");
    printf("Input Value: %d\\n", num);
    printf("Calculated Factorial(%d) = %d\\n", num, factorial(num));
    return 0;
}`,

  cpp: `#include <iostream>
#include <vector>
#include <numeric>

int main() {
    std::vector<int> swaraIntervals = {1, 2, 4, 5, 7, 8, 11};
    std::cout << "=== C++ 20 SWARA SCALES ===" << std::endl;
    for (int interval : swaraIntervals) {
        std::cout << "Interval Semitone: " << interval << std::endl;
    }
    return 0;
}`,

  javascript: `// JavaScript / Node.js
function calculateSwaraFrequencies(baseHz = 130.81) {
  const ratios = { S: 1.0, R1: 16/15, G3: 5/4, M1: 4/3, P: 3/2, D1: 8/5, N3: 15/8, S_high: 2.0 };
  console.log("=== JAVASCRIPT ACOUSTIC SYNTHESIS ===");
  Object.entries(ratios).forEach(([swara, ratio]) => {
    const hz = (baseHz * ratio).toFixed(2);
    console.log(swara.padEnd(8) + " -> " + hz + " Hz");
  });
}

calculateSwaraFrequencies();`,

  java: `public class Main {
    public static void main(String[] args) {
        System.out.println("=== JAVA OPENJDK 17 EXECUTION ===");
        System.out.println("Computing Fibonacci Series...");
        int n1 = 0, n2 = 1, n3, count = 10;
        System.out.print(n1 + " " + n2);
        for(int i = 2; i < count; ++i) {
            n3 = n1 + n2;
            System.out.print(" " + n3);
            n1 = n2;
            n2 = n3;
        }
        System.out.println();
    }
}`
};

export const CodingWorkspace: React.FC<CodingWorkspaceProps> = ({
  task,
  onSubmit,
  onCancel,
}) => {
  const initialLang = (task.codingConfig?.language as ProgrammingLanguage) || 'python';
  const [language, setLanguage] = useState<ProgrammingLanguage>(initialLang);
  const [code, setCode] = useState<string>(
    task.codingConfig?.starterCode || STARTER_TEMPLATES[initialLang] || STARTER_TEMPLATES.python
  );
  const [stdin, setStdin] = useState<string>(task.codingConfig?.sampleInput || '');
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [lastResult, setLastResult] = useState<ExecutionResult | null>(null);
  
  // Compiler theme: Multi-colour options
  const [compilerTheme, setCompilerTheme] = useState<'tokyo_night' | 'synthwave' | 'dracula' | 'cyberpunk'>('tokyo_night');
  const [activeTab, setActiveTab] = useState<'terminal' | 'plot' | 'table' | 'preview' | 'instructions'>('terminal');

  // Switch starter template when language changes if code is untouched or requested
  const handleLanguageChange = (newLang: ProgrammingLanguage) => {
    setLanguage(newLang);
    setCode(STARTER_TEMPLATES[newLang]);
    setLastResult(null);
    if (newLang === 'html') {
      setActiveTab('preview');
    } else {
      setActiveTab('terminal');
    }
  };

  const handleRunCode = () => {
    setIsRunning(true);
    setTimeout(() => {
      const result = executeCode(language, code, stdin);
      setLastResult(result);
      setIsRunning(false);

      if (language === 'html' && result.htmlPreview) {
        setActiveTab('preview');
      } else if (result.matplotlibPlotUrl) {
        setActiveTab('plot');
      } else if (result.pandasTableHtml) {
        setActiveTab('table');
      } else {
        setActiveTab('terminal');
      }
    }, 240);
  };

  const handleReset = () => {
    if (confirm('Reset code to starter template?')) {
      setCode(STARTER_TEMPLATES[language] || '');
      setLastResult(null);
    }
  };

  const handleSubmitSolution = () => {
    let finalResult = lastResult;
    if (!finalResult) {
      finalResult = executeCode(language, code, stdin);
      setLastResult(finalResult);
    }

    const payload: SubmissionPayload = {
      code,
      codeLanguage: language,
      codeStdout: finalResult.stdout,
      codeStderr: finalResult.stderr,
      codeExecutionSuccess: finalResult.success,
      stdinProvided: stdin,
      matplotlibPlotUrl: finalResult.matplotlibPlotUrl,
      pandasTableHtml: finalResult.pandasTableHtml,
      htmlPreview: finalResult.htmlPreview,
    };

    onSubmit(payload);
  };

  const lineNumbers = code.split('\n').map((_, i) => i + 1);

  // Theme styling configurations (Multi-colour modern VS Code themes)
  const themeStyles = {
    tokyo_night: {
      editorBg: 'bg-[#1a1b26]',
      editorHeader: 'bg-[#16161e] border-[#292e42]',
      gutterBg: 'bg-[#16161e] text-[#565f89] border-[#292e42]',
      textColor: 'text-[#c0caf5]',
      terminalBg: 'bg-[#1a1b26]',
      accentBadge: 'bg-[#7aa2f7]/20 text-[#7aa2f7] border-[#7aa2f7]/30',
      terminalText: 'text-[#7dcfff]',
    },
    synthwave: {
      editorBg: 'bg-[#241b35]',
      editorHeader: 'bg-[#181124] border-[#492b6a]',
      gutterBg: 'bg-[#181124] text-[#8463a5] border-[#492b6a]',
      textColor: 'text-[#f97e72]',
      terminalBg: 'bg-[#241b35]',
      accentBadge: 'bg-[#ff7edb]/20 text-[#ff7edb] border-[#ff7edb]/30',
      terminalText: 'text-[#fede5d]',
    },
    dracula: {
      editorBg: 'bg-[#282a36]',
      editorHeader: 'bg-[#21222c] border-[#44475a]',
      gutterBg: 'bg-[#21222c] text-[#6272a4] border-[#44475a]',
      textColor: 'text-[#f8f8f2]',
      terminalBg: 'bg-[#282a36]',
      accentBadge: 'bg-[#bd93f9]/20 text-[#bd93f9] border-[#bd93f9]/30',
      terminalText: 'text-[#50fa7b]',
    },
    cyberpunk: {
      editorBg: 'bg-[#0b0f19]',
      editorHeader: 'bg-[#06080e] border-[#1e293b]',
      gutterBg: 'bg-[#06080e] text-[#475569] border-[#1e293b]',
      textColor: 'text-[#38bdf8]',
      terminalBg: 'bg-[#0b0f19]',
      accentBadge: 'bg-[#06b6d4]/20 text-[#06b6d4] border-[#06b6d4]/30',
      terminalText: 'text-[#34d399]',
    }
  }[compilerTheme];

  return (
    <div className="flex flex-col gap-4 max-w-7xl mx-auto">
      {/* Top Header & Settings Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-600 text-white flex items-center justify-center font-bold shadow-xs">
            <Cpu className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-indigo-700 bg-indigo-50 px-2.5 py-0.5 rounded-full">
                Multi-Language IDE & Compiler
              </span>
              <span className="text-xs font-bold text-slate-700 bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
                {task.maxPoints} Points
              </span>
            </div>
            <h2 className="text-base font-bold text-slate-900 mt-0.5">{task.title}</h2>
          </div>
        </div>

        {/* Controls: Language, Theme, Reset */}
        <div className="flex flex-wrap items-center gap-2.5">
          {/* Programming Language Selector */}
          <div className="flex items-center gap-1.5 text-xs text-slate-600 font-semibold bg-slate-50 px-2.5 py-1 rounded-xl border border-slate-200">
            <span>Language:</span>
            <select
              value={language}
              onChange={e => handleLanguageChange(e.target.value as ProgrammingLanguage)}
              className="rounded-lg border border-slate-300 bg-white px-2 py-1 text-xs font-bold text-slate-800 focus:outline-hidden"
            >
              <option value="python">Python 3.11 (Matplotlib, Pandas, NumPy)</option>
              <option value="html">HTML5 & CSS3 (Live Web Render)</option>
              <option value="c">C (GCC 12 / C17)</option>
              <option value="cpp">C++ (G++ 20)</option>
              <option value="javascript">JavaScript (Node.js)</option>
              <option value="java">Java (OpenJDK 17)</option>
            </select>
          </div>

          {/* Theme Selector (Multi-Colour Options) */}
          <div className="flex items-center gap-1.5 text-xs text-slate-600 font-semibold bg-slate-50 px-2.5 py-1 rounded-xl border border-slate-200">
            <Palette className="w-3.5 h-3.5 text-purple-600" />
            <span>Theme:</span>
            <select
              value={compilerTheme}
              onChange={e => setCompilerTheme(e.target.value as any)}
              className="rounded-lg border border-slate-300 bg-white px-2 py-1 text-xs font-bold text-slate-800 focus:outline-hidden"
            >
              <option value="tokyo_night">Tokyo Night (Multi-Color)</option>
              <option value="synthwave">Synthwave Neon (Multi-Color)</option>
              <option value="dracula">Dracula Vivid (Multi-Color)</option>
              <option value="cyberpunk">Cyberpunk Sapphire (Multi-Color)</option>
            </select>
          </div>

          <button
            type="button"
            onClick={handleReset}
            className="p-2 text-slate-500 hover:text-slate-800 rounded-xl hover:bg-slate-100 transition border border-slate-200"
            title="Reset code template"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Editor & Execution Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left Column (7 cols): Vibrant Multi-Color Code Editor */}
        <div className={`lg:col-span-7 flex flex-col rounded-2xl border border-slate-800 ${themeStyles.editorBg} overflow-hidden shadow-lg`}>
          {/* Editor Header */}
          <div className={`flex items-center justify-between border-b px-4 py-2.5 ${themeStyles.editorHeader}`}>
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-1.5">
                <div className="w-3 h-3 rounded-full bg-rose-500 shadow-xs"></div>
                <div className="w-3 h-3 rounded-full bg-amber-500 shadow-xs"></div>
                <div className="w-3 h-3 rounded-full bg-emerald-500 shadow-xs"></div>
              </div>
              <span className="text-xs font-mono font-bold text-slate-300 ml-1 flex items-center gap-1.5">
                <span className={`px-2 py-0.5 rounded text-[10px] uppercase font-mono border ${themeStyles.accentBadge}`}>
                  {language}
                </span>
                <span>
                  solution.{language === 'python' ? 'py' : language === 'html' ? 'html' : language === 'javascript' ? 'js' : language === 'cpp' ? 'cpp' : language === 'java' ? 'java' : 'c'}
                </span>
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleRunCode}
                disabled={isRunning}
                className="flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white px-4 py-1.5 text-xs font-bold shadow-md transition active:scale-95 disabled:opacity-50 cursor-pointer"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>{isRunning ? 'Executing...' : 'Run Code'}</span>
              </button>
            </div>
          </div>

          {/* Code Textarea with Multi-Colour Visual Presence */}
          <div className="relative flex flex-1 min-h-[460px] font-mono text-xs">
            {/* Line numbers gutter */}
            <div className={`select-none py-3.5 px-3 text-right border-r w-12 shrink-0 ${themeStyles.gutterBg}`}>
              {lineNumbers.map(n => (
                <div key={n} className="leading-6 font-mono text-[11px]">
                  {n}
                </div>
              ))}
            </div>

            {/* Code Input */}
            <textarea
              value={code}
              onChange={e => setCode(e.target.value)}
              spellCheck={false}
              className={`w-full flex-1 resize-none bg-transparent p-3.5 font-mono text-xs leading-6 ${themeStyles.textColor} focus:outline-hidden selection:bg-indigo-500/40`}
              placeholder="// Write your code or HTML markup here..."
            />
          </div>

          {/* Editor Footer Status */}
          <div className={`flex items-center justify-between border-t px-4 py-2 text-[11px] font-mono text-slate-400 ${themeStyles.editorHeader}`}>
            <span className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
              <span>UTF-8 · 4 Spaces · Multi-Color Active</span>
            </span>
            <span>{code.length} characters · {lineNumbers.length} lines</span>
          </div>
        </div>

        {/* Right Column (5 cols): Dynamic Output Suite */}
        <div className="lg:col-span-5 flex flex-col rounded-2xl border border-slate-200 bg-white overflow-hidden shadow-xs">
          {/* Multi-Tab Navigation */}
          <div className="flex items-center border-b border-slate-200 bg-slate-50 px-2 overflow-x-auto text-xs font-bold">
            <button
              type="button"
              onClick={() => setActiveTab('terminal')}
              className={`flex items-center gap-1.5 py-3 px-3 border-b-2 transition cursor-pointer shrink-0 ${
                activeTab === 'terminal'
                  ? 'border-indigo-600 text-indigo-700'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              <Terminal className="w-3.5 h-3.5" />
              <span>Terminal Output</span>
            </button>

            {/* Matplotlib Tab */}
            {language === 'python' && (
              <button
                type="button"
                onClick={() => setActiveTab('plot')}
                className={`flex items-center gap-1.5 py-3 px-3 border-b-2 transition cursor-pointer shrink-0 ${
                  activeTab === 'plot'
                    ? 'border-indigo-600 text-indigo-700'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                <BarChart3 className="w-3.5 h-3.5 text-purple-600" />
                <span>Matplotlib Plot</span>
              </button>
            )}

            {/* Pandas Table Tab */}
            {language === 'python' && (
              <button
                type="button"
                onClick={() => setActiveTab('table')}
                className={`flex items-center gap-1.5 py-3 px-3 border-b-2 transition cursor-pointer shrink-0 ${
                  activeTab === 'table'
                    ? 'border-indigo-600 text-indigo-700'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                <TableIcon className="w-3.5 h-3.5 text-sky-600" />
                <span>Pandas DataFrame</span>
              </button>
            )}

            {/* HTML Live Preview Tab */}
            {language === 'html' && (
              <button
                type="button"
                onClick={() => setActiveTab('preview')}
                className={`flex items-center gap-1.5 py-3 px-3 border-b-2 transition cursor-pointer shrink-0 ${
                  activeTab === 'preview'
                    ? 'border-indigo-600 text-indigo-700'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                <Globe className="w-3.5 h-3.5 text-emerald-600" />
                <span>Live Web Preview</span>
              </button>
            )}

            <button
              type="button"
              onClick={() => setActiveTab('instructions')}
              className={`flex items-center gap-1.5 py-3 px-3 border-b-2 transition cursor-pointer shrink-0 ${
                activeTab === 'instructions'
                  ? 'border-indigo-600 text-indigo-700'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              <HelpCircle className="w-3.5 h-3.5" />
              <span>Instructions & Stdin</span>
            </button>
          </div>

          {/* Tab Content Display */}
          <div className="flex-1 p-4 bg-[#111827] text-slate-100 flex flex-col justify-between font-mono text-xs overflow-y-auto">
            {/* TAB 1: TERMINAL OUTPUT */}
            {activeTab === 'terminal' && (
              <div className="flex-1 flex flex-col justify-between space-y-3">
                <div>
                  <div className="flex items-center justify-between pb-2 border-b border-slate-800 text-[11px] text-slate-400">
                    <span className="flex items-center gap-1 text-slate-300">
                      <Cpu className="w-3.5 h-3.5 text-indigo-400" />
                      Runtime: {language.toUpperCase()}
                    </span>
                    {lastResult && (
                      <span className={lastResult.success ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                        {lastResult.success ? `Exit 0 (${lastResult.executionTimeMs}ms)` : `Exit ${lastResult.exitCode}`}
                      </span>
                    )}
                  </div>

                  {lastResult?.compileOutput && (
                    <div className="mt-2 text-slate-400 text-[11px] bg-slate-950 p-2.5 rounded-xl border border-slate-800 font-mono whitespace-pre-wrap">
                      <span className="text-indigo-400">$ </span>
                      {lastResult.compileOutput}
                    </div>
                  )}

                  {/* Standard output display */}
                  <div className="mt-3">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">
                        Standard Output (stdout):
                      </span>
                      {lastResult?.matplotlibPlotUrl && (
                        <button
                          type="button"
                          onClick={() => setActiveTab('plot')}
                          className="text-[10px] text-purple-400 hover:underline flex items-center gap-1 cursor-pointer"
                        >
                          View Matplotlib Chart <ArrowRight className="w-3 h-3" />
                        </button>
                      )}
                    </div>
                    <div className="bg-[#0b0f19] p-3.5 rounded-xl border border-slate-800 min-h-[160px] max-h-[260px] overflow-y-auto whitespace-pre-wrap font-mono leading-relaxed text-[#38bdf8]">
                      {isRunning ? (
                        <span className="text-slate-400 animate-pulse">Running compiler and calculating results...</span>
                      ) : lastResult ? (
                        lastResult.stdout || <span className="text-slate-500 italic">[Execution finished with no stdout]</span>
                      ) : (
                        <span className="text-slate-500 italic">Click "Run Code" above to compile and see stdout, matplotlib plots, or pandas tables here.</span>
                      )}
                    </div>
                  </div>

                  {/* Stderr display */}
                  {lastResult?.stderr && (
                    <div className="mt-2">
                      <span className="text-[10px] uppercase font-bold text-rose-400 tracking-wider">
                        Errors & Traceback (stderr):
                      </span>
                      <div className="mt-1 bg-rose-950/40 p-2.5 rounded-xl border border-rose-800/60 text-rose-300 font-mono text-[11px] whitespace-pre-wrap">
                        {lastResult.stderr}
                      </div>
                    </div>
                  )}
                </div>

                {/* Stdin input bar */}
                <div className="pt-2 border-t border-slate-800">
                  <label className="text-[10px] uppercase font-bold text-slate-400 tracking-wider block mb-1">
                    Standard Input (stdin for input() or scanf):
                  </label>
                  <input
                    type="text"
                    value={stdin}
                    onChange={e => setStdin(e.target.value)}
                    placeholder="Enter input values here..."
                    className="w-full rounded-lg bg-slate-950 px-3 py-1.5 text-xs text-slate-200 border border-slate-800 focus:outline-hidden focus:border-indigo-500"
                  />
                </div>
              </div>
            )}

            {/* TAB 2: MATPLOTLIB VISUAL PLOT */}
            {activeTab === 'plot' && (
              <div className="flex-1 flex flex-col justify-between space-y-3">
                <div className="space-y-3">
                  <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                    <span className="font-bold text-white text-xs flex items-center gap-1.5">
                      <BarChart3 className="w-4 h-4 text-purple-400" />
                      Matplotlib Plot Figure
                    </span>
                    <span className="text-[11px] text-purple-300 bg-purple-950/60 px-2 py-0.5 rounded border border-purple-800">
                      Live High-DPI Graphic
                    </span>
                  </div>

                  {lastResult?.matplotlibPlotUrl ? (
                    <div className="rounded-xl overflow-hidden border border-slate-800 shadow-inner bg-slate-950 p-2 flex items-center justify-center">
                      <img
                        src={lastResult.matplotlibPlotUrl}
                        alt="Matplotlib Plot"
                        className="w-full h-auto object-contain rounded-lg"
                      />
                    </div>
                  ) : (
                    <div className="text-center py-12 text-slate-500 font-sans space-y-2">
                      <BarChart3 className="w-10 h-10 text-slate-600 mx-auto" />
                      <p className="text-xs">No Matplotlib chart generated yet.</p>
                      <p className="text-[11px] text-slate-400">
                        Include <code>plt.plot()</code> or <code>plt.bar()</code> and click "Run Code"!
                      </p>
                    </div>
                  )}
                </div>

                <div className="text-[11px] text-slate-400 p-2.5 rounded-lg bg-slate-950 border border-slate-800">
                  💡 Tip: The generated Matplotlib chart is saved directly into your submission so teachers can inspect both your plotting code and visual graph!
                </div>
              </div>
            )}

            {/* TAB 3: PANDAS DATAFRAME VIEW */}
            {activeTab === 'table' && (
              <div className="flex-1 flex flex-col justify-between space-y-3 font-sans">
                <div className="space-y-3">
                  <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                    <span className="font-bold text-white text-xs flex items-center gap-1.5">
                      <TableIcon className="w-4 h-4 text-sky-400" />
                      Pandas DataFrame Representation
                    </span>
                  </div>

                  {lastResult?.pandasTableHtml ? (
                    <div dangerouslySetInnerHTML={{ __html: lastResult.pandasTableHtml }} />
                  ) : (
                    <div className="text-center py-12 text-slate-500 space-y-2">
                      <TableIcon className="w-10 h-10 text-slate-600 mx-auto" />
                      <p className="text-xs">No Pandas DataFrame generated.</p>
                      <p className="text-[11px] text-slate-400">
                        Use <code>pd.DataFrame(...)</code> and click "Run Code" to view formatted tables!
                      </p>
                    </div>
                  )}
                </div>

                <div className="text-[11px] text-slate-400 p-2.5 rounded-lg bg-slate-950 border border-slate-800 font-mono">
                  Pandas v2.2 & NumPy v1.26 active in execution sandbox.
                </div>
              </div>
            )}

            {/* TAB 4: HTML LIVE WEB PREVIEW */}
            {activeTab === 'preview' && (
              <div className="flex-1 flex flex-col justify-between space-y-3 font-sans">
                <div className="flex-1 flex flex-col">
                  <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800">
                    <span className="font-bold text-white text-xs flex items-center gap-1.5">
                      <Globe className="w-4 h-4 text-emerald-400" />
                      Interactive Live Webpage Preview
                    </span>
                    <span className="text-[10px] text-emerald-400 font-mono">localhost:3000/preview</span>
                  </div>

                  <div className="flex-1 rounded-xl overflow-hidden border border-slate-700 bg-white min-h-[300px]">
                    <iframe
                      srcDoc={lastResult?.htmlPreview || code}
                      title="HTML Preview"
                      sandbox="allow-scripts"
                      className="w-full h-full min-h-[320px] border-0"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* TAB 5: INSTRUCTIONS & STDIN */}
            {activeTab === 'instructions' && (
              <div className="text-slate-200 font-sans space-y-3">
                <h4 className="text-sm font-bold text-white">Task Instructions & Expectations</h4>
                <p className="text-xs text-slate-300 leading-relaxed">
                  {task.codingConfig?.instructions || task.description}
                </p>

                {task.codingConfig?.expectedOutput && (
                  <div className="mt-3 p-3 rounded-xl bg-slate-950 border border-slate-800 font-mono text-xs">
                    <span className="text-indigo-400 font-bold block mb-1">Expected Output:</span>
                    <pre className="text-emerald-400">{task.codingConfig.expectedOutput}</pre>
                  </div>
                )}

                <div className="p-3.5 rounded-xl bg-indigo-950/40 border border-indigo-800 text-xs text-indigo-200 space-y-1">
                  <p className="font-bold">✨ Supported Features:</p>
                  <p>• Python 3.11 with <strong>Matplotlib</strong>, <strong>Pandas</strong>, and <strong>NumPy</strong></p>
                  <p>• HTML5 & CSS3 with live interactive web rendering</p>
                  <p>• Stdin inputs for <code>input()</code>, <code>scanf()</code>, and <code>cin</code></p>
                  <p>• Multi-colour syntax theme with clear error diagnostic tracebacks</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Submission Actions */}
      <div className="flex items-center justify-between rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
        <button
          type="button"
          onClick={onCancel}
          className="rounded-xl border border-slate-300 bg-white px-5 py-2.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 transition cursor-pointer"
        >
          Cancel & Return
        </button>

        <div className="flex items-center gap-3">
          {lastResult && (
            <span className="text-xs text-emerald-600 flex items-center gap-1.5 font-bold">
              <CheckCircle2 className="w-4 h-4" />
              Verified Execution
            </span>
          )}

          <button
            type="button"
            onClick={handleSubmitSolution}
            className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white px-6 py-2.5 text-xs font-bold shadow-md transition active:scale-95 cursor-pointer"
          >
            <Send className="w-4 h-4" />
            <span>Submit Solution to Teacher</span>
          </button>
        </div>
      </div>
    </div>
  );
};
