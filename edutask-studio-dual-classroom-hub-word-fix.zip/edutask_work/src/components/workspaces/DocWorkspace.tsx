import React, { useState } from 'react';
import { Task, SubmissionPayload } from '../../types';
import { 
  Bold, 
  Italic, 
  Underline, 
  Strikethrough, 
  AlignLeft, 
  AlignCenter, 
  AlignRight, 
  AlignJustify, 
  List, 
  ListOrdered, 
  Table, 
  FileText, 
  Send, 
  RotateCcw, 
  RotateCw, 
  Type, 
  Palette, 
  Layout, 
  Check, 
  Heading1, 
  Heading2, 
  Quote, 
  Minus, 
  SlidersHorizontal 
} from 'lucide-react';

interface DocWorkspaceProps {
  task: Task;
  onSubmit: (payload: SubmissionPayload) => void;
  onCancel: () => void;
}

const FONT_FAMILIES = [
  { name: 'Calibri (Word Standard)', val: 'font-sans' },
  { name: 'Times New Roman', val: 'font-serif' },
  { name: 'Georgia', val: 'font-serif' },
  { name: 'Arial', val: 'font-sans' },
  { name: 'Courier New (Mono)', val: 'font-mono' },
];

const FONT_SIZES = ['10pt', '11pt', '12pt', '14pt', '16pt', '18pt', '24pt', '32pt'];

const PAGE_THEMES = [
  { name: 'Classic A4 White', bg: 'bg-white', text: 'text-slate-900', border: 'border-slate-300' },
  { name: 'Cream / Eye Care', bg: 'bg-amber-50/50', text: 'text-amber-950', border: 'border-amber-200' },
  { name: 'Academic Parchment', bg: 'bg-orange-50/40', text: 'text-stone-900', border: 'border-orange-200' },
  { name: 'Executive Modern', bg: 'bg-slate-50', text: 'text-slate-900', border: 'border-slate-300' },
];

export const DocWorkspace: React.FC<DocWorkspaceProps> = ({
  task,
  onSubmit,
  onCancel,
}) => {
  const [activeTab, setActiveTab] = useState<'home' | 'insert' | 'layout'>('home');
  const [docTitle, setDocTitle] = useState<string>(task.title || 'Microsoft Word Document');

  // Text formatting states
  const [fontFamily, setFontFamily] = useState<string>('font-serif');
  const [fontSize, setFontSize] = useState<string>('12pt');
  const [isBold, setIsBold] = useState<boolean>(false);
  const [isItalic, setIsItalic] = useState<boolean>(false);
  const [isUnderline, setIsUnderline] = useState<boolean>(false);
  const [isStrike, setIsStrike] = useState<boolean>(false);
  const [textAlign, setTextAlign] = useState<'left' | 'center' | 'right' | 'justify'>('left');
  const [lineSpacing, setLineSpacing] = useState<string>('1.5');
  const [selectedPageTheme, setSelectedPageTheme] = useState<number>(0);
  const [marginSize, setMarginSize] = useState<'normal' | 'narrow' | 'wide'>('normal');

  const [content, setContent] = useState<string>(task.docConfig?.sampleTemplate || '');

  const wordCount = content.trim() ? content.trim().split(/\s+/).length : 0;
  const charCount = content.length;

  const insertSnippet = (snippet: string) => {
    setContent(prev => prev + '\n' + snippet + '\n');
  };

  const handleSubmit = () => {
    const payload: SubmissionPayload = {
      docTitle,
      docContent: content,
      docStyles: {
        fontFamily,
        fontSize,
        textAlign,
        lineSpacing,
        margins: marginSize,
        pageColor: PAGE_THEMES[selectedPageTheme].name,
      },
    };
    onSubmit(payload);
  };

  const activeTheme = PAGE_THEMES[selectedPageTheme];

  const marginPadding = 
    marginSize === 'narrow' ? 'p-6 sm:p-8' :
    marginSize === 'wide' ? 'p-12 sm:p-20' :
    'p-8 sm:p-14';

  return (
    <div className="flex flex-col gap-3 max-w-5xl mx-auto">
      {/* 1. Microsoft Word Window Title Bar */}
      <div className="rounded-xl border border-blue-800 bg-blue-900 text-white px-4 py-2 flex flex-wrap items-center justify-between text-xs shadow-md">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded bg-blue-600 text-white flex items-center justify-center font-bold text-xs shadow-xs">
            W
          </div>
          <span className="font-bold text-sm tracking-tight">{docTitle} - Word</span>
          <span className="text-[10px] bg-blue-800 text-blue-200 px-2 py-0.5 rounded font-mono">
            AutoSaved to Classroom
          </span>
        </div>

        <div className="flex items-center gap-3">
          {task.docConfig?.minWords && (
            <span className={`px-2 py-0.5 rounded text-[11px] font-bold font-mono ${
              wordCount >= task.docConfig.minWords
                ? 'bg-emerald-700 text-white'
                : 'bg-amber-600 text-white'
            }`}>
              {wordCount} / {task.docConfig.minWords} words
            </span>
          )}
          <span className="text-blue-200 text-xs">Total Points: <strong>{task.maxPoints} pts</strong></span>
          <button
            type="button"
            onClick={onCancel}
            className="px-2.5 py-1 rounded bg-blue-800 hover:bg-blue-700 text-blue-200 text-xs font-semibold cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleSubmit}
            className="flex items-center gap-1.5 px-3 py-1 rounded bg-blue-500 hover:bg-blue-400 text-white font-bold transition shadow-xs cursor-pointer"
          >
            <Send className="w-3.5 h-3.5" />
            <span>Turn In to Teacher</span>
          </button>
        </div>
      </div>

      {task.docConfig?.prompt && (
        <div className="bg-amber-50 border border-amber-200 rounded-xl px-4 py-3 text-xs text-amber-950">
          <strong>Teacher instructions:</strong> {task.docConfig.prompt}
          <div className="mt-1 text-amber-800">Follow the structure exactly. EduTask does not automatically correct, rewrite, or grade your document.</div>
        </div>
      )}

      {/* Teacher Template Info Banner */}
      {task.docConfig?.sampleTemplate && (
        <div className="bg-blue-50 border border-blue-200 rounded-xl px-4 py-2.5 flex flex-wrap items-center justify-between text-xs text-blue-900 gap-2 shadow-2xs">
          <div className="flex items-center gap-2">
            <FileText className="w-4 h-4 text-blue-600 shrink-0" />
            <span>
              <strong>Teacher Template Loaded:</strong> Your instructor provided this structured document outline. Follow the section prompts to complete your submission.
            </span>
          </div>
          <button
            type="button"
            onClick={() => {
              if (window.confirm('Reset document to the original teacher template? Any custom edits will be replaced.')) {
                setContent(task.docConfig!.sampleTemplate!);
              }
            }}
            className="px-2.5 py-1 rounded-lg bg-white border border-blue-300 text-blue-800 hover:bg-blue-100 font-bold text-[11px] cursor-pointer shadow-2xs"
          >
            ↺ Reset to Teacher's Template
          </button>
        </div>
      )}

      {/* 2. Microsoft Word Fluent Ribbon Navigation */}
      <div className="rounded-xl border border-slate-300 bg-slate-100 shadow-xs overflow-hidden">
        {/* Ribbon Tab Bar */}
        <div className="flex items-center gap-1 border-b border-slate-300 bg-slate-200/80 px-3 pt-1 text-xs">
          <button
            type="button"
            onClick={() => setActiveTab('home')}
            className={`px-3 py-1.5 rounded-t-lg font-semibold cursor-pointer transition ${
              activeTab === 'home' ? 'bg-white text-blue-700 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Home
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('insert')}
            className={`px-3 py-1.5 rounded-t-lg font-semibold cursor-pointer transition ${
              activeTab === 'insert' ? 'bg-white text-blue-700 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Insert
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('layout')}
            className={`px-3 py-1.5 rounded-t-lg font-semibold cursor-pointer transition ${
              activeTab === 'layout' ? 'bg-white text-blue-700 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Page Layout & Themes
          </button>
        </div>

        {/* Ribbon Action Panels */}
        <div className="p-2.5 bg-white border-b border-slate-200 flex flex-wrap items-center gap-3 text-xs">
          {activeTab === 'home' && (
            <>
              {/* Font Family & Size */}
              <div className="flex items-center gap-1.5 border-r border-slate-200 pr-3">
                <select
                  value={fontFamily}
                  onChange={e => setFontFamily(e.target.value)}
                  className="rounded border border-slate-300 p-1 text-xs font-semibold text-slate-800 bg-white"
                >
                  {FONT_FAMILIES.map(f => (
                    <option key={f.val} value={f.val}>{f.name}</option>
                  ))}
                </select>

                <select
                  value={fontSize}
                  onChange={e => setFontSize(e.target.value)}
                  className="rounded border border-slate-300 p-1 text-xs font-semibold text-slate-800 bg-white"
                >
                  {FONT_SIZES.map(s => (
                    <option key={s} value={s}>{s}</option>
                  ))}
                </select>
              </div>

              {/* Bold, Italic, Underline, Strike */}
              <div className="flex items-center gap-1 border-r border-slate-200 pr-3">
                <button
                  type="button"
                  onClick={() => setIsBold(!isBold)}
                  className={`p-1.5 rounded cursor-pointer ${isBold ? 'bg-blue-100 text-blue-700 font-black' : 'hover:bg-slate-100 text-slate-700'}`}
                  title="Bold (Ctrl+B)"
                >
                  <Bold className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => setIsItalic(!isItalic)}
                  className={`p-1.5 rounded cursor-pointer ${isItalic ? 'bg-blue-100 text-blue-700' : 'hover:bg-slate-100 text-slate-700'}`}
                  title="Italic (Ctrl+I)"
                >
                  <Italic className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => setIsUnderline(!isUnderline)}
                  className={`p-1.5 rounded cursor-pointer ${isUnderline ? 'bg-blue-100 text-blue-700' : 'hover:bg-slate-100 text-slate-700'}`}
                  title="Underline (Ctrl+U)"
                >
                  <Underline className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => setIsStrike(!isStrike)}
                  className={`p-1.5 rounded cursor-pointer ${isStrike ? 'bg-blue-100 text-blue-700' : 'hover:bg-slate-100 text-slate-700'}`}
                  title="Strikethrough"
                >
                  <Strikethrough className="w-4 h-4" />
                </button>
              </div>

              {/* Alignment */}
              <div className="flex items-center gap-1 border-r border-slate-200 pr-3">
                <button
                  type="button"
                  onClick={() => setTextAlign('left')}
                  className={`p-1.5 rounded cursor-pointer ${textAlign === 'left' ? 'bg-blue-100 text-blue-700' : 'hover:bg-slate-100 text-slate-700'}`}
                  title="Align Left"
                >
                  <AlignLeft className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => setTextAlign('center')}
                  className={`p-1.5 rounded cursor-pointer ${textAlign === 'center' ? 'bg-blue-100 text-blue-700' : 'hover:bg-slate-100 text-slate-700'}`}
                  title="Center"
                >
                  <AlignCenter className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => setTextAlign('right')}
                  className={`p-1.5 rounded cursor-pointer ${textAlign === 'right' ? 'bg-blue-100 text-blue-700' : 'hover:bg-slate-100 text-slate-700'}`}
                  title="Align Right"
                >
                  <AlignRight className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => setTextAlign('justify')}
                  className={`p-1.5 rounded cursor-pointer ${textAlign === 'justify' ? 'bg-blue-100 text-blue-700' : 'hover:bg-slate-100 text-slate-700'}`}
                  title="Justify"
                >
                  <AlignJustify className="w-4 h-4" />
                </button>
              </div>

              {/* Line Spacing */}
              <div className="flex items-center gap-1.5">
                <span className="text-slate-500 text-[11px]">Spacing:</span>
                {['1.0', '1.15', '1.5', '2.0'].map(sp => (
                  <button
                    key={sp}
                    type="button"
                    onClick={() => setLineSpacing(sp)}
                    className={`px-1.5 py-0.5 rounded text-[11px] font-mono cursor-pointer ${lineSpacing === sp ? 'bg-blue-600 text-white font-bold' : 'bg-slate-100 text-slate-700'}`}
                  >
                    {sp}
                  </button>
                ))}
              </div>
            </>
          )}

          {activeTab === 'insert' && (
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => insertSnippet(`| Component | Characteristic | Exemplar Kriti |\n|---|---|---|\n| Pallavi | Primary thematic motif | Vatapi Ganapatim |\n| Anupallavi | Secondary ascent & contrast | Raghu Vamsa Sudha |\n| Charanam | Lyrical climax & signature | Endaro Mahanubhavulu |`)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold cursor-pointer shadow-2xs"
              >
                <Table className="w-4 h-4 text-blue-600" />
                <span>Insert Analysis Table</span>
              </button>
              <button
                type="button"
                onClick={() => insertSnippet(`> "Nadopasana is the singular sacred path where melody, intellect, and spiritual liberation converge."\n> — Classical Music Maxim`)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold cursor-pointer shadow-2xs"
              >
                <Quote className="w-4 h-4 text-amber-600" />
                <span>Insert Blockquote / Callout</span>
              </button>
              <button
                type="button"
                onClick={() => insertSnippet(`--------------------------------------------------------------------------------`)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold cursor-pointer shadow-2xs"
              >
                <Minus className="w-4 h-4 text-slate-600" />
                <span>Insert Page Break / Divider</span>
              </button>
            </div>
          )}

          {activeTab === 'layout' && (
            <div className="flex flex-wrap items-center gap-4">
              {/* Margin sizes */}
              <div className="flex items-center gap-1.5">
                <span className="text-slate-500 font-semibold">Margins:</span>
                {(['normal', 'narrow', 'wide'] as const).map(m => (
                  <button
                    key={m}
                    type="button"
                    onClick={() => setMarginSize(m)}
                    className={`px-2.5 py-1 rounded text-xs capitalize cursor-pointer ${
                      marginSize === m ? 'bg-blue-600 text-white font-bold' : 'bg-slate-100 text-slate-700'
                    }`}
                  >
                    {m}
                  </button>
                ))}
              </div>

              {/* Page Paper Theme */}
              <div className="flex items-center gap-1.5">
                <span className="text-slate-500 font-semibold">Paper Styling:</span>
                {PAGE_THEMES.map((theme, idx) => (
                  <button
                    key={theme.name}
                    type="button"
                    onClick={() => setSelectedPageTheme(idx)}
                    className={`px-2.5 py-1 rounded text-xs cursor-pointer border ${
                      selectedPageTheme === idx ? 'bg-blue-50 border-blue-500 text-blue-700 font-bold' : 'bg-white border-slate-300 text-slate-700'
                    }`}
                  >
                    {theme.name}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* 3. Document Canvas: Microsoft Word A4 Styled Page */}
      <div className="bg-slate-200/70 p-6 rounded-2xl border border-slate-300 min-h-[620px] flex justify-center overflow-x-auto">
        <div 
          className={`w-full max-w-4xl min-h-[720px] ${activeTheme.bg} ${activeTheme.text} ${activeTheme.border} ${marginPadding} rounded-lg shadow-xl border flex flex-col justify-between transition-all`}
        >
          <div>
            {/* Header Document Title */}
            <input
              type="text"
              value={docTitle}
              onChange={e => setDocTitle(e.target.value)}
              className="w-full text-2xl font-black text-slate-900 border-b border-slate-200 pb-2 mb-6 focus:outline-hidden bg-transparent"
              placeholder="Enter Document Title..."
            />

            {/* Word Content Textarea formatted with active styles */}
            <textarea
              value={content}
              onChange={e => setContent(e.target.value)}
              rows={20}
              className={`w-full min-h-[520px] resize-y bg-transparent focus:outline-hidden leading-relaxed whitespace-pre-wrap ${fontFamily} ${
                isBold ? 'font-bold' : 'font-normal'
              } ${isItalic ? 'italic' : ''} ${isUnderline ? 'underline' : ''} ${
                isStrike ? 'line-through' : ''
              } ${
                textAlign === 'center' ? 'text-center' :
                textAlign === 'right' ? 'text-right' :
                textAlign === 'justify' ? 'text-justify' : 'text-left'
              }`}
              style={{
                fontSize: fontSize === '10pt' ? '13px' :
                          fontSize === '11pt' ? '14px' :
                          fontSize === '12pt' ? '15px' :
                          fontSize === '14pt' ? '17px' :
                          fontSize === '16pt' ? '20px' :
                          fontSize === '18pt' ? '22px' :
                          fontSize === '24pt' ? '28px' : '36px',
                lineHeight: lineSpacing === '1.0' ? '1.2' : lineSpacing === '1.15' ? '1.4' : lineSpacing === '1.5' ? '1.7' : '2.1'
              }}
              placeholder="Type your essay or document answers here..."
            />
          </div>

          {/* Microsoft Word Page Footer */}
          <div className="pt-4 mt-8 border-t border-slate-200 flex items-center justify-between text-[11px] text-slate-400 font-sans">
            <span>Microsoft Word Format · Certified Academic Paper</span>
            <span>Page 1 of 1</span>
          </div>
        </div>
      </div>

      {/* 4. Microsoft Word Status Bar */}
      <div className="rounded-xl border border-slate-200 bg-white px-4 py-2 flex flex-wrap items-center justify-between text-xs text-slate-500 shadow-xs">
        <div className="flex items-center gap-4">
          <span>Page 1 of 1</span>
          <span>{wordCount} words</span>
          <span>{charCount} characters</span>
          <span>Language: English (India)</span>
        </div>

        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={onCancel}
            className="rounded border border-slate-300 bg-white px-3 py-1 text-slate-700 hover:bg-slate-100 font-semibold cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleSubmit}
            className="rounded bg-blue-600 hover:bg-blue-700 text-white px-4 py-1.5 font-bold shadow-xs transition cursor-pointer"
          >
            Turn In Assignment
          </button>
        </div>
      </div>
    </div>
  );
};
