import React, { useState, useEffect } from 'react';
import { Task, SubmissionPayload } from '../../types';
import { Clock, CheckCircle2, AlertCircle, Send } from 'lucide-react';

interface McqWorkspaceProps {
  task: Task;
  onSubmit: (payload: SubmissionPayload) => void;
  onCancel: () => void;
}

export const McqWorkspace: React.FC<McqWorkspaceProps> = ({
  task,
  onSubmit,
  onCancel,
}) => {
  const questions = task.mcqConfig?.questions || task.quizConfig?.questions || [
    {
      id: 'default-1',
      question: 'Which of the following is an example of an input device?',
      options: ['Keyboard', 'Monitor', 'Printer', 'Speaker'],
      correctOptionIndex: 0,
      points: task.maxPoints || 20,
    },
  ];

  const [selectedAnswers, setSelectedAnswers] = useState<Record<string, number>>({});
  const [timeLeftSeconds, setTimeLeftSeconds] = useState<number | null>(
    task.timeLimitMinutes ? task.timeLimitMinutes * 60 : null
  );

  // Timer countdown
  useEffect(() => {
    if (timeLeftSeconds === null) return;
    if (timeLeftSeconds <= 0) {
      // Auto submit when time expires
      handleSubmit();
      return;
    }

    const timer = setInterval(() => {
      setTimeLeftSeconds(prev => (prev !== null && prev > 0 ? prev - 1 : 0));
    }, 1000);

    return () => clearInterval(timer);
  }, [timeLeftSeconds]);

  const handleSelectOption = (questionId: string, optionIndex: number) => {
    setSelectedAnswers(prev => ({
      ...prev,
      [questionId]: optionIndex,
    }));
  };

  const calculateAutoScore = () => {
    let score = 0;
    questions.forEach(q => {
      if (selectedAnswers[q.id] === q.correctOptionIndex) {
        score += q.points;
      }
    });
    return score;
  };

  const handleSubmit = () => {
    const autoScore = calculateAutoScore();
    const payload: SubmissionPayload = {
      selectedOptions: selectedAnswers,
      autoScore: autoScore,
    };
    onSubmit(payload);
  };

  const formatTimer = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const answeredCount = Object.keys(selectedAnswers).length;
  const totalCount = questions.length;

  return (
    <div className="flex flex-col gap-5 max-w-4xl mx-auto">
      {/* Quiz Header & Timer */}
      <div className="flex flex-wrap items-center justify-between gap-4 rounded-xl border border-slate-200 bg-white p-5 shadow-xs">
        <div>
          <span className="text-xs font-semibold px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 uppercase tracking-wide">
            {task.type === 'quiz' ? 'Interactive Quiz' : 'Timed MCQ Evaluation'}
          </span>
          <h2 className="text-lg font-bold text-slate-900 mt-1">{task.title}</h2>
          <p className="text-xs text-slate-500 mt-0.5">{task.description}</p>
        </div>

        <div className="flex items-center gap-3">
          {timeLeftSeconds !== null && (
            <div className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg border font-mono text-sm font-bold shadow-2xs ${
              timeLeftSeconds < 120 ? 'bg-red-50 text-red-600 border-red-200 animate-pulse' : 'bg-slate-50 text-slate-800 border-slate-200'
            }`}>
              <Clock className="w-4 h-4 text-slate-500" />
              <span>{formatTimer(timeLeftSeconds)}</span>
            </div>
          )}

          <div className="text-xs font-medium text-slate-600 bg-slate-100 px-3 py-1.5 rounded-lg">
            Progress: <strong className="text-slate-900">{answeredCount}/{totalCount}</strong> answered
          </div>
        </div>
      </div>

      {/* Questions list */}
      <div className="space-y-4">
        {questions.map((q, qIndex) => {
          const isAnswered = selectedAnswers[q.id] !== undefined;

          return (
            <div
              key={q.id}
              className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs transition hover:border-slate-300"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-2.5">
                  <span className="w-6 h-6 rounded-full bg-slate-100 text-slate-700 flex items-center justify-center text-xs font-bold shrink-0">
                    {qIndex + 1}
                  </span>
                  <h3 className="text-sm font-semibold text-slate-900">{q.question}</h3>
                </div>
                <span className="text-xs font-medium text-slate-400 shrink-0">
                  {q.points} pts
                </span>
              </div>

              {/* Options */}
              <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {q.options.map((opt, optIndex) => {
                  const isSelected = selectedAnswers[q.id] === optIndex;
                  return (
                    <button
                      key={optIndex}
                      type="button"
                      onClick={() => handleSelectOption(q.id, optIndex)}
                      className={`flex items-center gap-3 p-3 rounded-lg border text-left text-xs font-medium transition cursor-pointer ${
                        isSelected
                          ? 'border-indigo-600 bg-indigo-50/80 text-indigo-950 ring-1 ring-indigo-500 shadow-xs'
                          : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50 hover:border-slate-300'
                      }`}
                    >
                      <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold shrink-0 border ${
                        isSelected
                          ? 'bg-indigo-600 text-white border-indigo-600'
                          : 'bg-slate-100 text-slate-600 border-slate-200'
                      }`}>
                        {String.fromCharCode(65 + optIndex)}
                      </span>
                      <span className="flex-1">{opt}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>

      {/* Action Footer */}
      <div className="flex items-center justify-between rounded-xl border border-slate-200 bg-white p-4 shadow-xs">
        <button
          type="button"
          onClick={onCancel}
          className="rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50"
        >
          Cancel
        </button>

        <div className="flex items-center gap-3">
          {answeredCount < totalCount && (
            <span className="text-xs text-amber-600 flex items-center gap-1 font-medium">
              <AlertCircle className="w-3.5 h-3.5" />
              {totalCount - answeredCount} unanswered questions
            </span>
          )}
          <button
            type="button"
            onClick={handleSubmit}
            className="flex items-center gap-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2 text-xs font-bold shadow-xs transition active:scale-95"
          >
            <Send className="w-3.5 h-3.5" />
            <span>Submit MCQ to Teacher</span>
          </button>
        </div>
      </div>
    </div>
  );
};
