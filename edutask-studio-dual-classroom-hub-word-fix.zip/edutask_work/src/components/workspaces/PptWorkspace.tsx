import React, { useState } from 'react';
import { Task, SubmissionPayload, SlideItem } from '../../types';
import { 
  Presentation, 
  Plus, 
  Trash2, 
  Send, 
  Play, 
  Layout, 
  Palette, 
  Type, 
  Maximize2, 
  X, 
  Copy, 
  ArrowUp, 
  ArrowDown, 
  ListPlus, 
  Sparkles,
  AlignLeft,
  Bold,
  Italic
} from 'lucide-react';

interface PptWorkspaceProps {
  task: Task;
  onSubmit: (payload: SubmissionPayload) => void;
  onCancel: () => void;
}

const PPT_THEMES = [
  { 
    id: 'carnatic_gold', 
    name: 'Carnatic Gold & Maroon (Classical)', 
    bg: 'bg-gradient-to-br from-amber-950 via-red-950 to-stone-900', 
    titleColor: 'text-amber-300', 
    textColor: 'text-amber-100', 
    accent: 'bg-amber-500/20 border-amber-500/40 text-amber-200',
    border: 'border-amber-700/50'
  },
  { 
    id: 'office_navy', 
    name: 'Office 365 Sapphire Navy', 
    bg: 'bg-gradient-to-br from-slate-900 via-blue-950 to-slate-900', 
    titleColor: 'text-blue-300', 
    textColor: 'text-blue-100', 
    accent: 'bg-blue-500/20 border-blue-500/40 text-blue-200',
    border: 'border-blue-700/50'
  },
  { 
    id: 'emerald_academic', 
    name: 'Emerald Academic Sangeeth', 
    bg: 'bg-gradient-to-br from-emerald-950 via-teal-950 to-slate-950', 
    titleColor: 'text-emerald-300', 
    textColor: 'text-emerald-100', 
    accent: 'bg-emerald-500/20 border-emerald-500/40 text-emerald-200',
    border: 'border-emerald-700/50'
  },
  { 
    id: 'modern_dark', 
    name: 'Slate Minimalist Dark', 
    bg: 'bg-gradient-to-br from-slate-950 via-zinc-900 to-black', 
    titleColor: 'text-white', 
    textColor: 'text-zinc-200', 
    accent: 'bg-zinc-800 border-zinc-700 text-zinc-300',
    border: 'border-zinc-700'
  },
  { 
    id: 'clean_light', 
    name: 'Executive Clean Light', 
    bg: 'bg-white', 
    titleColor: 'text-slate-900', 
    textColor: 'text-slate-700', 
    accent: 'bg-slate-100 border-slate-300 text-slate-800',
    border: 'border-slate-300'
  }
];

export const PptWorkspace: React.FC<PptWorkspaceProps> = ({
  task,
  onSubmit,
  onCancel,
}) => {
  const [activeTab, setActiveTab] = useState<'home' | 'design' | 'slideshow'>('home');
  const [selectedThemeIndex, setSelectedThemeIndex] = useState<number>(0);
  const [isFullscreenShow, setIsFullscreenShow] = useState<boolean>(false);
  const [fullscreenSlideIndex, setFullscreenSlideIndex] = useState<number>(0);

  const [slides, setSlides] = useState<SlideItem[]>([
    {
      id: 'slide-1',
      title: task.title || 'The 35 Talas & Sapta Tala Framework',
      bullets: [
        'Suladi Sapta Tala Scheme structured by Purandara Dasa',
        'Five Jathis: Tisra (3), Chatusra (4), Khanda (5), Mishra (7), Sankeerna (9)',
        '35 Distinct Tala permutation matrix'
      ],
      notes: 'Introduce Purandara Dasa as the Pitamaha of Carnatic music and explain the fundamental classification.',
      layout: 'title',
    },
    {
      id: 'slide-2',
      title: 'The Six Angas (Shadangas) in Tala Shastra',
      bullets: [
        'Anudhrutam (U): 1 Akshara (Clap 👏)',
        'Dhrutam (O): 2 Aksharas (Clap + Wave 👏👋)',
        'Laghu (I): Variable count (Clap + finger counts based on Jathi)',
        'Guru (8), Plutam (12), Kakapadam (16): Used in 108 Classical Talas'
      ],
      notes: 'Illustrate the visual Kriyas and explain how Laghu acts as the foundational variable anga.',
      layout: 'content',
    },
    {
      id: 'slide-3',
      title: 'Comparative Analysis: Adi Tala vs Rupaka Tala',
      bullets: [
        'Adi Tala: Chatusra Jathi Triputa Tala = I4 + O + O = 8 Aksharas',
        'Rupaka Tala: Dhrutam + Laghu = O + I4 = 6 Aksharas',
        'Rhythmic cadence and Edduppu (Arudi) placements'
      ],
      notes: 'Contrast 8-beat even cycle with 6-beat asymmetric cycle commonly used in Dikshitar kritis.',
      layout: 'two_column',
    }
  ]);

  const [currentSlideIndex, setCurrentSlideIndex] = useState<number>(0);

  const activeSlide = slides[currentSlideIndex] || slides[0];
  const activeTheme = PPT_THEMES[selectedThemeIndex];

  const handleUpdateSlide = (updated: Partial<SlideItem>) => {
    setSlides(prev => {
      const copy = [...prev];
      copy[currentSlideIndex] = { ...copy[currentSlideIndex], ...updated };
      return copy;
    });
  };

  const handleAddSlide = (layout: 'title' | 'content' | 'two_column' = 'content') => {
    const newSlide: SlideItem = {
      id: 'slide-' + Date.now(),
      title: `Slide ${slides.length + 1}: Sangeetha Topic`,
      bullets: ['Key analytical observation 1', 'Musical insight 2'],
      notes: '',
      layout,
    };
    setSlides(prev => [...prev, newSlide]);
    setCurrentSlideIndex(slides.length);
  };

  const handleDuplicateSlide = () => {
    const dup: SlideItem = {
      ...activeSlide,
      id: 'slide-' + Date.now(),
      title: activeSlide.title + ' (Copy)',
    };
    const newSlides = [...slides];
    newSlides.splice(currentSlideIndex + 1, 0, dup);
    setSlides(newSlides);
    setCurrentSlideIndex(currentSlideIndex + 1);
  };

  const handleDeleteSlide = (index: number) => {
    if (slides.length <= 1) {
      alert('A PowerPoint presentation must contain at least one slide.');
      return;
    }
    const filtered = slides.filter((_, i) => i !== index);
    setSlides(filtered);
    setCurrentSlideIndex(Math.max(0, index - 1));
  };

  const handleMoveSlide = (direction: 'up' | 'down') => {
    if (direction === 'up' && currentSlideIndex === 0) return;
    if (direction === 'down' && currentSlideIndex === slides.length - 1) return;

    const targetIndex = direction === 'up' ? currentSlideIndex - 1 : currentSlideIndex + 1;
    const copy = [...slides];
    const temp = copy[currentSlideIndex];
    copy[currentSlideIndex] = copy[targetIndex];
    copy[targetIndex] = temp;
    setSlides(copy);
    setCurrentSlideIndex(targetIndex);
  };

  const handleBulletChange = (bIndex: number, text: string) => {
    const newBullets = [...activeSlide.bullets];
    newBullets[bIndex] = text;
    handleUpdateSlide({ bullets: newBullets });
  };

  const handleAddBullet = () => {
    handleUpdateSlide({ bullets: [...activeSlide.bullets, 'New analytical bullet point'] });
  };

  const handleDeleteBullet = (bIndex: number) => {
    const newBullets = activeSlide.bullets.filter((_, i) => i !== bIndex);
    handleUpdateSlide({ bullets: newBullets });
  };

  const handleSubmit = () => {
    const payload: SubmissionPayload = {
      slides,
      pptTheme: activeTheme.name,
    };
    onSubmit(payload);
  };

  return (
    <div className="flex flex-col gap-3 max-w-6xl mx-auto">
      {/* 1. PowerPoint Window Title Bar */}
      <div className="rounded-xl border border-orange-800 bg-orange-900 text-white px-4 py-2 flex flex-wrap items-center justify-between text-xs shadow-md">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded bg-orange-600 text-white flex items-center justify-center font-bold text-xs shadow-xs">
            P
          </div>
          <span className="font-bold text-sm tracking-tight">{task.title} - PowerPoint</span>
          <span className="text-[10px] bg-orange-950/80 text-orange-200 px-2 py-0.5 rounded font-mono">
            {slides.length} Slides
          </span>
        </div>

        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => {
              setFullscreenSlideIndex(0);
              setIsFullscreenShow(true);
            }}
            className="flex items-center gap-1.5 px-3 py-1 rounded bg-orange-600 hover:bg-orange-500 text-white font-bold transition shadow-xs cursor-pointer"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>Start Slide Show</span>
          </button>

          <button
            type="button"
            onClick={handleSubmit}
            className="flex items-center gap-1.5 px-3 py-1 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-bold transition shadow-xs cursor-pointer"
          >
            <Send className="w-3.5 h-3.5" />
            <span>Turn In Presentation</span>
          </button>
        </div>
      </div>

      {/* 2. PowerPoint Fluent Ribbon */}
      <div className="rounded-xl border border-slate-300 bg-slate-100 shadow-xs overflow-hidden">
        {/* Ribbon Tabs */}
        <div className="flex items-center gap-1 border-b border-slate-300 bg-slate-200/80 px-3 pt-1 text-xs">
          <button
            type="button"
            onClick={() => setActiveTab('home')}
            className={`px-3 py-1.5 rounded-t-lg font-semibold cursor-pointer transition ${
              activeTab === 'home' ? 'bg-white text-orange-700 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Home
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('design')}
            className={`px-3 py-1.5 rounded-t-lg font-semibold cursor-pointer transition ${
              activeTab === 'design' ? 'bg-white text-orange-700 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Themes & Designs
          </button>
        </div>

        {/* Ribbon Action Toolbar */}
        <div className="p-2.5 bg-white border-b border-slate-200 flex flex-wrap items-center gap-3 text-xs">
          {activeTab === 'home' && (
            <>
              {/* New Slide & Layouts */}
              <div className="flex items-center gap-1.5 border-r border-slate-200 pr-3">
                <button
                  type="button"
                  onClick={() => handleAddSlide('content')}
                  className="flex items-center gap-1 bg-orange-50 hover:bg-orange-100 text-orange-800 font-bold px-3 py-1.5 rounded border border-orange-200 cursor-pointer shadow-2xs"
                >
                  <Plus className="w-4 h-4" />
                  <span>New Slide</span>
                </button>

                <button
                  type="button"
                  onClick={handleDuplicateSlide}
                  className="p-1.5 rounded hover:bg-slate-100 text-slate-700 cursor-pointer"
                  title="Duplicate Slide"
                >
                  <Copy className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => handleMoveSlide('up')}
                  disabled={currentSlideIndex === 0}
                  className="p-1.5 rounded hover:bg-slate-100 disabled:opacity-40 text-slate-700 cursor-pointer"
                  title="Move Slide Up"
                >
                  <ArrowUp className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => handleMoveSlide('down')}
                  disabled={currentSlideIndex === slides.length - 1}
                  className="p-1.5 rounded hover:bg-slate-100 disabled:opacity-40 text-slate-700 cursor-pointer"
                  title="Move Slide Down"
                >
                  <ArrowDown className="w-4 h-4" />
                </button>
              </div>

              {/* Layout Chooser for active slide */}
              <div className="flex items-center gap-1.5 border-r border-slate-200 pr-3">
                <span className="text-slate-500 font-semibold">Layout:</span>
                {(['title', 'content', 'two_column'] as const).map(lay => (
                  <button
                    key={lay}
                    type="button"
                    onClick={() => handleUpdateSlide({ layout: lay })}
                    className={`px-2 py-1 rounded text-xs capitalize cursor-pointer ${
                      activeSlide.layout === lay ? 'bg-orange-600 text-white font-bold' : 'bg-slate-100 text-slate-700'
                    }`}
                  >
                    {lay === 'two_column' ? '2 Column' : lay}
                  </button>
                ))}
              </div>

              {/* Add Bullet */}
              <button
                type="button"
                onClick={handleAddBullet}
                className="flex items-center gap-1 px-2.5 py-1 rounded bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold cursor-pointer"
              >
                <ListPlus className="w-4 h-4 text-orange-600" />
                <span>Add Bullet Point</span>
              </button>
            </>
          )}

          {activeTab === 'design' && (
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-slate-500 font-semibold mr-1">Select Presentation Theme:</span>
              {PPT_THEMES.map((theme, idx) => (
                <button
                  key={theme.id}
                  type="button"
                  onClick={() => setSelectedThemeIndex(idx)}
                  className={`px-3 py-1.5 rounded-lg border text-xs font-semibold cursor-pointer transition ${
                    selectedThemeIndex === idx
                      ? 'bg-orange-50 border-orange-500 text-orange-900 font-bold shadow-xs ring-1 ring-orange-300'
                      : 'bg-white border-slate-300 text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  {theme.name}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* 3. PowerPoint Workspace: Left Thumbnails + Center Slide Canvas */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-start">
        {/* Left Thumbnails Pane (3 cols) */}
        <div className="lg:col-span-3 flex flex-col gap-2.5 max-h-[640px] overflow-y-auto pr-1">
          <div className="flex items-center justify-between text-xs font-bold text-slate-700 pb-1">
            <span>Slide Deck ({slides.length})</span>
            <button
              type="button"
              onClick={() => handleAddSlide('content')}
              className="text-orange-600 hover:underline flex items-center gap-1 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add</span>
            </button>
          </div>

          {slides.map((s, idx) => (
            <div
              key={s.id}
              onClick={() => setCurrentSlideIndex(idx)}
              className={`group relative rounded-xl border p-2.5 transition cursor-pointer flex flex-col justify-between ${
                currentSlideIndex === idx
                  ? 'border-orange-500 bg-orange-50/70 shadow-md ring-2 ring-orange-300'
                  : 'border-slate-300 bg-white hover:border-slate-400'
              }`}
            >
              <div className="flex items-center justify-between text-[11px] font-bold text-slate-500 mb-1.5">
                <span>Slide {idx + 1}</span>
                {slides.length > 1 && (
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleDeleteSlide(idx);
                    }}
                    className="opacity-0 group-hover:opacity-100 text-rose-500 hover:text-rose-700 p-0.5 cursor-pointer"
                    title="Delete slide"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              {/* Mini Slide Preview thumbnail */}
              <div className={`aspect-video w-full rounded-md ${activeTheme.bg} p-2 flex flex-col justify-between overflow-hidden shadow-2xs`}>
                <span className={`text-[10px] font-bold ${activeTheme.titleColor} truncate block`}>
                  {s.title}
                </span>
                <span className="text-[9px] text-slate-400 opacity-60">
                  {s.bullets.length} bullet points
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Center Main Presentation Slide (9 cols) */}
        <div className="lg:col-span-9 flex flex-col gap-3">
          {/* Active 16:9 Presentation Slide Canvas */}
          <div className={`aspect-video w-full rounded-2xl ${activeTheme.bg} ${activeTheme.border} p-8 sm:p-12 shadow-2xl flex flex-col justify-between relative overflow-hidden transition-all border border-slate-700`}>
            <div>
              {/* Slide Meta Bar */}
              <div className="flex items-center justify-between text-xs uppercase tracking-widest font-mono text-slate-400 mb-4 pb-2 border-b border-white/10">
                <span className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-orange-500"></span>
                  <span>Slide {currentSlideIndex + 1} of {slides.length}</span>
                </span>
                <span className={activeTheme.accent + ' px-2 py-0.5 rounded text-[10px] font-bold uppercase'}>
                  {activeSlide.layout === 'title' ? 'Title Slide' : activeSlide.layout === 'two_column' ? 'Comparative Slide' : 'Content Slide'}
                </span>
              </div>

              {/* Editable Slide Title */}
              <input
                type="text"
                value={activeSlide.title}
                onChange={e => handleUpdateSlide({ title: e.target.value })}
                className={`w-full font-black tracking-tight bg-transparent focus:outline-hidden mb-6 ${activeTheme.titleColor} ${
                  activeSlide.layout === 'title' ? 'text-2xl sm:text-4xl' : 'text-xl sm:text-2xl'
                }`}
                placeholder="Click to add slide title..."
              />

              {/* Editable Bullets */}
              <div className="space-y-3">
                {activeSlide.bullets.map((bullet, bi) => (
                  <div key={bi} className="flex items-center gap-2 group">
                    <span className="text-orange-400 font-bold">•</span>
                    <input
                      type="text"
                      value={bullet}
                      onChange={e => handleBulletChange(bi, e.target.value)}
                      className={`flex-1 bg-transparent focus:outline-hidden text-sm sm:text-base ${activeTheme.textColor} border-b border-transparent focus:border-orange-400/50 py-0.5`}
                      placeholder="Type bullet point here..."
                    />
                    {activeSlide.bullets.length > 1 && (
                      <button
                        type="button"
                        onClick={() => handleDeleteBullet(bi)}
                        className="opacity-0 group-hover:opacity-100 text-rose-400 hover:text-rose-300 p-1 cursor-pointer"
                        title="Delete bullet point"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Slide Footer */}
            <div className="pt-4 mt-6 border-t border-white/10 flex items-center justify-between text-[11px] text-slate-400 font-mono">
              <span>{task.title}</span>
              <span>Presentation Slide {currentSlideIndex + 1}</span>
            </div>
          </div>

          {/* Speaker Notes Box */}
          <div className="rounded-xl border border-slate-200 bg-white p-3.5 shadow-xs">
            <label className="text-xs font-bold text-slate-700 block mb-1">
              Presenter Speaker Notes (for Viva / Presentation):
            </label>
            <textarea
              value={activeSlide.notes || ''}
              onChange={e => handleUpdateSlide({ notes: e.target.value })}
              rows={2}
              placeholder="Add personal talking points, Tala explanations, or notes for this slide..."
              className="w-full text-xs text-slate-800 p-2 rounded-lg border border-slate-200 focus:outline-hidden focus:border-orange-500"
            />
          </div>
        </div>
      </div>

      {/* 4. Fullscreen Slide Show Mode Modal */}
      {isFullscreenShow && (
        <div className="fixed inset-0 z-50 bg-black flex flex-col justify-between p-6 sm:p-12">
          {/* Top Bar */}
          <div className="flex items-center justify-between text-white/70 text-xs">
            <span>Slide Show: {fullscreenSlideIndex + 1} of {slides.length}</span>
            <button
              type="button"
              onClick={() => setIsFullscreenShow(false)}
              className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-white cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Slide in Full View */}
          <div className="max-w-4xl mx-auto w-full my-auto text-center space-y-6">
            <h1 className="text-3xl sm:text-5xl font-black text-white">
              {slides[fullscreenSlideIndex]?.title}
            </h1>
            <ul className="space-y-4 text-lg sm:text-xl text-slate-200 max-w-2xl mx-auto text-left list-disc list-inside">
              {slides[fullscreenSlideIndex]?.bullets.map((b, bi) => (
                <li key={bi}>{b}</li>
              ))}
            </ul>
          </div>

          {/* Navigation Controls */}
          <div className="flex items-center justify-center gap-4 text-white">
            <button
              type="button"
              onClick={() => setFullscreenSlideIndex(Math.max(0, fullscreenSlideIndex - 1))}
              disabled={fullscreenSlideIndex === 0}
              className="px-4 py-2 rounded-lg bg-white/20 hover:bg-white/30 disabled:opacity-30 cursor-pointer font-bold text-sm"
            >
              Previous Slide
            </button>
            <span className="font-mono text-sm">{fullscreenSlideIndex + 1} / {slides.length}</span>
            <button
              type="button"
              onClick={() => setFullscreenSlideIndex(Math.min(slides.length - 1, fullscreenSlideIndex + 1))}
              disabled={fullscreenSlideIndex === slides.length - 1}
              className="px-4 py-2 rounded-lg bg-white/20 hover:bg-white/30 disabled:opacity-30 cursor-pointer font-bold text-sm"
            >
              Next Slide
            </button>
          </div>
        </div>
      )}

      {/* Action Footer */}
      <div className="flex items-center justify-between rounded-xl border border-slate-200 bg-white p-4 shadow-xs">
        <button
          type="button"
          onClick={onCancel}
          className="rounded border border-slate-300 bg-white px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100 cursor-pointer"
        >
          Cancel
        </button>

        <button
          type="button"
          onClick={handleSubmit}
          className="flex items-center gap-2 rounded bg-orange-600 hover:bg-orange-700 text-white px-6 py-2.5 text-xs font-bold shadow-xs transition active:scale-95 cursor-pointer"
        >
          <Send className="w-4 h-4" />
          <span>Turn In Presentation ({slides.length} Slides)</span>
        </button>
      </div>
    </div>
  );
};
