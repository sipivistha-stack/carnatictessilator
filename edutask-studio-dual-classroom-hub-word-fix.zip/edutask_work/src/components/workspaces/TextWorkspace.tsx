import React, { useState } from 'react';
import { Task, SubmissionPayload } from '../../types';
import { Send, FileText } from 'lucide-react';

interface TextWorkspaceProps {
  task: Task;
  onSubmit: (payload: SubmissionPayload) => void;
  onCancel: () => void;
}

export const TextWorkspace: React.FC<TextWorkspaceProps> = ({
  task,
  onSubmit,
  onCancel,
}) => {
  const [response, setResponse] = useState<string>('');

  const wordCount = response.trim() ? response.trim().split(/\s+/).length : 0;
  const charCount = response.length;
  const minChars = task.textConfig?.minCharacters || 0;

  const handleSubmit = () => {
    if (!response.trim()) {
      alert('Please enter a response before submitting.');
      return;
    }
    const payload: SubmissionPayload = {
      textResponse: response,
    };
    onSubmit(payload);
  };

  return (
    <div className="flex flex-col gap-4 max-w-3xl mx-auto">
      {/* Header */}
      <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs">
        <span className="text-xs font-semibold px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 uppercase tracking-wide">
          Text Entry Task
        </span>
        <h2 className="text-base font-bold text-slate-900 mt-1">{task.title}</h2>
        <p className="text-xs text-slate-600 mt-1 leading-relaxed">
          {task.textConfig?.prompt || task.description}
        </p>
      </div>

      {/* Input area */}
      <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs">
        <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-100 text-xs text-slate-500">
          <span>Your Written Response:</span>
          <span>
            {wordCount} words · {charCount} chars {minChars > 0 && `(min: ${minChars})`}
          </span>
        </div>
        <textarea
          value={response}
          onChange={e => setResponse(e.target.value)}
          rows={10}
          placeholder="Compose your structured response here..."
          className="w-full text-sm text-slate-800 p-2 focus:outline-hidden leading-relaxed resize-y"
        />
      </div>

      {/* Action Footer */}
      <div className="flex items-center justify-between rounded-xl border border-slate-200 bg-white p-4 shadow-xs">
        <button
          type="button"
          onClick={onCancel}
          className="rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50"
        >
          Cancel
        </button>

        <button
          type="button"
          onClick={handleSubmit}
          className="flex items-center gap-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2 text-xs font-bold shadow-xs transition active:scale-95"
        >
          <Send className="w-3.5 h-3.5" />
          <span>Submit Response to Teacher</span>
        </button>
      </div>
    </div>
  );
};
