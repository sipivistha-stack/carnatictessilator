import React, { useState, useEffect, useRef } from 'react';
import { Task, SubmissionPayload } from '../../types';
import { Keyboard, Clock, CheckCircle2, RotateCcw, Send, AlertTriangle } from 'lucide-react';

interface TypingWorkspaceProps {
  task: Task;
  onSubmit: (payload: SubmissionPayload) => void;
  onCancel: () => void;
}

const DEFAULT_PASSAGE = 
  `Carnatic music is a system of music commonly associated with southern India. It is one of two main subgenres of Indian classical music that evolved from ancient Hindu traditions, the other subgenre being Hindustani music. The main emphasis in Carnatic music is on vocal music; most compositions are written to be sung, and even when played on instruments, they are meant to be performed in a singing style termed gayaki. The basic components of Carnatic music are Raga, which provides the melodic framework, and Tala, which provides the rhythmic foundation. Learning Carnatic music disciplines the mind and purifies the aesthetic senses through deep devotion and melodic symmetry.`;

export const TypingWorkspace: React.FC<TypingWorkspaceProps> = ({
  task,
  onSubmit,
  onCancel,
}) => {
  const passage = task.typingConfig?.passage || DEFAULT_PASSAGE;
  const timeLimitSeconds = task.typingConfig?.timeLimitSeconds || (task.timeLimitMinutes ? task.timeLimitMinutes * 60 : 300);

  const [input, setInput] = useState<string>('');
  const [timeLeft, setTimeLeft] = useState<number>(timeLimitSeconds);
  const [isStarted, setIsStarted] = useState<boolean>(false);
  const [isFinished, setIsFinished] = useState<boolean>(false);

  const timerRef = useRef<any>(null);

  useEffect(() => {
    if (isStarted && !isFinished && timeLeft > 0) {
      timerRef.current = setInterval(() => {
        setTimeLeft(prev => {
          if (prev <= 1) {
            clearInterval(timerRef.current);
            setIsFinished(true);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(timerRef.current);
  }, [isStarted, isFinished, timeLeft]);

  // Handle typing input
  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    if (isFinished) return;
    if (!isStarted) setIsStarted(true);

    const val = e.target.value;
    setInput(val);

    if (val.length >= passage.length) {
      setIsFinished(true);
      clearInterval(timerRef.current);
    }
  };

  // Metrics
  const timeSpentSeconds = Math.max(1, timeLimitSeconds - timeLeft);
  const minutes = timeSpentSeconds / 60;
  const wordCount = input.trim() ? input.trim().split(/\s+/).length : 0;
  const wpm = Math.round(wordCount / minutes) || 0;

  // Accuracy calculation
  let correctChars = 0;
  for (let i = 0; i < input.length; i++) {
    if (input[i] === passage[i]) correctChars++;
  }
  const accuracy = input.length > 0 ? Math.round((correctChars / input.length) * 100) : 100;

  const handleSubmit = () => {
    const payload: SubmissionPayload = {
      typingSpeedWpm: wpm,
      typingAccuracyPercentage: accuracy,
      typingCompletedText: input,
      textResponse: `Typing Speed: ${wpm} WPM | Accuracy: ${accuracy}% | Time Elapsed: ${timeSpentSeconds}s`,
    };
    onSubmit(payload);
  };

  const handleReset = () => {
    clearInterval(timerRef.current);
    setInput('');
    setTimeLeft(timeLimitSeconds);
    setIsStarted(false);
    setIsFinished(false);
  };

  return (
    <div className="flex flex-col gap-5 max-w-4xl mx-auto">
      {/* Header */}
      <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs flex flex-wrap items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded">
            Examination Mode · Typing Speed & Precision
          </span>
          <h2 className="text-lg font-bold text-slate-900 mt-1">{task.title}</h2>
          <p className="text-xs text-slate-500 mt-0.5">{task.description}</p>
        </div>

        {/* Live Metrics */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 bg-slate-100 px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-mono font-bold text-slate-700">
            <Clock className="w-4 h-4 text-indigo-600" />
            <span>{Math.floor(timeLeft / 60)}:{(timeLeft % 60).toString().padStart(2, '0')}</span>
          </div>
          <div className="bg-emerald-50 px-3 py-1.5 rounded-lg border border-emerald-200 text-xs font-bold text-emerald-800">
            {wpm} WPM
          </div>
          <div className="bg-blue-50 px-3 py-1.5 rounded-lg border border-blue-200 text-xs font-bold text-blue-800">
            {accuracy}% Accuracy
          </div>
        </div>
      </div>

      {/* Target Passage */}
      <div className="rounded-xl border border-slate-300 bg-slate-50 p-6 font-serif text-sm leading-relaxed text-slate-700 select-none shadow-xs">
        <h4 className="font-sans text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
          Examination Text Passage:
        </h4>
        <div className="p-4 bg-white rounded-lg border border-slate-200 shadow-2xs">
          {passage.split('').map((char, index) => {
            let color = 'text-slate-800';
            if (index < input.length) {
              color = input[index] === char ? 'text-emerald-600 bg-emerald-50 font-semibold' : 'text-rose-600 bg-rose-100 line-through';
            }
            return (
              <span key={index} className={color}>
                {char}
              </span>
            );
          })}
        </div>
      </div>

      {/* Typing Input */}
      <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs">
        <label className="text-xs font-bold text-slate-900 block mb-2">
          {isFinished ? 'Examination Completed' : isStarted ? 'Type actively below:' : 'Start typing to begin examination timer:'}
        </label>
        <textarea
          value={input}
          onChange={handleInputChange}
          disabled={isFinished}
          rows={6}
          placeholder="Start typing the passage above here..."
          className="w-full rounded-lg border border-slate-300 p-4 font-mono text-sm leading-relaxed text-slate-900 focus:outline-hidden focus:border-indigo-500 bg-white"
        />
      </div>

      {/* Footer Actions */}
      <div className="flex items-center justify-between rounded-xl border border-slate-200 bg-white p-4 shadow-xs">
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onCancel}
            className="rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleReset}
            className="flex items-center gap-1 text-xs text-slate-600 hover:text-slate-900 px-3 py-2 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset</span>
          </button>
        </div>

        <button
          type="button"
          onClick={handleSubmit}
          className="flex items-center gap-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-2.5 text-xs font-bold shadow-xs transition active:scale-95 cursor-pointer"
        >
          <Send className="w-4 h-4" />
          <span>Submit Examination Script</span>
        </button>
      </div>
    </div>
  );
};
