import React, { useState } from 'react';
import { Announcement, AnnouncementPriority, ClassGroup } from '../../types';
import { 
  getAnnouncements, 
  addAnnouncement, 
  deleteAnnouncement, 
  togglePinAnnouncement, 
  getClasses, 
  getCurrentClass 
} from '../../data/storage';
import { 
  X, 
  Megaphone, 
  Pin, 
  Trash2, 
  Plus, 
  AlertTriangle, 
  Info, 
  CheckCircle2, 
  Calendar, 
  Tag, 
  FileText, 
  Sparkles, 
  ShieldCheck 
} from 'lucide-react';

interface AnnouncementManagerModalProps {
  onClose: () => void;
  onAnnouncementsUpdated?: () => void;
}

export const AnnouncementManagerModal: React.FC<AnnouncementManagerModalProps> = ({
  onClose,
  onAnnouncementsUpdated,
}) => {
  const classes = getClasses();
  const currentClass = getCurrentClass();

  const [announcements, setAnnouncements] = useState<Announcement[]>(() => getAnnouncements());
  const [activeTab, setActiveTab] = useState<'create' | 'feed'>('create');

  // Form states
  const [title, setTitle] = useState<string>('');
  const [content, setContent] = useState<string>('');
  const [priority, setPriority] = useState<AnnouncementPriority>('important');
  const [targetClassId, setTargetClassId] = useState<string>('all');
  const [postedBy, setPostedBy] = useState<string>('Vidwan K. Narayanaswamy (Lead Guru & HOD)');
  const [pinned, setPinned] = useState<boolean>(true);
  const [tagsInput, setTagsInput] = useState<string>('Important, Examination, Attendance');
  const [successToast, setSuccessToast] = useState<string | null>(null);

  const refreshList = () => {
    const updated = getAnnouncements();
    setAnnouncements(updated);
    if (onAnnouncementsUpdated) {
      onAnnouncementsUpdated();
    }
  };

  const handlePost = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !content.trim()) return;

    const tags = tagsInput
      .split(',')
      .map(t => t.trim())
      .filter(t => t.length > 0);

    addAnnouncement({
      title: title.trim(),
      content: content.trim(),
      priority,
      classId: targetClassId,
      postedBy: postedBy.trim() || 'Lead Faculty',
      pinned,
      tags,
    });

    setTitle('');
    setContent('');
    setSuccessToast('Important Announcement posted and broadcasted to students.');
    setTimeout(() => setSuccessToast(null), 3500);
    refreshList();
    setActiveTab('feed');
  };

  const handleDelete = (id: string) => {
    deleteAnnouncement(id);
    refreshList();
  };

  const handleTogglePin = (id: string) => {
    togglePinAnnouncement(id);
    refreshList();
  };

  const loadPreset = (preset: { title: string; content: string; priority: AnnouncementPriority; tags: string }) => {
    setTitle(preset.title);
    setContent(preset.content);
    setPriority(preset.priority);
    setTagsInput(preset.tags);
    setPinned(true);
    setActiveTab('create');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/70 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="relative w-full max-w-4xl rounded-2xl bg-white shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh]">
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-amber-600 via-orange-600 to-amber-700 p-6 text-white flex items-center justify-between border-b border-amber-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-xs flex items-center justify-center font-bold text-white shadow-xs">
              <Megaphone className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs uppercase tracking-widest font-bold text-amber-200">
                  Faculty Broadcasting Station
                </span>
                <span className="text-[10px] bg-amber-900/40 text-amber-100 px-2 py-0.5 rounded-full font-mono border border-amber-400/30">
                  Student Live Feed
                </span>
              </div>
              <h2 className="text-xl font-black text-white tracking-tight mt-0.5">
                Post & Manage Important Announcements
              </h2>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-1.5 text-amber-200 hover:bg-white/10 hover:text-white transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switcher */}
        <div className="flex items-center justify-between border-b border-slate-200 bg-slate-50 px-6 pt-3">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setActiveTab('create')}
              className={`px-4 py-2 font-bold text-xs rounded-t-xl transition cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'create'
                  ? 'bg-white text-amber-900 border-t-2 border-amber-600 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Create New Announcement</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('feed')}
              className={`px-4 py-2 font-bold text-xs rounded-t-xl transition cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'feed'
                  ? 'bg-white text-amber-900 border-t-2 border-amber-600 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Megaphone className="w-3.5 h-3.5" />
              <span>Active Bulletin Board ({announcements.length})</span>
            </button>
          </div>

          <span className="text-[11px] text-slate-500 font-sans">
            Visible on Teacher & Student Dashboards
          </span>
        </div>

        {/* Tab 1: Create Announcement Form */}
        {activeTab === 'create' && (
          <div className="p-6 overflow-y-auto flex-1 space-y-5">
            {/* Quick Presets Bar */}
            <div className="p-3.5 rounded-xl bg-amber-50/70 border border-amber-200 text-xs space-y-2">
              <span className="font-bold text-amber-950 flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-amber-700" />
                Quick Announcement Templates:
              </span>
              <div className="flex flex-wrap gap-2">
                <button
                  type="button"
                  onClick={() => loadPreset({
                    title: '⚠️ Strict 75% Minimum Attendance Requirement for Final Examinations',
                    content: 'Attention all candidates: As per Academic Board Section 14(b), candidates with attendance below 75% are ineligible to sit for the semester examination. Review your attendance status in the student portal immediately.',
                    priority: 'exam_alert',
                    tags: 'Attendance, Exam Rule, Mandatory'
                  })}
                  className="px-2.5 py-1 rounded-lg bg-white border border-rose-300 text-rose-900 hover:bg-rose-50 text-[11px] font-bold cursor-pointer transition shadow-2xs"
                >
                  ⚠️ 75% Attendance Exam Rule
                </button>

                <button
                  type="button"
                  onClick={() => loadPreset({
                    title: 'Carnatic Sangeeth Theory & Viva Assessment Guidelines',
                    content: 'Internal Assessment schedule: Part A Theory (40 Marks) + Part B Singing Viva (10 Marks). Keep your Shruti Box and Tala Metronome calibrated in the Carnatic tools workspace.',
                    priority: 'important',
                    tags: 'Carnatic Music, Viva, Theory Paper'
                  })}
                  className="px-2.5 py-1 rounded-lg bg-white border border-amber-300 text-amber-900 hover:bg-amber-50 text-[11px] font-bold cursor-pointer transition shadow-2xs"
                >
                  📢 Carnatic Sangeeth Exam Guidelines
                </button>

                <button
                  type="button"
                  onClick={() => loadPreset({
                    title: 'Word Document Assignment: Structured Template Provided',
                    content: 'Students writing the Classical Kriti Research Assignment: A comprehensive Word document starting template with pre-formatted sections has been provided. Load the template in the document editor.',
                    priority: 'important',
                    tags: 'Word Document, Assignment Template, Thesis'
                  })}
                  className="px-2.5 py-1 rounded-lg bg-white border border-blue-300 text-blue-900 hover:bg-blue-50 text-[11px] font-bold cursor-pointer transition shadow-2xs"
                >
                  📄 Word Document Template Notice
                </button>
              </div>
            </div>

            <form onSubmit={handlePost} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {/* Priority Selector */}
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Notice Priority Level:</label>
                  <select
                    value={priority}
                    onChange={e => setPriority(e.target.value as AnnouncementPriority)}
                    className="w-full rounded-xl border border-slate-300 p-2.5 font-bold text-slate-900 bg-white"
                  >
                    <option value="important">📢 Important Announcement (Amber)</option>
                    <option value="exam_alert">⚠️ Examination & Attendance Alert (Red)</option>
                    <option value="normal">ℹ️ General Notice (Blue)</option>
                  </select>
                </div>

                {/* Target Classroom */}
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Target Classroom:</label>
                  <select
                    value={targetClassId}
                    onChange={e => setTargetClassId(e.target.value)}
                    className="w-full rounded-xl border border-slate-300 p-2.5 font-semibold text-slate-800 bg-white"
                  >
                    <option value="all">All Classrooms (Broadcast)</option>
                    {classes.map(c => (
                      <option key={c.id} value={c.id}>{c.name}</option>
                    ))}
                  </select>
                </div>

                {/* Author */}
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Issued By / Faculty Signature:</label>
                  <input
                    type="text"
                    value={postedBy}
                    onChange={e => setPostedBy(e.target.value)}
                    className="w-full rounded-xl border border-slate-300 p-2 bg-white font-semibold text-slate-800"
                    placeholder="e.g. Lead Music Faculty"
                  />
                </div>
              </div>

              {/* Title */}
              <div>
                <label className="font-bold text-slate-700 block mb-1">Announcement Title:</label>
                <input
                  type="text"
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  placeholder="e.g. ⚠️ Urgent Notice: Minimum 75% Attendance Required for Semester Exams"
                  className="w-full rounded-xl border border-slate-300 p-2.5 text-xs font-bold text-slate-900 bg-white focus:outline-hidden focus:border-amber-500"
                  required
                />
              </div>

              {/* Content */}
              <div>
                <label className="font-bold text-slate-700 block mb-1">Announcement Details / Circular Text:</label>
                <textarea
                  value={content}
                  onChange={e => setContent(e.target.value)}
                  rows={4}
                  placeholder="Provide detailed instructions, rules, or guidelines for students..."
                  className="w-full rounded-xl border border-slate-300 p-3 text-xs text-slate-800 bg-white focus:outline-hidden focus:border-amber-500 leading-relaxed"
                  required
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Tags */}
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Tags (Comma-separated):</label>
                  <input
                    type="text"
                    value={tagsInput}
                    onChange={e => setTagsInput(e.target.value)}
                    placeholder="Attendance, Exam, Carnatic Music"
                    className="w-full rounded-xl border border-slate-300 p-2 bg-white font-medium text-slate-800"
                  />
                </div>

                {/* Pinned toggle */}
                <div className="flex items-center justify-between p-3 rounded-xl border border-slate-200 bg-slate-50">
                  <div>
                    <span className="font-bold text-slate-900 block flex items-center gap-1.5">
                      <Pin className="w-3.5 h-3.5 text-amber-600" />
                      Pin to Top of Student Portal
                    </span>
                    <span className="text-[11px] text-slate-500">
                      Displays in high-visibility banner above coursework
                    </span>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={pinned}
                      onChange={e => setPinned(e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-slate-300 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-amber-600"></div>
                  </label>
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
                <button
                  type="submit"
                  className="flex items-center gap-1.5 px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 text-white font-bold text-xs shadow-md transition active:scale-95 cursor-pointer"
                >
                  <Megaphone className="w-4 h-4" />
                  <span>Publish Announcement to Class</span>
                </button>
              </div>
            </form>
          </div>
        )}

        {/* Tab 2: Feed of Announcements */}
        {activeTab === 'feed' && (
          <div className="p-6 overflow-y-auto flex-1 space-y-4">
            {announcements.length > 0 ? (
              <div className="space-y-3">
                {announcements.map(ann => {
                  const isExamAlert = ann.priority === 'exam_alert';
                  const isImportant = ann.priority === 'important';

                  return (
                    <div
                      key={ann.id}
                      className={`p-5 rounded-2xl border transition shadow-xs ${
                        isExamAlert 
                          ? 'border-rose-300 bg-rose-50/50' 
                          : isImportant 
                          ? 'border-amber-300 bg-amber-50/50' 
                          : 'border-slate-200 bg-white'
                      }`}
                    >
                      <div className="flex flex-wrap items-center justify-between gap-2 pb-3 mb-2 border-b border-slate-200/80">
                        <div className="flex items-center gap-2 flex-wrap">
                          {/* Priority Pill */}
                          <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider flex items-center gap-1 ${
                            isExamAlert ? 'bg-rose-600 text-white shadow-xs' :
                            isImportant ? 'bg-amber-600 text-white shadow-xs' :
                            'bg-blue-600 text-white shadow-xs'
                          }`}>
                            {isExamAlert ? <AlertTriangle className="w-3 h-3" /> :
                             isImportant ? <Megaphone className="w-3 h-3" /> :
                             <Info className="w-3 h-3" />}
                            <span>{ann.priority.replace('_', ' ')}</span>
                          </span>

                          {ann.pinned && (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-300 flex items-center gap-1">
                              <Pin className="w-3 h-3 text-amber-700" />
                              <span>Pinned to Top</span>
                            </span>
                          )}

                          <span className="text-[11px] text-slate-500 font-mono">
                            {new Date(ann.postedAt).toLocaleString()}
                          </span>
                        </div>

                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => handleTogglePin(ann.id)}
                            className={`p-1.5 rounded-lg border text-xs font-bold cursor-pointer transition ${
                              ann.pinned ? 'bg-amber-100 border-amber-300 text-amber-800' : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                            }`}
                            title={ann.pinned ? 'Unpin announcement' : 'Pin to top'}
                          >
                            <Pin className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDelete(ann.id)}
                            className="p-1.5 rounded-lg border border-rose-200 bg-white text-rose-600 hover:bg-rose-50 cursor-pointer transition"
                            title="Delete announcement"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      <h3 className="text-sm font-bold text-slate-900 leading-snug">
                        {ann.title}
                      </h3>

                      <p className="text-xs text-slate-700 mt-2 leading-relaxed whitespace-pre-wrap">
                        {ann.content}
                      </p>

                      <div className="flex flex-wrap items-center justify-between gap-2 mt-4 pt-3 border-t border-slate-200/60 text-[11px] text-slate-500">
                        <span>Issued by: <strong>{ann.postedBy}</strong></span>
                        {ann.tags && ann.tags.length > 0 && (
                          <div className="flex items-center gap-1 flex-wrap">
                            <Tag className="w-3 h-3 text-slate-400" />
                            {ann.tags.map((tg, idx) => (
                              <span key={idx} className="bg-slate-200/80 text-slate-700 px-1.5 py-0.5 rounded font-mono text-[10px]">
                                #{tg}
                              </span>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="p-12 text-center border border-dashed border-slate-300 rounded-xl bg-slate-50 space-y-2">
                <Megaphone className="w-10 h-10 text-slate-400 mx-auto" />
                <h4 className="text-sm font-bold text-slate-700">No Active Announcements</h4>
                <p className="text-xs text-slate-500 max-w-sm mx-auto">
                  Click 'Create New Announcement' to publish notices to your classes.
                </p>
              </div>
            )}
          </div>
        )}

        {/* Footer */}
        <div className="p-4 bg-slate-100 border-t border-slate-200 flex items-center justify-between">
          {successToast ? (
            <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-800 bg-emerald-100 px-3 py-1.5 rounded-lg border border-emerald-300">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>{successToast}</span>
            </div>
          ) : (
            <span className="text-xs text-slate-500">
              Announcements notify enrolled students of schedule changes and examination eligibility policies.
            </span>
          )}

          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl border border-slate-300 bg-white font-bold text-xs text-slate-700 hover:bg-slate-50 cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
