import React, { useState } from 'react';
import { 
  Task, 
  TaskCategory, 
  TaskType, 
  ProgrammingLanguage,
  InterconnectedTaskBundle,
  ClassGroup,
  QuizQuestion 
} from '../../types';
import { getTaskBundles, saveTaskBundle, getClasses } from '../../data/storage';
import { generateQuizWithAI } from '../../services/aiQuizGenerator';
import { generateStudentSubmissionsForTask } from '../../services/aiStudentSimulator';
import { parseDocxText } from '../../services/docxParser';
import { 
  X, 
  CheckCircle2,
  Code2, 
  CheckSquare, 
  FileText, 
  Presentation, 
  Table, 
  Upload, 
  Video, 
  Image as ImageIcon, 
  AlignLeft, 
  PenTool, 
  HelpCircle,
  Clock,
  Sparkles,
  Music,
  Keyboard,
  ShieldAlert,
  Link2,
  Sliders,
  Radio,
  Mic,
  BookOpen,
  Globe
} from 'lucide-react';

interface TaskCreateModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaveTask: (task: Task) => void;
  defaultCategory?: TaskCategory;
}

export const TaskCreateModal: React.FC<TaskCreateModalProps> = ({
  isOpen,
  onClose,
  onSaveTask,
  defaultCategory = 'temporary_task',
}) => {
  const existingBundles = getTaskBundles();
  const classes = getClasses();

  const [category, setCategory] = useState<TaskCategory>(defaultCategory);
  const [type, setType] = useState<TaskType>('carnatic_music');
  const [title, setTitle] = useState<string>('Carnatic Music: Theory & Raga Lakshana Exam');
  const [description, setDescription] = useState<string>(
    'Comprehensive 40-mark examination testing Melakarta classification, Shuddha Swara positions, and Geetham notation.'
  );
  const [maxPoints, setMaxPoints] = useState<number>(40);
  const [dueDate, setDueDate] = useState<string>(
    new Date(Date.now() + 86400000 * 3).toISOString().split('T')[0]
  );
  const [enableTimer, setEnableTimer] = useState<boolean>(true);
  const [timerMinutes, setTimerMinutes] = useState<number>(45);

  // Auto-generate AI student submissions toggle (4 Bright, 3 Average, 8 Failing)
  const [autoSimulateSubmissions, setAutoSimulateSubmissions] = useState<boolean>(true);

  // Class assignment
  const [selectedClassId, setSelectedClassId] = useState<string>(classes[0]?.id || 'cls-10-carnatic');

  // Interconnection Bundle assignment
  const [linkToBundle, setLinkToBundle] = useState<boolean>(true);
  const [bundleOption, setBundleOption] = useState<string>(existingBundles[0]?.id || 'new');
  const [newBundleTitle, setNewBundleTitle] = useState<string>('Carnatic Music Combined Semester Assessment');

  // Carnatic Music Config
  const [carnaticRaga, setCarnaticRaga] = useState<string>('Mayamalavagowla (15th Melakarta)');
  const [carnaticTala, setCarnaticTala] = useState<string>('Adi Tala (8 Aksharas)');
  const [carnaticShruti, setCarnaticShruti] = useState<string>('1 Kattai (C)');
  const [carnaticAspect, setCarnaticAspect] = useState<'theory_internal' | 'viva_vocal' | 'tala_meter' | 'swara_notation'>('theory_internal');
  const [carnaticSpeed, setCarnaticSpeed] = useState<string>('2nd Kala (Madhyama)');
  const [carnaticInstructions, setCarnaticInstructions] = useState<string>(
    'Write the Arohana, Avarohana, Vadi, and Samvadi swaras. Transcribe Geetham in Rupaka Tala with proper akshara spacing.'
  );
  const [carnaticSingingActivity, setCarnaticSingingActivity] = useState<boolean>(false);
  const [carnaticRecordingRequired, setCarnaticRecordingRequired] = useState<boolean>(true);
  const [carnaticRecordingMaxSeconds, setCarnaticRecordingMaxSeconds] = useState<number>(180);
  const [carnaticBeginnerLyrics, setCarnaticBeginnerLyrics] = useState<string>('');
  const [carnaticIntermediateLyrics, setCarnaticIntermediateLyrics] = useState<string>('');
  const [carnaticAdvancedLyrics, setCarnaticAdvancedLyrics] = useState<string>('');
  const [enabledCarnaticTools, setEnabledCarnaticTools] = useState<string[]>([
    'shruti_box',
    'tala_meter',
    'swara_keyboard',
    'raga_explorer',
    'audio_recorder'
  ]);

  // Coding config
  const [codeLang, setCodeLang] = useState<ProgrammingLanguage>('python');
  const [starterCode, setStarterCode] = useState<string>(
    `import numpy as np\nimport pandas as pd\nimport matplotlib.pyplot as plt\n\n# Compute swara frequencies\nswaras = ['Sa', 'Ri1', 'Ga3', 'Ma1', 'Pa', 'Dha1', 'Ni3']\nratios = [1.0, 16/15, 5/4, 4/3, 3/2, 8/5, 15/8]\ndf = pd.DataFrame({'Swara': swaras, 'Frequency': np.array(ratios) * 130.81})\nprint(df)\nplt.plot(df['Swara'], df['Frequency'])\nplt.title('Acoustic Spectrum')\nplt.show()`
  );
  const [codeInstructions, setCodeInstructions] = useState<string>(
    'Implement the solution with Matplotlib plotting, Pandas DataFrame, or HTML/CSS layout. Verify execution outputs.'
  );

  // Typing Config
  const [typingPassage, setTypingPassage] = useState<string>(
    `Carnatic music is a system of music commonly associated with southern India. The basic components are Raga and Tala. Learning Carnatic music disciplines the intellect and aesthetic senses.`
  );
  const [typingTargetWpm, setTypingTargetWpm] = useState<number>(40);

  // MCQ / Quiz config (with AI Quiz Generator)
  const [quizQuestions, setQuizQuestions] = useState<QuizQuestion[]>([
    {
      id: 'q-1',
      question: 'Which of the following is the 15th Melakarta Raga in the Venkatamakhin scheme?',
      options: ['Mayamalavagowla', 'Kalyani', 'Kharaharapriya', 'Shankarabharanam'],
      correctOptionIndex: 0,
      points: 5,
    },
    {
      id: 'q-2',
      question: 'How many Aksharas are there in one complete Avartanam of Adi Tala?',
      options: ['6 Aksharas', '8 Aksharas', '7 Aksharas', '10 Aksharas'],
      correctOptionIndex: 1,
      points: 5,
    },
  ]);

  const [aiQuizTopic, setAiQuizTopic] = useState<string>('carnatic_music');
  const [aiQuizDifficulty, setAiQuizDifficulty] = useState<'Beginner' | 'Intermediate' | 'Advanced'>('Intermediate');
  const [isGeneratingAiQuiz, setIsGeneratingAiQuiz] = useState<boolean>(false);

  // Word Document Template Configuration
  const [docMinWords, setDocMinWords] = useState<number>(250);
  const [docTemplate, setDocTemplate] = useState<string>(
`THE GOLDEN ERA OF CARNATIC MUSIC: KRITI & RAGA ANALYSIS
Author / Student: [Enter Student Name]
Roll Number: [Enter Roll No]
Academic Session: Class 10 Carnatic & Fine Arts

1. Executive Abstract & Historical Lineage
[Provide a scholarly introduction to the chosen raga, composer, and traditional lineage.]

2. Melakarta & Scale Mathematics
• Raga: Mayamalavagowla (15th Melakarta - Agni Chakra)
• Arohana: S R1 G3 M1 P D1 N3 S'
• Avarohana: S' N3 D1 P M1 G3 R1 S
• Swara Sthanas: Shuddha Rishabha, Antara Gandhara, Shuddha Madhyama, Shuddha Dhaivatha, Kakali Nishadha

3. Tala & Rhythmic Formulation
• Tala: Adi Tala (Chatusra Jati Triputa Tala - 8 Aksharas)
• Anga Division: 1 Laghu (4 counts) + 2 Dhrithas (2 + 2 counts)
• Eduppu: Samam (Beat 1)

4. Sahitya Translation & Critical Appraisal
[Document the devotional and literary meaning of the Pallavi, Anupallavi, and Charanam.]

5. Conclusion & Pedagogical Value
[Summarize why this composition remains essential for vocal training and gamaka mastery.]`
  );

  // Keep hooks unconditional. The modal visibility check must happen after all hooks
  // to avoid React hook-order errors when the modal is opened/closed.
  if (!isOpen) return null;

  const handleGenerateAiQuiz = () => {
    setIsGeneratingAiQuiz(true);
    setTimeout(() => {
      const generated = generateQuizWithAI(aiQuizTopic, 5, aiQuizDifficulty);
      setQuizQuestions(generated.questions);
      setTitle(generated.title);
      setDescription(generated.description);
      setMaxPoints(generated.totalPoints);
      setIsGeneratingAiQuiz(false);
    }, 300);
  };

  const handleQuickCarnaticPreset = (preset: 'theory_40' | 'viva_10') => {
    setType('carnatic_music');
    if (preset === 'theory_40') {
      setTitle('Carnatic Music: Theory & Raga Lakshana Exam');
      setDescription('Comprehensive 40-mark theory paper on Melakarta classification and swara sthanas.');
      setMaxPoints(40);
      setCarnaticAspect('theory_internal');
      setCategory('examination');
    } else {
      setTitle('Carnatic Music: Singing & Viva Voce Exam');
      setDescription('10-mark practical singing exam testing Raga Alapana, Kalpana Swaram, and Tala sync.');
      setMaxPoints(10);
      setCarnaticAspect('viva_vocal');
      setCategory('examination');
    }
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      alert('Please enter a task or assignment title.');
      return;
    }

    const taskId = 'task-' + Date.now();
    let linkedBundleId: string | undefined = undefined;

    // Handle Interconnected Bundle
    if (linkToBundle) {
      if (bundleOption === 'new' && newBundleTitle.trim()) {
        const newBundle: InterconnectedTaskBundle = {
          id: 'bundle-' + Date.now(),
          title: newBundleTitle.trim(),
          description: `Combined evaluation containing ${title.trim()}`,
          classId: selectedClassId,
          taskIds: [taskId],
          totalMaxMarks: Number(maxPoints),
          createdAt: new Date().toISOString(),
        };
        saveTaskBundle(newBundle);
        linkedBundleId = newBundle.id;
      } else if (bundleOption !== 'new') {
        const existing = existingBundles.find(b => b.id === bundleOption);
        if (existing) {
          if (!existing.taskIds.includes(taskId)) {
            existing.taskIds.push(taskId);
            existing.totalMaxMarks += Number(maxPoints);
            saveTaskBundle(existing);
          }
          linkedBundleId = existing.id;
        }
      }
    }

    const newTask: Task = {
      id: taskId,
      title: title.trim(),
      description: description.trim() || 'Complete the assignment as requested.',
      category,
      type,
      status: 'active',
      maxPoints: Number(maxPoints) || 100,
      createdAt: new Date().toISOString(),
      dueDate: category === 'assignment' ? dueDate : undefined,
      timeLimitMinutes: enableTimer ? Number(timerMinutes) : undefined,
      classId: selectedClassId,
      strictSubmission: true,
      linkedBundleId,
    };

    if (type === 'carnatic_music') {
      newTask.carnaticConfig = {
        raga: carnaticRaga,
        tala: carnaticTala,
        baseShruti: carnaticShruti,
        taskAspect: carnaticAspect,
        recommendedSpeed: carnaticSpeed,
        instructions: carnaticInstructions,
        sampleNotation: 'S R1 G3 M1 | P D1 | N3 S || S N3 D1 P | M1 G3 | R1 S ||',
        enabledTools: enabledCarnaticTools as any,
        singingActivity: carnaticSingingActivity,
        recordingRequired: carnaticSingingActivity && carnaticRecordingRequired,
        recordingMaxSeconds: carnaticRecordingMaxSeconds,
        lyricsByLevel: {
          beginner: carnaticBeginnerLyrics,
          intermediate: carnaticIntermediateLyrics,
          advanced: carnaticAdvancedLyrics,
        },
        strictSubmission: true,
      };
    } else if (type === 'typing_exam') {
      newTask.typingConfig = {
        passage: typingPassage,
        targetWpm: typingTargetWpm,
        timeLimitSeconds: (Number(timerMinutes) || 5) * 60,
      };
    } else if (type === 'coding') {
      newTask.codingConfig = {
        language: codeLang,
        starterCode,
        instructions: codeInstructions,
      };
    } else if (type === 'mcq' || type === 'quiz') {
      newTask.quizConfig = {
        questions: quizQuestions,
      };
      newTask.mcqConfig = {
        questions: quizQuestions as any,
      };
    } else if (type === 'word_doc') {
      newTask.docConfig = {
        prompt: description || 'Write your formal paper or essay using the prescribed template.',
        minWords: docMinWords,
        sampleTemplate: docTemplate,
      };
    } else if (type === 'ppt') {
      newTask.pptConfig = {
        prompt: description || 'Build the requested presentation deck with Microsoft PowerPoint styling.',
      };
    }

    onSaveTask(newTask);

    // Auto-generate AI student submissions for the 15 students matching tiers
    if (autoSimulateSubmissions) {
      setTimeout(() => {
        generateStudentSubmissionsForTask(newTask, false);
      }, 100);
    }

    onClose();
  };

  const TYPE_OPTIONS: { id: TaskType; label: string; icon: React.ReactNode; desc: string }[] = [
    { id: 'carnatic_music', label: 'Carnatic Music', icon: <Music className="w-4 h-4 text-amber-600" />, desc: 'Raga, Tala, Tanpura drone, Swaras & Vocal viva' },
    { id: 'typing_exam', label: 'Typing Examination', icon: <Keyboard className="w-4 h-4 text-indigo-600" />, desc: 'Live typing speed (WPM) & accuracy test' },
    { id: 'word_doc', label: 'Word Document', icon: <FileText className="w-4 h-4 text-blue-600" />, desc: 'Microsoft Word style formatted essays & reports' },
    { id: 'ppt', label: 'Presentation (PPT)', icon: <Presentation className="w-4 h-4 text-orange-600" />, desc: 'Microsoft PowerPoint style slide deck with themes' },
    { id: 'coding', label: 'Coding Challenge', icon: <Code2 className="w-4 h-4 text-emerald-600" />, desc: 'C, C++, Python with compiler terminal' },
    { id: 'mcq', label: 'MCQs', icon: <CheckSquare className="w-4 h-4 text-blue-600" />, desc: 'Multiple choice with timer' },
    { id: 'quiz', label: 'Quiz Assessment', icon: <HelpCircle className="w-4 h-4 text-indigo-600" />, desc: 'Structured evaluation questions' },
    { id: 'excel', label: 'Excel Sheets', icon: <Table className="w-4 h-4 text-green-600" />, desc: 'Spreadsheet grid with formulas' },
    { id: 'upload', label: 'Upload Files', icon: <Upload className="w-4 h-4 text-slate-600" />, desc: 'Upload documents, PDFs (all pages), zips' },
    { id: 'drawing', label: 'Drawing Board', icon: <PenTool className="w-4 h-4 text-purple-600" />, desc: 'Freehand sketch & diagram canvas' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="relative w-full max-w-4xl rounded-2xl bg-white shadow-2xl border border-slate-200 overflow-hidden my-6">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-200 bg-slate-50 px-6 py-4">
          <div>
            <h2 className="text-lg font-bold text-slate-900">Post Task, Assignment or Examination</h2>
            <p className="text-xs text-slate-500">
              Create academic activities, Carnatic music evaluations, or conduct examinations
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Carnatic Assessment Presets */}
        <div className="bg-amber-50/80 border-b border-amber-200 px-6 py-3 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 text-amber-950 font-bold">
            <Sparkles className="w-4 h-4 text-amber-600" />
            <span>1-Click Carnatic Examination Presets:</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => handleQuickCarnaticPreset('theory_40')}
              className="px-3 py-1.5 rounded-lg bg-white border border-amber-300 font-bold text-amber-900 hover:bg-amber-100 shadow-2xs cursor-pointer"
            >
              🎵 Internal Theory Exam (40 Marks)
            </button>
            <button
              type="button"
              onClick={() => handleQuickCarnaticPreset('viva_10')}
              className="px-3 py-1.5 rounded-lg bg-white border border-amber-300 font-bold text-amber-900 hover:bg-amber-100 shadow-2xs cursor-pointer"
            >
              🎤 Practical Viva Exam (10 Marks)
            </button>
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSave} className="p-6 space-y-6 max-h-[75vh] overflow-y-auto">
          {/* Target Section: Temporary Task vs Assignment vs Conduct Examination */}
          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-slate-500 block mb-2">
              1. Destination Section & Activity Group:
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <button
                type="button"
                onClick={() => setCategory('examination')}
                className={`p-3.5 rounded-xl border text-left transition cursor-pointer ${
                  category === 'examination'
                    ? 'border-indigo-600 bg-indigo-50/80 ring-2 ring-indigo-500 shadow-sm'
                    : 'border-slate-200 bg-white hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold text-slate-900">🎓 Conduct Examination</span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-indigo-100 text-indigo-800">Exam Hall</span>
                </div>
                <p className="text-xs text-slate-500 mt-1">
                  Shows in Student <strong>Examination Section</strong>. Strict timer & controlled environment.
                </p>
              </button>

              <button
                type="button"
                onClick={() => setCategory('assignment')}
                className={`p-3.5 rounded-xl border text-left transition cursor-pointer ${
                  category === 'assignment'
                    ? 'border-indigo-600 bg-indigo-50/80 ring-2 ring-indigo-500 shadow-sm'
                    : 'border-slate-200 bg-white hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold text-slate-900">📚 Regular Assignment</span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-blue-100 text-blue-800">Coursework</span>
                </div>
                <p className="text-xs text-slate-500 mt-1">
                  Shows in Student <strong>Assignments Section</strong> with due dates.
                </p>
              </button>

              <button
                type="button"
                onClick={() => setCategory('temporary_task')}
                className={`p-3.5 rounded-xl border text-left transition cursor-pointer ${
                  category === 'temporary_task'
                    ? 'border-indigo-600 bg-indigo-50/80 ring-2 ring-indigo-500 shadow-sm'
                    : 'border-slate-200 bg-white hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold text-slate-900">⚡ Temporary Task</span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-100 text-amber-800">Live Control</span>
                </div>
                <p className="text-xs text-slate-500 mt-1">
                  Shows in Student <strong>Dashboard Section</strong>. Can be started or stopped live anytime.
                </p>
              </button>
            </div>
          </div>

          {/* Activity Type Selector */}
          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-slate-500 block mb-2">
              2. Select Task Type:
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
              {TYPE_OPTIONS.map(opt => (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => setType(opt.id)}
                  className={`flex flex-col items-start p-2.5 rounded-xl border text-left transition cursor-pointer ${
                    type === opt.id
                      ? 'border-indigo-600 bg-indigo-50 text-indigo-950 ring-2 ring-indigo-400 font-bold shadow-xs'
                      : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-center gap-1.5 mb-1">
                    {opt.icon}
                    <span className="text-xs font-bold">{opt.label}</span>
                  </div>
                  <span className="text-[10px] opacity-75 line-clamp-2">{opt.desc}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Title & Description */}
          <div className="space-y-4">
            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-1">Activity / Exam Title:</label>
              <input
                type="text"
                value={title}
                onChange={e => setTitle(e.target.value)}
                className="w-full rounded-lg border border-slate-300 p-2.5 text-sm font-bold text-slate-900 focus:outline-hidden focus:border-indigo-500"
                placeholder="e.g. Carnatic Music Theory Internal Exam"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-1">Instructions / Description:</label>
              <textarea
                value={description}
                onChange={e => setDescription(e.target.value)}
                rows={2}
                className="w-full rounded-lg border border-slate-300 p-2.5 text-xs text-slate-800 focus:outline-hidden focus:border-indigo-500"
                placeholder="Provide clear directions for the students..."
              />
            </div>
          </div>

          {/* Marks & Timing Configuration */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 bg-slate-50 p-4 rounded-xl border border-slate-200 text-xs">
            {/* Marks */}
            <div>
              <label className="font-semibold text-slate-700 block mb-1">Maximum Marks:</label>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  min={1}
                  max={500}
                  value={maxPoints}
                  onChange={e => setMaxPoints(Number(e.target.value))}
                  className="w-24 rounded-lg border border-slate-300 p-2 text-center text-sm font-mono font-bold text-slate-900 bg-white"
                />
                <div className="flex gap-1">
                  {[40, 10, 50, 100].map(m => (
                    <button
                      key={m}
                      type="button"
                      onClick={() => setMaxPoints(m)}
                      className={`px-2 py-1 rounded text-[11px] font-bold cursor-pointer ${
                        maxPoints === m ? 'bg-indigo-600 text-white' : 'bg-white border text-slate-600'
                      }`}
                    >
                      {m}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Class target */}
            <div>
              <label className="font-semibold text-slate-700 block mb-1">Target Class:</label>
              <select
                value={selectedClassId}
                onChange={e => setSelectedClassId(e.target.value)}
                className="w-full rounded-lg border border-slate-300 p-2 font-semibold text-slate-800 bg-white"
              >
                {classes.map(c => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
            </div>

            {/* Timer */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="font-semibold text-slate-700">Exam Timer:</label>
                <input
                  type="checkbox"
                  checked={enableTimer}
                  onChange={e => setEnableTimer(e.target.checked)}
                  className="rounded accent-indigo-600"
                />
              </div>
              <input
                type="number"
                disabled={!enableTimer}
                value={timerMinutes}
                onChange={e => setTimerMinutes(Number(e.target.value))}
                className="w-full rounded-lg border border-slate-300 p-2 text-sm font-mono text-slate-800 bg-white disabled:opacity-40"
                placeholder="Minutes"
              />
            </div>
          </div>

          {/* 3. INTERCONNECTION FEATURE (Link tasks together for aggregate calculations) */}
          <div className="bg-indigo-50/60 p-4 rounded-xl border border-indigo-200 text-xs space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Link2 className="w-4 h-4 text-indigo-600" />
                <span className="font-bold text-indigo-950">Interconnect with Other Tasks:</span>
              </div>
              <label className="flex items-center gap-1.5 cursor-pointer font-semibold text-indigo-900">
                <input
                  type="checkbox"
                  checked={linkToBundle}
                  onChange={e => setLinkToBundle(e.target.checked)}
                  className="rounded accent-indigo-600"
                />
                <span>Enable Task Interconnection</span>
              </label>
            </div>

            {linkToBundle && (
              <div className="space-y-2 pt-2 border-t border-indigo-200/60">
                <p className="text-slate-600">
                  Allow teachers to connect this task (e.g. 40 Marks Internal) with another task (e.g. 10 Marks Viva) to calculate cumulative student totals.
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="font-semibold text-slate-700 block mb-1">Connect To Bundle:</label>
                    <select
                      value={bundleOption}
                      onChange={e => setBundleOption(e.target.value)}
                      className="w-full rounded border border-slate-300 p-2 font-bold bg-white text-slate-800"
                    >
                      <option value="new">+ Create New Assessment Bundle</option>
                      {existingBundles.map(b => (
                        <option key={b.id} value={b.id}>{b.title} (Currently {b.totalMaxMarks} Marks)</option>
                      ))}
                    </select>
                  </div>

                  {bundleOption === 'new' && (
                    <div>
                      <label className="font-semibold text-slate-700 block mb-1">New Bundle Assessment Title:</label>
                      <input
                        type="text"
                        value={newBundleTitle}
                        onChange={e => setNewBundleTitle(e.target.value)}
                        className="w-full rounded border border-slate-300 p-2 font-bold text-slate-800 bg-white"
                        placeholder="e.g. Carnatic Music Mid-Term Evaluation"
                      />
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Carnatic Music Specific Setup */}
          {type === 'carnatic_music' && (
            <div className="bg-amber-50/70 p-5 rounded-xl border border-amber-300 space-y-4 text-xs">
              <h4 className="font-bold text-amber-950 uppercase tracking-wider flex items-center gap-1.5">
                <Music className="w-4 h-4 text-amber-700" />
                <span>Carnatic Classical Music Tool Configuration:</span>
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Prescribed Raga:</label>
                  <input
                    type="text"
                    value={carnaticRaga}
                    onChange={e => setCarnaticRaga(e.target.value)}
                    className="w-full rounded border border-amber-300 p-2 font-bold bg-white text-slate-800"
                    placeholder="e.g. Mayamalavagowla"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Prescribed Tala:</label>
                  <input
                    type="text"
                    value={carnaticTala}
                    onChange={e => setCarnaticTala(e.target.value)}
                    className="w-full rounded border border-amber-300 p-2 font-bold bg-white text-slate-800"
                    placeholder="e.g. Adi Tala"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Base Shruti (Pitch):</label>
                  <input
                    type="text"
                    value={carnaticShruti}
                    onChange={e => setCarnaticShruti(e.target.value)}
                    className="w-full rounded border border-amber-300 p-2 font-bold bg-white text-slate-800"
                    placeholder="e.g. 1 Kattai (C)"
                  />
                </div>
              </div>

              {/* Carnatic Music Tools Enabled */}
              <div>
                <label className="font-semibold text-slate-700 block mb-1.5">
                  Carnatic Music Tools Provided to Students:
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {[
                    { id: 'shruti_box', label: '1. Shruti Box (Tanpura Drone)' },
                    { id: 'tala_meter', label: '2. Tala Metronome & Kriya Visualizer' },
                    { id: 'swara_keyboard', label: '3. Swara Keyboard & Notation Pad' },
                    { id: 'raga_explorer', label: '4. 72 Melakarta & Raga Explorer' },
                    { id: 'audio_recorder', label: '5. Live Vocal/Audio Recorder' },
                    { id: 'alankara_pad', label: '6. Sapta Tala Alankara Pad' },
                  ].map(tool => {
                    const isChecked = enabledCarnaticTools.includes(tool.id);
                    return (
                      <label key={tool.id} className="flex items-center gap-2 p-2 bg-white rounded-lg border border-amber-200 cursor-pointer font-medium text-slate-700">
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={e => {
                            if (e.target.checked) {
                              setEnabledCarnaticTools([...enabledCarnaticTools, tool.id]);
                            } else {
                              setEnabledCarnaticTools(enabledCarnaticTools.filter(t => t !== tool.id));
                            }
                          }}
                          className="rounded accent-amber-600"
                        />
                        <span className="text-[11px]">{tool.label}</span>
                      </label>
                    );
                  })}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Assessment Aspect:</label>
                  <select
                    value={carnaticAspect}
                    onChange={e => setCarnaticAspect(e.target.value as any)}
                    className="w-full rounded border border-amber-300 p-2 font-bold bg-white text-slate-800"
                  >
                    <option value="theory_internal">Theory & Raga Lakshana Paper (Internal 40 Marks)</option>
                    <option value="viva_vocal">Practical Singing & Oral Viva (Viva 10 Marks)</option>
                    <option value="tala_meter">Tala Kriya & Laya Precision</option>
                    <option value="swara_notation">Swara Notation Transcription</option>
                  </select>
                </div>
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Kala Speed:</label>
                  <input
                    type="text"
                    value={carnaticSpeed}
                    onChange={e => setCarnaticSpeed(e.target.value)}
                    className="w-full rounded border border-amber-300 p-2 font-bold bg-white text-slate-800"
                    placeholder="e.g. 1st & 2nd Kala"
                  />
                </div>
              </div>

              <div className="rounded-xl border border-amber-300 bg-white p-4 space-y-3">
                <label className="flex items-center gap-2 font-bold text-amber-950 cursor-pointer">
                  <input type="checkbox" checked={carnaticSingingActivity} onChange={e => setCarnaticSingingActivity(e.target.checked)} className="accent-amber-600" />
                  Enable level-based singing activity & AI voice recorder
                </label>
                {carnaticSingingActivity && (
                  <>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <label className="flex items-center gap-2 text-slate-700 font-semibold">
                        <input type="checkbox" checked={carnaticRecordingRequired} onChange={e => setCarnaticRecordingRequired(e.target.checked)} className="accent-amber-600" />
                        Recording required for submission
                      </label>
                      <label className="text-slate-700 font-semibold">Maximum recording time (seconds)
                        <input type="number" min={15} max={600} value={carnaticRecordingMaxSeconds} onChange={e => setCarnaticRecordingMaxSeconds(Number(e.target.value) || 180)} className="ml-2 w-24 rounded border border-amber-300 p-1.5" />
                      </label>
                    </div>
                    <div className="grid grid-cols-1 gap-3">
                      <label className="text-slate-700 font-semibold">Beginner-level lyrics
                        <textarea value={carnaticBeginnerLyrics} onChange={e => setCarnaticBeginnerLyrics(e.target.value)} rows={3} className="mt-1 w-full rounded-lg border border-amber-200 p-2 font-mono" placeholder="Lyrics prescribed for beginner students..." />
                      </label>
                      <label className="text-slate-700 font-semibold">Intermediate-level lyrics
                        <textarea value={carnaticIntermediateLyrics} onChange={e => setCarnaticIntermediateLyrics(e.target.value)} rows={3} className="mt-1 w-full rounded-lg border border-amber-200 p-2 font-mono" placeholder="Lyrics prescribed for intermediate students..." />
                      </label>
                      <label className="text-slate-700 font-semibold">Advanced-level lyrics
                        <textarea value={carnaticAdvancedLyrics} onChange={e => setCarnaticAdvancedLyrics(e.target.value)} rows={3} className="mt-1 w-full rounded-lg border border-amber-200 p-2 font-mono" placeholder="Lyrics prescribed for advanced students..." />
                      </label>
                    </div>
                    <p className="text-[11px] text-amber-900 bg-amber-50 border border-amber-200 rounded-lg p-2">Strict submission rule: the student/AI submits only the fields and content requested by the teacher. No automatic correction, rewriting, or teacher grading is performed.</p>
                  </>
                )}
              </div>
            </div>
          )}

          {/* Coding Challenge Setup */}
          {type === 'coding' && (
            <div className="bg-slate-900 text-white p-5 rounded-xl border border-slate-800 space-y-4 text-xs font-mono">
              <div className="flex items-center justify-between font-sans">
                <h4 className="font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                  <Code2 className="w-4 h-4 text-emerald-400" />
                  <span>Coding Environment & Compiler Setup:</span>
                </h4>
                <span className="text-xs text-slate-400 font-mono">Multi-Color Engine</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 font-sans">
                <div>
                  <label className="font-semibold text-slate-300 block mb-1">Target Language:</label>
                  <select
                    value={codeLang}
                    onChange={e => {
                      const newL = e.target.value as ProgrammingLanguage;
                      setCodeLang(newL);
                      if (newL === 'html') {
                        setStarterCode(`<!DOCTYPE html>\n<html>\n<head>\n  <style>body { font-family: sans-serif; background: #0f172a; color: white; padding: 20px; }</style>\n</head>\n<body>\n  <h1>Classical Sangeeth Portal</h1>\n</body>\n</html>`);
                      } else if (newL === 'python') {
                        setStarterCode(`import numpy as np\nimport pandas as pd\nimport matplotlib.pyplot as plt\n\n# Swara analysis\ndf = pd.DataFrame({'Swara': ['Sa', 'Pa'], 'Frequency': [130.81, 196.22]})\nprint(df)\nplt.plot(df['Swara'], df['Frequency'])\nplt.title('Acoustic Spectrum')\nplt.show()`);
                      } else {
                        setStarterCode(`#include <stdio.h>\n\nint main() {\n    printf("Hello World\\n");\n    return 0;\n}`);
                      }
                    }}
                    className="w-full rounded border border-slate-700 p-2 font-bold bg-slate-800 text-white"
                  >
                    <option value="python">Python 3.11 (Matplotlib, Pandas, NumPy)</option>
                    <option value="html">HTML5 & CSS3 (Live Web Render Sandbox)</option>
                    <option value="c">C (GCC 12 / C17)</option>
                    <option value="cpp">C++ (G++ 20)</option>
                    <option value="javascript">JavaScript (Node.js)</option>
                    <option value="java">Java (OpenJDK 17)</option>
                  </select>
                </div>

                <div>
                  <label className="font-semibold text-slate-300 block mb-1">Language Feature Highlights:</label>
                  <div className="p-2 rounded bg-slate-800 border border-slate-700 text-[11px] text-slate-300 font-sans">
                    {codeLang === 'python' ? '✓ Matplotlib plots, Pandas DataFrames, NumPy arrays, stdin inputs' :
                     codeLang === 'html' ? '✓ Full HTML5 tags, CSS3 styles, Flexbox/Grid, live interactive preview' :
                     '✓ GCC/G++ compilation, stdout terminal, exit codes, stdin args'}
                  </div>
                </div>
              </div>

              <div>
                <label className="font-semibold text-slate-300 block mb-1 font-sans">Starter Code:</label>
                <textarea
                  value={starterCode}
                  onChange={e => setStarterCode(e.target.value)}
                  rows={4}
                  className="w-full rounded border border-slate-700 bg-slate-950 p-2.5 text-xs text-emerald-400 font-mono"
                />
              </div>
            </div>
          )}

          {/* AI Quiz Generator Setup */}
          {(type === 'quiz' || type === 'mcq') && (
            <div className="bg-indigo-50/80 p-5 rounded-xl border border-indigo-300 space-y-4 text-xs">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-indigo-600" />
                  <div>
                    <h4 className="font-bold text-indigo-950 text-sm">AI Quiz Generator:</h4>
                    <p className="text-[11px] text-slate-600">Instantly generate rich MCQs with answers, explanations, and scoring.</p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <select
                    value={aiQuizTopic}
                    onChange={e => setAiQuizTopic(e.target.value)}
                    className="rounded-lg border border-indigo-300 p-1.5 font-bold bg-white text-slate-800 text-xs"
                  >
                    <option value="carnatic_music">Carnatic Music & Ragas</option>
                    <option value="python_data_science">Python, Pandas & Matplotlib</option>
                    <option value="html_css_web">HTML5 & Modern CSS3 Web</option>
                  </select>

                  <select
                    value={aiQuizDifficulty}
                    onChange={e => setAiQuizDifficulty(e.target.value as any)}
                    className="rounded-lg border border-indigo-300 p-1.5 font-bold bg-white text-slate-800 text-xs"
                  >
                    <option value="Beginner">Beginner</option>
                    <option value="Intermediate">Intermediate</option>
                    <option value="Advanced">Advanced</option>
                  </select>

                  <button
                    type="button"
                    onClick={handleGenerateAiQuiz}
                    disabled={isGeneratingAiQuiz}
                    className="flex items-center gap-1.5 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white font-bold px-3 py-1.5 rounded-lg text-xs shadow-xs cursor-pointer disabled:opacity-50"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>{isGeneratingAiQuiz ? 'Generating...' : '✨ AI Generate Quiz'}</span>
                  </button>
                </div>
              </div>

              {/* Questions Preview */}
              <div className="space-y-2">
                <span className="font-bold text-indigo-950 block">Configured Questions ({quizQuestions.length}):</span>
                {quizQuestions.map((q, idx) => (
                  <div key={q.id} className="p-3 bg-white rounded-xl border border-indigo-200 space-y-1">
                    <div className="flex justify-between font-bold text-slate-900">
                      <span>Q{idx + 1}: {q.question}</span>
                      <span className="text-indigo-600 font-mono">{q.points} pts</span>
                    </div>
                    <div className="grid grid-cols-2 gap-1 text-[11px] text-slate-600">
                      {q.options.map((opt, oIdx) => (
                        <span key={oIdx} className={oIdx === q.correctOptionIndex ? 'font-bold text-emerald-700' : ''}>
                          {String.fromCharCode(65 + oIdx)}) {opt} {oIdx === q.correctOptionIndex ? '✓' : ''}
                        </span>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Typing Exam Setup */}
          {type === 'typing_exam' && (
            <div className="bg-indigo-50/70 p-5 rounded-xl border border-indigo-200 space-y-3 text-xs">
              <h4 className="font-bold text-indigo-950 uppercase tracking-wider flex items-center gap-1.5">
                <Keyboard className="w-4 h-4 text-indigo-700" />
                <span>Typing Examination Configuration:</span>
              </h4>
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Target Examination Passage:</label>
                <textarea
                  value={typingPassage}
                  onChange={e => setTypingPassage(e.target.value)}
                  rows={3}
                  className="w-full rounded border border-indigo-300 p-2.5 bg-white text-slate-900"
                />
              </div>
              <div className="flex items-center gap-3">
                <span className="font-semibold text-slate-700">Minimum Target WPM:</span>
                <input
                  type="number"
                  value={typingTargetWpm}
                  onChange={e => setTypingTargetWpm(Number(e.target.value))}
                  className="w-20 rounded border border-indigo-300 p-1.5 text-center font-bold"
                />
              </div>
            </div>
          )}

          {/* Word Document Template Configuration */}
          {type === 'word_doc' && (
            <div className="bg-blue-50/70 p-5 rounded-xl border border-blue-200 space-y-4 text-xs">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded bg-blue-600 text-white font-bold flex items-center justify-center text-xs shadow-xs">
                    W
                  </div>
                  <div>
                    <h4 className="font-bold text-blue-950 uppercase tracking-wider text-xs">
                      Word Document Structure & Student Starting Template:
                    </h4>
                    <p className="text-[11px] text-blue-700">
                      Provide a pre-formatted template with sections, prompts, or tables for students to start from.
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <span className="font-bold text-blue-900 text-xs">Min Words:</span>
                  <input
                    type="number"
                    min={50}
                    max={5000}
                    value={docMinWords}
                    onChange={e => setDocMinWords(Number(e.target.value))}
                    className="w-16 rounded border border-blue-300 p-1.5 text-center font-bold bg-white text-blue-950"
                  />
                  <div className="flex gap-1">
                    {[150, 250, 500].map(w => (
                      <button
                        key={w}
                        type="button"
                        onClick={() => setDocMinWords(w)}
                        className={`px-2 py-1 rounded text-[10px] font-bold cursor-pointer ${
                          docMinWords === w ? 'bg-blue-600 text-white' : 'bg-white border text-blue-800'
                        }`}
                      >
                        {w}w
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Template Presets Bar */}
              <div className="space-y-1.5">
                <span className="font-bold text-slate-700 block text-[11px]">Load Template Preset:</span>
                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() => setDocTemplate(
`THE GOLDEN ERA OF CARNATIC MUSIC: KRITI & RAGA ANALYSIS
Author / Student: [Enter Student Name]
Roll Number: [Enter Roll No]
Academic Session: Class 10 Carnatic & Fine Arts

1. Executive Abstract & Historical Lineage
[Provide a scholarly introduction to the chosen raga, composer, and traditional lineage.]

2. Melakarta & Scale Mathematics
• Raga: Mayamalavagowla (15th Melakarta - Agni Chakra)
• Arohana: S R1 G3 M1 P D1 N3 S'
• Avarohana: S' N3 D1 P M1 G3 R1 S
• Swara Sthanas: Shuddha Rishabha, Antara Gandhara, Shuddha Madhyama, Shuddha Dhaivatha, Kakali Nishadha

3. Tala & Rhythmic Formulation
• Tala: Adi Tala (Chatusra Jati Triputa Tala - 8 Aksharas)
• Anga Division: 1 Laghu (4 counts) + 2 Dhrithas (2 + 2 counts)
• Eduppu: Samam (Beat 1)

4. Sahitya Translation & Critical Appraisal
[Document the devotional and literary meaning of the Pallavi, Anupallavi, and Charanam.]

5. Conclusion & Pedagogical Value
[Summarize why this composition remains essential for vocal training and gamaka mastery.]`
                    )}
                    className="px-2.5 py-1 rounded-lg bg-white border border-blue-300 text-blue-900 hover:bg-blue-100/60 font-bold text-[11px] cursor-pointer shadow-2xs"
                  >
                    🎵 Carnatic Music & Kriti Analysis Template
                  </button>

                  <button
                    type="button"
                    onClick={() => setDocTemplate(
`LABORATORY INVESTIGATION REPORT: ACOUSTIC HARMONICS & FREQUENCY ANALYSIS
Investigator Name: [Student Name]
Lab Section: Acoustics & Audio Engineering
Date: [Submission Date]

1. Objective & Hypothesis
[State the experimental hypothesis regarding microtonal pitch frequencies in cents and Hertz.]

2. Theoretical Foundation & Formulae
• Fundamental Frequency equation: f = (1 / 2L) * sqrt(T / mu)
• Harmonic series ratio: f_n = n * f_1

3. Experimental Apparatus & Setup
• Audio transducer / condenser microphone
• FFT spectrum analyzer and digital oscilloscope
• Python SciPy acoustic signal processing suite

4. Observations & Spectral Data Table
[Present swara frequency measurements vs theoretical 22-shruti values.]

5. Error Analysis & Conclusion
[Discuss frequency deviations, ambient temperature factors, and final conclusion.]`
                    )}
                    className="px-2.5 py-1 rounded-lg bg-white border border-slate-300 text-slate-800 hover:bg-slate-100 font-bold text-[11px] cursor-pointer shadow-2xs"
                  >
                    🔬 Scientific / Acoustics Lab Report
                  </button>

                  <button
                    type="button"
                    onClick={() => setDocTemplate(
`CRITICAL ESSAY: COMPARATIVE LITERATURE & PHILOSOPHY
Student: [Student Name]
Course: Fine Arts & Humanities
Instructor: [Faculty Name]

1. Thesis Statement
[Define the core argumentative thesis in one or two clear assertions.]

2. Historical & Cultural Context
[Situate the subject within historical timeline and artistic movements.]

3. Primary Argument & Textual Evidence
[Develop first major argument with supporting citations and textual analysis.]

4. Counter-Perspective & Rebuttal
[Address opposing perspectives or alternative academic interpretations.]

5. Concluding Synthesis & Bibliography
[Synthesize findings and list works cited in MLA/APA format.]`
                    )}
                    className="px-2.5 py-1 rounded-lg bg-white border border-slate-300 text-slate-800 hover:bg-slate-100 font-bold text-[11px] cursor-pointer shadow-2xs"
                  >
                    📚 Comparative Essay & Thesis
                  </button>

                  <button
                    type="button"
                    onClick={() => setDocTemplate('')}
                    className="px-2.5 py-1 rounded-lg bg-white border border-slate-300 text-slate-600 hover:bg-slate-100 font-bold text-[11px] cursor-pointer"
                  >
                    Clear Blank
                  </button>
                </div>
              </div>

              {/* Template Text Area */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="font-semibold text-slate-700">
                    Template Content Provided to Students:
                  </label>
                  <span className="text-[11px] text-blue-800 font-mono">
                    Template Word Count: {docTemplate.trim() ? docTemplate.trim().split(/\s+/).length : 0} words
                  </span>
                </div>
                <textarea
                  value={docTemplate}
                  onChange={e => setDocTemplate(e.target.value)}
                  rows={8}
                  className="w-full rounded-xl border border-blue-300 bg-white p-3 font-mono text-xs text-slate-800 leading-relaxed focus:outline-hidden focus:border-blue-500 shadow-2xs"
                  placeholder="Type or paste the structured starting template for students here..."
                />
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <label className="inline-flex items-center gap-2 px-3 py-2 rounded-lg bg-blue-600 text-white font-bold cursor-pointer hover:bg-blue-700">
                  Import .docx Template
                  <input type="file" accept=".docx,application/vnd.openxmlformats-officedocument.wordprocessingml.document" className="hidden" onChange={async e => {
                    const file = e.target.files?.[0];
                    if (!file) return;
                    try {
                      const imported = await parseDocxText(file);
                      setDocTemplate(imported);
                    } catch (err) {
                      console.error('Word template import failed:', err);
                      alert(err instanceof Error ? err.message : 'Unable to read this Word document.');
                    } finally {
                      e.target.value = '';
                    }
                  }} />
                </label>
                <span className="text-[11px] text-blue-700">Loads the real Word text into the teacher template; no sample content is substituted.</span>
              </div>

              <div className="p-2.5 rounded-lg bg-blue-100/60 border border-blue-200 text-[11px] text-blue-900 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0" />
                <span>
                  When students click <strong>Do Task Now</strong> or open this Word document, their editor will be initialized with this template ready for editing.
                </span>
              </div>
            </div>
          )}

          {/* AI Automatic Class Submissions Toggle (15 Indian Students) */}
          <div className="bg-gradient-to-r from-purple-50 to-indigo-50 p-4 rounded-xl border border-purple-200 flex items-center justify-between text-xs">
            <div>
              <span className="font-bold text-purple-950 flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-purple-600" />
                Auto-Generate Realistic Submissions for 15 Enrolled Indian Students
              </span>
              <p className="text-[11px] text-purple-800 mt-0.5">
                Automatically populates diverse submissions matching academic profiles: <strong>4 Bright</strong> (high quality answers/code/swaras), <strong>3 Average</strong> (moderate answers), and <strong>8 Failing candidates</strong> (incomplete/flawed work).
              </p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer ml-3 shrink-0">
              <input
                type="checkbox"
                checked={autoSimulateSubmissions}
                onChange={e => setAutoSimulateSubmissions(e.target.checked)}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-slate-300 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600"></div>
            </label>
          </div>

          {/* Submit Buttons */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white font-bold text-xs px-6 py-2.5 shadow-md transition active:scale-95 cursor-pointer"
            >
              Publish Task to Class
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
