import React, { useState } from 'react';
import { StudentProfile, ClassGroup, AttendanceRecord, AttendanceSession } from '../../types';
import { 
  getStudentsRoster, 
  getClasses, 
  getCurrentClass, 
  recordClassAttendance, 
  getAttendanceSessions,
  updateStudentAttendance 
} from '../../data/storage';
import { 
  X, 
  Calendar, 
  Users, 
  ShieldCheck, 
  AlertTriangle, 
  CheckCircle2, 
  Clock, 
  Save, 
  Search, 
  History, 
  UserCheck, 
  FileSpreadsheet, 
  Award, 
  AlertCircle 
} from 'lucide-react';

interface AttendanceManagerModalProps {
  onClose: () => void;
  onAttendanceUpdated?: () => void;
}

export const AttendanceManagerModal: React.FC<AttendanceManagerModalProps> = ({
  onClose,
  onAttendanceUpdated,
}) => {
  const classes = getClasses();
  const currentClass = getCurrentClass();
  const [selectedClassId, setSelectedClassId] = useState<string>(currentClass.id);
  const [selectedDate, setSelectedDate] = useState<string>(
    new Date().toISOString().split('T')[0]
  );
  const [sessionTitle, setSessionTitle] = useState<string>('Daily Sangeeth & Theory Academic Session');
  const [activeTab, setActiveTab] = useState<'mark' | 'history'>('mark');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [saveSuccessMsg, setSaveSuccessMsg] = useState<string | null>(null);

  // Load students for active class
  const allStudents = getStudentsRoster();
  const classStudents = allStudents.filter(
    s => !s.classId || s.classId === selectedClassId
  );

  // Local state for session attendance
  const [attendanceMap, setAttendanceMap] = useState<
    Record<string, {
      status: 'present' | 'absent' | 'late' | 'excused';
      percentage: number;
      remarks: string;
    }>
  >(() => {
    const init: Record<string, { status: 'present' | 'absent' | 'late' | 'excused'; percentage: number; remarks: string }> = {};
    classStudents.forEach(std => {
      init[std.id] = {
        status: 'present',
        percentage: std.attendancePercentage ?? 85,
        remarks: 'Present in class'
      };
    });
    return init;
  });

  const sessionsHistory = getAttendanceSessions(selectedClassId);

  // Quick batch actions
  const handleMarkAll = (status: 'present' | 'absent' | 'late' | 'excused') => {
    setAttendanceMap(prev => {
      const next = { ...prev };
      classStudents.forEach(std => {
        const curPerc = next[std.id]?.percentage ?? (std.attendancePercentage || 85);
        let updatedPerc = curPerc;
        if (status === 'present') updatedPerc = Math.min(100, curPerc + 1);
        if (status === 'absent') updatedPerc = Math.max(0, curPerc - 2);

        next[std.id] = {
          status,
          percentage: updatedPerc,
          remarks: status === 'present' ? 'Present in class' : 'Marked absent by teacher'
        };
      });
      return next;
    });
  };

  const handleStatusChange = (
    studentId: string, 
    status: 'present' | 'absent' | 'late' | 'excused'
  ) => {
    setAttendanceMap(prev => {
      const cur = prev[studentId] || { status: 'present', percentage: 85, remarks: '' };
      let newPerc = cur.percentage;
      if (status === 'present' && cur.status !== 'present') newPerc = Math.min(100, cur.percentage + 1);
      if (status === 'absent' && cur.status !== 'absent') newPerc = Math.max(0, cur.percentage - 2);

      return {
        ...prev,
        [studentId]: {
          ...cur,
          status,
          percentage: newPerc,
        }
      };
    });
  };

  const handlePercentageChange = (studentId: string, delta: number) => {
    setAttendanceMap(prev => {
      const cur = prev[studentId] || { status: 'present', percentage: 85, remarks: '' };
      const newPerc = Math.min(100, Math.max(0, cur.percentage + delta));
      return {
        ...prev,
        [studentId]: {
          ...cur,
          percentage: newPerc
        }
      };
    });
  };

  const handleDirectPercentageInput = (studentId: string, val: number) => {
    setAttendanceMap(prev => {
      const cur = prev[studentId] || { status: 'present', percentage: 85, remarks: '' };
      return {
        ...prev,
        [studentId]: {
          ...cur,
          percentage: Math.min(100, Math.max(0, isNaN(val) ? 0 : val))
        }
      };
    });
  };

  const handleSaveAttendance = () => {
    const selectedClassObj = classes.find(c => c.id === selectedClassId) || currentClass;

    const records: AttendanceRecord[] = classStudents.map(std => {
      const att = attendanceMap[std.id] || { status: 'present', percentage: std.attendancePercentage || 85, remarks: '' };
      return {
        studentId: std.id,
        studentName: std.name,
        rollNo: std.rollNo,
        status: att.status,
        cumulativePercentage: att.percentage,
        remarks: att.remarks,
      };
    });

    recordClassAttendance(
      selectedDate,
      selectedClassId,
      selectedClassObj.name,
      sessionTitle,
      records
    );

    setSaveSuccessMsg(`Attendance successfully recorded for ${records.length} students on ${selectedDate}. Examination eligibility rosters updated.`);
    setTimeout(() => setSaveSuccessMsg(null), 4000);

    if (onAttendanceUpdated) {
      onAttendanceUpdated();
    }
  };

  // Compute live statistics
  const totalCount = classStudents.length;
  const eligibleCount = classStudents.filter(s => (attendanceMap[s.id]?.percentage ?? s.attendancePercentage ?? 85) >= 75).length;
  const barredCount = totalCount - eligibleCount;
  const avgAttendance = totalCount > 0 
    ? (classStudents.reduce((acc, s) => acc + (attendanceMap[s.id]?.percentage ?? s.attendancePercentage ?? 85), 0) / totalCount).toFixed(1)
    : '0';

  const filteredStudents = classStudents.filter(s => 
    s.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    s.rollNo.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/70 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="relative w-full max-w-5xl rounded-2xl bg-white shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="bg-gradient-to-r from-indigo-900 via-slate-900 to-indigo-950 p-6 text-white flex items-center justify-between border-b border-indigo-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-600/50 border border-indigo-400 flex items-center justify-center font-bold">
              <UserCheck className="w-6 h-6 text-indigo-200" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs uppercase tracking-widest font-bold text-indigo-300">
                  Faculty Attendance & Eligibility Register
                </span>
                <span className="text-[10px] bg-indigo-500/30 text-indigo-200 px-2 py-0.5 rounded-full font-mono border border-indigo-400/30">
                  75% Rule Enforced
                </span>
              </div>
              <h2 className="text-xl font-black text-white tracking-tight mt-0.5">
                Mark Student Attendance & Exam Access
              </h2>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-1.5 text-slate-400 hover:bg-white/10 hover:text-white transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 75% Regulation Notice Banner */}
        <div className="bg-amber-50 border-b border-amber-200 px-6 py-2.5 flex flex-wrap items-center justify-between text-xs text-amber-900">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-amber-700 shrink-0" />
            <span>
              <strong>Mandatory Academic Rule:</strong> Students having attendance <strong>below 75% are strictly barred</strong> from sitting for formal semester examinations and practical tests.
            </span>
          </div>
          <span className="font-semibold text-amber-800 bg-amber-100/80 px-2 py-0.5 rounded">
            Threshold: 75.0%
          </span>
        </div>

        {/* Session Metadata Controls Bar */}
        <div className="p-5 bg-slate-50 border-b border-slate-200 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
            <div>
              <label className="font-bold text-slate-700 block mb-1">Classroom / Section:</label>
              <select
                value={selectedClassId}
                onChange={e => setSelectedClassId(e.target.value)}
                className="w-full rounded-xl border border-slate-300 p-2.5 bg-white font-semibold text-slate-800"
              >
                {classes.map(c => (
                  <option key={c.id} value={c.id}>{c.name} ({c.section})</option>
                ))}
              </select>
            </div>

            <div>
              <label className="font-bold text-slate-700 block mb-1">Attendance Date:</label>
              <div className="flex items-center gap-2">
                <input
                  type="date"
                  value={selectedDate}
                  onChange={e => setSelectedDate(e.target.value)}
                  className="w-full rounded-xl border border-slate-300 p-2 bg-white font-semibold text-slate-800"
                />
              </div>
            </div>

            <div>
              <label className="font-bold text-slate-700 block mb-1">Academic Session Name:</label>
              <input
                type="text"
                value={sessionTitle}
                onChange={e => setSessionTitle(e.target.value)}
                placeholder="e.g. Classical Vocal & Theory Lecture"
                className="w-full rounded-xl border border-slate-300 p-2 bg-white font-semibold text-slate-800"
              />
            </div>
          </div>

          {/* Quick Stats Summary */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-white p-3 rounded-xl border border-slate-200 flex items-center justify-between">
              <div>
                <span className="text-[11px] font-bold text-slate-500 block uppercase">Enrolled Students</span>
                <span className="text-xl font-black text-slate-900">{totalCount}</span>
              </div>
              <Users className="w-6 h-6 text-indigo-600" />
            </div>

            <div className="bg-emerald-50/80 p-3 rounded-xl border border-emerald-200 flex items-center justify-between">
              <div>
                <span className="text-[11px] font-bold text-emerald-800 block uppercase">Eligible for Exam (≥75%)</span>
                <span className="text-xl font-black text-emerald-900">{eligibleCount}</span>
              </div>
              <ShieldCheck className="w-6 h-6 text-emerald-600" />
            </div>

            <div className="bg-rose-50/80 p-3 rounded-xl border border-rose-200 flex items-center justify-between">
              <div>
                <span className="text-[11px] font-bold text-rose-800 block uppercase">Barred from Exam (&lt;75%)</span>
                <span className="text-xl font-black text-rose-900">{barredCount}</span>
              </div>
              <AlertTriangle className="w-6 h-6 text-rose-600 animate-pulse" />
            </div>

            <div className="bg-purple-50/80 p-3 rounded-xl border border-purple-200 flex items-center justify-between">
              <div>
                <span className="text-[11px] font-bold text-purple-800 block uppercase">Class Attendance Avg</span>
                <span className="text-xl font-black text-purple-900">{avgAttendance}%</span>
              </div>
              <Award className="w-6 h-6 text-purple-600" />
            </div>
          </div>

          {/* Tabs and Quick Actions */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setActiveTab('mark')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1.5 ${
                  activeTab === 'mark' ? 'bg-indigo-600 text-white shadow-xs' : 'bg-white border text-slate-700 hover:bg-slate-100'
                }`}
              >
                <UserCheck className="w-3.5 h-3.5" />
                <span>Mark Attendance Register</span>
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('history')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1.5 ${
                  activeTab === 'history' ? 'bg-indigo-600 text-white shadow-xs' : 'bg-white border text-slate-700 hover:bg-slate-100'
                }`}
              >
                <History className="w-3.5 h-3.5" />
                <span>Recorded Sessions History ({sessionsHistory.length})</span>
              </button>
            </div>

            {activeTab === 'mark' && (
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-xs font-bold text-slate-500">Quick Mark All:</span>
                <button
                  type="button"
                  onClick={() => handleMarkAll('present')}
                  className="px-2.5 py-1 rounded-lg bg-emerald-100 hover:bg-emerald-200 text-emerald-800 font-bold text-xs cursor-pointer border border-emerald-300"
                >
                  ✓ All Present (+1%)
                </button>
                <button
                  type="button"
                  onClick={() => handleMarkAll('absent')}
                  className="px-2.5 py-1 rounded-lg bg-rose-100 hover:bg-rose-200 text-rose-800 font-bold text-xs cursor-pointer border border-rose-300"
                >
                  ✗ All Absent (-2%)
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Tab 1: Mark Attendance Table */}
        {activeTab === 'mark' && (
          <div className="p-5 overflow-y-auto flex-1 space-y-4">
            {/* Search filter */}
            <div className="flex items-center justify-between gap-3">
              <div className="relative w-full max-w-sm">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder="Search students by name or roll number..."
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-3 py-1.5 rounded-xl border border-slate-300 text-xs bg-white focus:outline-hidden focus:border-indigo-500"
                />
              </div>

              <div className="text-xs text-slate-500">
                Showing <strong>{filteredStudents.length}</strong> of <strong>{classStudents.length}</strong> students
              </div>
            </div>

            {/* Students Table */}
            <div className="border border-slate-200 rounded-xl overflow-hidden shadow-2xs">
              <table className="w-full text-left text-xs border-collapse">
                <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                  <tr>
                    <th className="py-2.5 px-3">Roll & Student</th>
                    <th className="py-2.5 px-3">Academic Tier</th>
                    <th className="py-2.5 px-3 text-center">Session Mark</th>
                    <th className="py-2.5 px-3 text-center">Cumulative %</th>
                    <th className="py-2.5 px-3 text-center">Exam Eligibility</th>
                    <th className="py-2.5 px-3">Remarks / Condonation</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 bg-white">
                  {filteredStudents.map(student => {
                    const currentEntry = attendanceMap[student.id] || { 
                      status: 'present', 
                      percentage: student.attendancePercentage ?? 85, 
                      remarks: '' 
                    };
                    const isEligible = currentEntry.percentage >= 75;

                    return (
                      <tr key={student.id} className={`hover:bg-slate-50/80 transition ${!isEligible ? 'bg-rose-50/30' : ''}`}>
                        {/* Student Info */}
                        <td className="py-3 px-3">
                          <div className="flex items-center gap-2.5">
                            <div
                              className="w-8 h-8 rounded-full flex items-center justify-center text-white font-bold text-xs shrink-0 shadow-xs"
                              style={{ backgroundColor: student.avatarColor || '#3b82f6' }}
                            >
                              {student.name.slice(0, 2).toUpperCase()}
                            </div>
                            <div>
                              <div className="font-bold text-slate-900">{student.name}</div>
                              <span className="font-mono text-[11px] text-slate-500">{student.rollNo}</span>
                            </div>
                          </div>
                        </td>

                        {/* Tier */}
                        <td className="py-3 px-3">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                            student.tier === 'bright' ? 'bg-emerald-100 text-emerald-800' :
                            student.tier === 'average' ? 'bg-blue-100 text-blue-800' :
                            'bg-amber-100 text-amber-800'
                          }`}>
                            {student.tier}
                          </span>
                        </td>

                        {/* Status Toggle Buttons */}
                        <td className="py-3 px-3 text-center">
                          <div className="inline-flex rounded-lg border border-slate-200 p-0.5 bg-slate-50 gap-0.5">
                            <button
                              type="button"
                              onClick={() => handleStatusChange(student.id, 'present')}
                              className={`px-2 py-1 rounded text-[11px] font-bold transition cursor-pointer ${
                                currentEntry.status === 'present' 
                                  ? 'bg-emerald-600 text-white shadow-2xs' 
                                  : 'text-slate-600 hover:bg-slate-200'
                              }`}
                              title="Mark Present"
                            >
                              ✓ Present
                            </button>
                            <button
                              type="button"
                              onClick={() => handleStatusChange(student.id, 'absent')}
                              className={`px-2 py-1 rounded text-[11px] font-bold transition cursor-pointer ${
                                currentEntry.status === 'absent' 
                                  ? 'bg-rose-600 text-white shadow-2xs' 
                                  : 'text-slate-600 hover:bg-slate-200'
                              }`}
                              title="Mark Absent"
                            >
                              ✗ Absent
                            </button>
                            <button
                              type="button"
                              onClick={() => handleStatusChange(student.id, 'late')}
                              className={`px-2 py-1 rounded text-[11px] font-bold transition cursor-pointer ${
                                currentEntry.status === 'late' 
                                  ? 'bg-amber-600 text-white shadow-2xs' 
                                  : 'text-slate-600 hover:bg-slate-200'
                              }`}
                              title="Mark Late"
                            >
                              ⏱ Late
                            </button>
                            <button
                              type="button"
                              onClick={() => handleStatusChange(student.id, 'excused')}
                              className={`px-2 py-1 rounded text-[11px] font-bold transition cursor-pointer ${
                                currentEntry.status === 'excused' 
                                  ? 'bg-blue-600 text-white shadow-2xs' 
                                  : 'text-slate-600 hover:bg-slate-200'
                              }`}
                              title="Excused / Medical"
                            >
                              📄 Excused
                            </button>
                          </div>
                        </td>

                        {/* Cumulative Attendance % with Adjusters */}
                        <td className="py-3 px-3 text-center">
                          <div className="flex items-center justify-center gap-1">
                            <button
                              type="button"
                              onClick={() => handlePercentageChange(student.id, -1)}
                              className="w-6 h-6 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold flex items-center justify-center cursor-pointer"
                              title="Decrement 1%"
                            >
                              -
                            </button>
                            <input
                              type="number"
                              min={0}
                              max={100}
                              value={currentEntry.percentage}
                              onChange={e => handleDirectPercentageInput(student.id, parseInt(e.target.value, 10))}
                              className={`w-14 rounded border py-1 text-center font-mono font-bold text-xs ${
                                isEligible 
                                  ? 'border-emerald-300 bg-emerald-50 text-emerald-900' 
                                  : 'border-rose-400 bg-rose-50 text-rose-900'
                              }`}
                            />
                            <span className="font-bold text-slate-600">%</span>
                            <button
                              type="button"
                              onClick={() => handlePercentageChange(student.id, 1)}
                              className="w-6 h-6 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold flex items-center justify-center cursor-pointer"
                              title="Increment 1%"
                            >
                              +
                            </button>
                          </div>
                        </td>

                        {/* Exam Eligibility Badge */}
                        <td className="py-3 px-3 text-center">
                          {isEligible ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
                              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                              <span>Eligible (≥75%)</span>
                            </span>
                          ) : (
                            <div className="inline-flex flex-col items-center">
                              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-rose-100 text-rose-800 border border-rose-300 animate-pulse">
                                <AlertTriangle className="w-3.5 h-3.5 text-rose-600" />
                                <span>Barred from Exam</span>
                              </span>
                              <span className="text-[10px] text-rose-700 font-mono mt-0.5">
                                Deficit: {75 - currentEntry.percentage}%
                              </span>
                            </div>
                          )}
                        </td>

                        {/* Remarks / Quick Condonation */}
                        <td className="py-3 px-3">
                          <div className="flex items-center gap-2">
                            <input
                              type="text"
                              placeholder="e.g. Regular or Medical leave"
                              value={currentEntry.remarks}
                              onChange={e => {
                                const val = e.target.value;
                                setAttendanceMap(prev => ({
                                  ...prev,
                                  [student.id]: {
                                    ...prev[student.id],
                                    remarks: val
                                  }
                                }));
                              }}
                              className="w-full text-xs rounded border border-slate-200 p-1 bg-white"
                            />
                            {!isEligible && (
                              <button
                                type="button"
                                onClick={() => {
                                  // Grant condonation to reach 75%
                                  setAttendanceMap(prev => ({
                                    ...prev,
                                    [student.id]: {
                                      ...prev[student.id],
                                      percentage: 75,
                                      remarks: 'Faculty condonation granted (set to 75% for exam eligibility)'
                                    }
                                  }));
                                }}
                                className="whitespace-nowrap px-2 py-1 rounded bg-amber-100 hover:bg-amber-200 text-amber-900 font-bold text-[10px] border border-amber-300 cursor-pointer"
                                title="Grant Faculty Condonation to enable exam taking"
                              >
                                Condone to 75%
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Tab 2: Sessions History */}
        {activeTab === 'history' && (
          <div className="p-5 overflow-y-auto flex-1 space-y-4">
            <h3 className="text-sm font-bold text-slate-800">
              Recorded Attendance Register Sessions for {currentClass.name}
            </h3>

            {sessionsHistory.length > 0 ? (
              <div className="space-y-3">
                {sessionsHistory.map(session => {
                  const presentCount = session.records.filter(r => r.status === 'present').length;
                  const absentCount = session.records.filter(r => r.status === 'absent').length;
                  const barredInSession = session.records.filter(r => r.cumulativePercentage < 75).length;

                  return (
                    <div key={session.id} className="p-4 rounded-xl border border-slate-200 bg-white shadow-2xs space-y-2">
                      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 pb-2">
                        <div className="flex items-center gap-2">
                          <Calendar className="w-4 h-4 text-indigo-600" />
                          <span className="font-bold text-slate-900">{session.date}</span>
                          <span className="text-slate-400">·</span>
                          <span className="text-slate-700 font-medium">{session.sessionTitle}</span>
                        </div>
                        <span className="text-[11px] text-slate-400 font-mono">
                          Recorded: {new Date(session.createdAt).toLocaleTimeString()}
                        </span>
                      </div>

                      <div className="flex flex-wrap items-center gap-4 text-xs">
                        <span className="font-semibold text-slate-600">
                          Total Students: <strong>{session.records.length}</strong>
                        </span>
                        <span className="text-emerald-700 font-semibold">
                          Present: <strong>{presentCount}</strong>
                        </span>
                        <span className="text-rose-700 font-semibold">
                          Absent: <strong>{absentCount}</strong>
                        </span>
                        <span className={`font-semibold px-2 py-0.5 rounded ${barredInSession > 0 ? 'bg-rose-100 text-rose-800' : 'bg-emerald-100 text-emerald-800'}`}>
                          {barredInSession > 0 ? `⚠️ ${barredInSession} Students Barred from Exams` : '✓ All Students Eligible'}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="p-10 text-center border border-dashed border-slate-300 rounded-xl bg-slate-50 space-y-2">
                <Clock className="w-8 h-8 text-slate-400 mx-auto" />
                <h4 className="text-sm font-bold text-slate-700">No Past Sessions Recorded Yet</h4>
                <p className="text-xs text-slate-500 max-w-sm mx-auto">
                  Use the 'Mark Attendance Register' tab above to record today's session attendance.
                </p>
              </div>
            )}
          </div>
        )}

        {/* Footer */}
        <div className="p-4 bg-slate-100 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3">
          {saveSuccessMsg ? (
            <div className="flex items-center gap-2 text-xs font-bold text-emerald-700 bg-emerald-100 px-3 py-1.5 rounded-lg border border-emerald-300 animate-fade-in">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>{saveSuccessMsg}</span>
            </div>
          ) : (
            <div className="text-xs text-slate-600 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-indigo-600" />
              <span>Updating attendance will immediately synchronize student examination access in real-time.</span>
            </div>
          )}

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl border border-slate-300 bg-white font-bold text-xs text-slate-700 hover:bg-slate-50 cursor-pointer"
            >
              Close
            </button>
            <button
              type="button"
              onClick={handleSaveAttendance}
              className="flex items-center gap-1.5 px-6 py-2 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white font-bold text-xs shadow-md transition active:scale-95 cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>Save & Apply Attendance</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
