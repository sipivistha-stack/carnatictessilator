import React, { useState } from 'react';
import { Task, Submission, PenStroke, StampAnnotation, TeacherCorrection } from '../../types';
import { CorrectionCanvas } from '../common/CorrectionCanvas';
import { DocumentPaperViewer } from '../common/DocumentPaperViewer';
import { executeCode, ExecutionResult } from '../../services/codeRunner';
import { 
  X, 
  Send, 
  Award, 
  CheckCircle2, 
  Play, 
  RotateCcw, 
  MessageSquare,
  Sparkles,
  FileCheck,
  FileText
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface EvaluationModalProps {
  submission: Submission;
  task?: Task;
  onClose: () => void;
  onSaveEvaluation: (submissionId: string, correction: TeacherCorrection, status: 'evaluated' | 'returned') => void;
}

export const EvaluationModal: React.FC<EvaluationModalProps> = ({
  submission,
  task,
  onClose,
  onSaveEvaluation,
}) => {
  const maxPoints = task?.maxPoints || submission.correction?.maxPoints || 100;
  const [grade, setGrade] = useState<number>(submission.correction?.grade ?? Math.round(maxPoints * 0.9));
  const [feedback, setFeedback] = useState<string>(
    submission.correction?.feedback ||
      'Well done! Reviewed your submission, structure, and output. Review the pen markings, highlights, and annotations directly on your document pages below.'
  );
  const [penStrokes, setPenStrokes] = useState<PenStroke[]>(
    submission.correction?.penStrokes || []
  );
  const [stamps, setStamps] = useState<StampAnnotation[]>(
    submission.correction?.stamps || []
  );

  // Coding re-test for teacher
  const [teacherRunResult, setTeacherRunResult] = useState<ExecutionResult | null>(null);
  const [isTeacherRunning, setIsTeacherRunning] = useState<boolean>(false);

  const calculateLetterGrade = (score: number, max: number): string => {
    const pct = (score / max) * 100;
    if (pct >= 94) return 'A+';
    if (pct >= 90) return 'A';
    if (pct >= 85) return 'B+';
    if (pct >= 80) return 'B';
    if (pct >= 75) return 'C+';
    if (pct >= 70) return 'C';
    if (pct >= 60) return 'D';
    return 'F';
  };

  const letterGrade = calculateLetterGrade(grade, maxPoints);

  const handleTeacherRunCode = () => {
    if (submission.taskType !== 'coding' || !submission.payload.code) return;
    setIsTeacherRunning(true);
    setTimeout(() => {
      const res = executeCode(
        submission.payload.codeLanguage || 'python',
        submission.payload.code || ''
      );
      setTeacherRunResult(res);
      // Update submission payload dynamically so the viewer reflects live execution
      submission.payload.codeStdout = res.stdout;
      submission.payload.codeStderr = res.stderr;
      if (res.matplotlibPlotUrl) submission.payload.matplotlibPlotUrl = res.matplotlibPlotUrl;
      if (res.pandasTableHtml) submission.payload.pandasTableHtml = res.pandasTableHtml;
      if (res.htmlPreview) submission.payload.htmlPreview = res.htmlPreview;
      setIsTeacherRunning(false);
    }, 250);
  };

  const handleReturnWork = () => {
    const correction: TeacherCorrection = {
      grade: Number(grade),
      maxPoints,
      letterGrade,
      feedback: feedback.trim(),
      evaluatedAt: new Date().toISOString(),
      penStrokes,
      stamps,
      evaluatorName: 'Lead Teacher',
    };

    onSaveEvaluation(submission.id, correction, 'returned');
    confetti({
      particleCount: 60,
      spread: 70,
      origin: { y: 0.7 },
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/75 backdrop-blur-xs overflow-y-auto">
      <div className="relative w-full max-w-7xl rounded-2xl bg-white shadow-2xl border border-slate-200 overflow-hidden my-3 flex flex-col max-h-[95vh]">
        {/* Modal Top Bar */}
        <div className="flex items-center justify-between border-b border-slate-200 bg-slate-50 px-6 py-3 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center font-bold text-sm shadow-xs">
              {submission.studentName.slice(0, 2).toUpperCase()}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-slate-900">{submission.taskTitle}</h3>
                <span className="text-xs px-2.5 py-0.5 rounded bg-indigo-100 text-indigo-800 font-semibold capitalize">
                  {submission.taskType}
                </span>
                {submission.payload.fileName && (
                  <span className="text-xs font-mono text-slate-500 bg-slate-200 px-2 py-0.5 rounded">
                    {submission.payload.fileName}
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-500">
                Submitted by <strong className="text-slate-800">{submission.studentName}</strong> ·{' '}
                {new Date(submission.submittedAt).toLocaleString()}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {submission.taskType === 'coding' && (
              <button
                type="button"
                onClick={handleTeacherRunCode}
                disabled={isTeacherRunning}
                className="flex items-center gap-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white px-3 py-1.5 text-xs font-semibold shadow-xs transition"
              >
                <Play className="w-3.5 h-3.5 fill-current text-emerald-400" />
                <span>{isTeacherRunning ? 'Re-compiling...' : 'Re-verify Code Output'}</span>
              </button>
            )}

            <button
              type="button"
              onClick={onClose}
              className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200 transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body: Left: Document Viewer with Direct In-App Annotation Canvas, Right: Grading Panel */}
        <div className="flex-1 overflow-y-auto grid grid-cols-1 lg:grid-cols-12 divide-y lg:divide-y-0 lg:divide-x divide-slate-200">
          {/* Left Column (8 cols): Direct In-App Document Viewer & Correction Canvas */}
          <div className="lg:col-span-8 p-4 sm:p-5 space-y-4 bg-slate-100/70 overflow-y-auto">
            {/* Instruction Banner */}
            <div className="rounded-xl bg-gradient-to-r from-indigo-50 to-blue-50 border border-indigo-200 p-3 flex flex-wrap items-center justify-between gap-2 text-xs text-indigo-900 shadow-2xs">
              <span className="flex items-center gap-1.5 font-medium">
                <Sparkles className="w-4 h-4 text-indigo-600 shrink-0" />
                <span>
                  <strong>Interactive In-App Correction:</strong> Draw with the colored pens, highlights, and stamps directly onto the student's Word doc, PDF pages, or PPT slides below!
                </span>
              </span>
              <span className="font-bold text-indigo-700 bg-white px-2 py-0.5 rounded border border-indigo-200 text-[11px]">
                {penStrokes.length} Strokes · {stamps.length} Stamps
              </span>
            </div>

            {/* Interactive Drawing Canvas Layer DIRECTLY OVER the Document Content */}
            <CorrectionCanvas
              penStrokes={penStrokes}
              onChangePenStrokes={setPenStrokes}
              stamps={stamps}
              onChangeStamps={setStamps}
            >
              <DocumentPaperViewer
                submission={submission}
                isAnnotating={true}
              />
            </CorrectionCanvas>
          </div>

          {/* Right Column (4 cols): Grading & Evaluation Controls */}
          <div className="lg:col-span-4 p-6 flex flex-col justify-between bg-white space-y-6 overflow-y-auto">
            <div className="space-y-5">
              <div className="flex items-center gap-2 border-b border-slate-200 pb-3">
                <Award className="w-5 h-5 text-indigo-600" />
                <h4 className="text-sm font-bold text-slate-900">Grading & Evaluation Sheet</h4>
              </div>

              {/* Score Input */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-semibold text-slate-700">
                    Awarded Score:
                  </label>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-500">out of {maxPoints} pts</span>
                    <span className="w-7 h-7 rounded-lg bg-indigo-600 text-white flex items-center justify-center text-xs font-bold shadow-xs">
                      {letterGrade}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <input
                    type="range"
                    min={0}
                    max={maxPoints}
                    value={grade}
                    onChange={e => setGrade(Number(e.target.value))}
                    className="flex-1 accent-indigo-600"
                  />
                  <input
                    type="number"
                    min={0}
                    max={maxPoints}
                    value={grade}
                    onChange={e => setGrade(Number(e.target.value))}
                    className="w-16 rounded-lg border border-slate-300 p-2 text-center text-sm font-bold text-slate-900 focus:outline-hidden focus:border-indigo-500"
                  />
                </div>
              </div>

              {/* Quick Grade presets */}
              <div className="flex items-center gap-1.5 flex-wrap">
                {[100, 95, 90, 85, 75, 60].map(s => (
                  <button
                    key={s}
                    type="button"
                    onClick={() => setGrade(s)}
                    className={`px-2.5 py-1 rounded text-xs font-medium border transition cursor-pointer ${
                      grade === s
                        ? 'bg-indigo-600 text-white border-indigo-600'
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    {s} pts
                  </button>
                ))}
              </div>

              {/* Teacher Written Feedback */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
                  <MessageSquare className="w-3.5 h-3.5 text-slate-500" />
                  Written Feedback & Correction Notes:
                </label>
                <textarea
                  rows={6}
                  value={feedback}
                  onChange={e => setFeedback(e.target.value)}
                  placeholder="Provide constructive feedback, praise strong points, and highlight areas for improvement..."
                  className="w-full rounded-xl border border-slate-300 p-3 text-xs leading-relaxed text-slate-800 focus:border-indigo-500 focus:outline-hidden"
                />
              </div>

              {/* Markings summary */}
              <div className="rounded-lg bg-slate-50 border border-slate-200 p-3 text-xs text-slate-600 space-y-1">
                <div className="flex justify-between">
                  <span>Document Annotations:</span>
                  <strong className="text-slate-800">{penStrokes.length} stroke(s)</strong>
                </div>
                <div className="flex justify-between">
                  <span>Stamps Placed:</span>
                  <strong className="text-slate-800">{stamps.length} stamp(s)</strong>
                </div>
                <div className="flex justify-between text-indigo-700 pt-1 border-t border-slate-200">
                  <span>Evaluation Status:</span>
                  <strong>Ready to Return</strong>
                </div>
              </div>
            </div>

            {/* Return Action */}
            <div className="space-y-2 pt-4 border-t border-slate-200">
              <button
                type="button"
                onClick={handleReturnWork}
                className="w-full flex items-center justify-center gap-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white py-3 text-xs font-bold shadow-md transition active:scale-95 cursor-pointer"
              >
                <FileCheck className="w-4 h-4" />
                <span>Return Evaluated Work to Student</span>
              </button>

              <button
                type="button"
                onClick={onClose}
                className="w-full rounded-xl border border-slate-200 bg-white py-2 text-xs font-semibold text-slate-600 hover:bg-slate-50 transition cursor-pointer"
              >
                Save Draft & Exit
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
