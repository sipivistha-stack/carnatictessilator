import React, { useState, useRef, useEffect } from 'react';
import { 
  Music, 
  Play, 
  Square, 
  Volume2, 
  Mic, 
  Radio, 
  Sliders, 
  Clock, 
  BookOpen, 
  X, 
  Check, 
  Layers, 
  Sparkles,
  HelpCircle,
  Activity,
  Plus
} from 'lucide-react';
import { Task } from '../../types';

interface CarnaticToolsManagerModalProps {
  tasks: Task[];
  onClose: () => void;
  onAttachToolToTask?: (taskId: string, toolName: string) => void;
}

// Shruti Pitch Mapping in Hz
const SHRUTI_MAP: Record<string, { note: string; freq: number }> = {
  '1 Kattai (C)': { note: 'C', freq: 130.81 },
  '1.5 Kattai (C#)': { note: 'C#', freq: 138.59 },
  '2 Kattai (D)': { note: 'D', freq: 146.83 },
  '2.5 Kattai (D#)': { note: 'D#', freq: 155.56 },
  '3 Kattai (E)': { note: 'E', freq: 164.81 },
  '4 Kattai (F)': { note: 'F', freq: 174.61 },
  '4.5 Kattai (F#)': { note: 'F#', freq: 185.00 },
  '5 Kattai (G)': { note: 'G', freq: 196.00 },
  '5.5 Kattai (G#)': { note: 'G#', freq: 207.65 },
  '6 Kattai (A)': { note: 'A', freq: 220.00 },
};

// Swara Interval Ratio from Sa
const SWARA_RATIOS: Record<string, number> = {
  'S': 1.0,
  'R1': 16 / 15,
  'R2': 9 / 8,
  'G2': 6 / 5,
  'G3': 5 / 4,
  'M1': 4 / 3,
  'M2': 45 / 32,
  'P': 3 / 2,
  'D1': 8 / 5,
  'D2': 5 / 3,
  'N2': 9 / 5,
  'N3': 15 / 8,
};

const TALAS: Record<string, { name: string; totalAksharas: number; kriyas: string[] }> = {
  'Adi Tala': {
    name: 'Adi Tala (Chatusra Jathi Triputa - 8 Aksharas)',
    totalAksharas: 8,
    kriyas: ['👏 Beat 1', '☝️ Little Finger', '✌️ Ring Finger', '🖐️ Middle Finger', '👏 Dhrutam Beat', '👋 Wave (Usiru)', '👏 Dhrutam Beat', '👋 Wave'],
  },
  'Rupaka Tala': {
    name: 'Rupaka Tala (Dhrutam + Laghu - 6 Aksharas)',
    totalAksharas: 6,
    kriyas: ['👏 Dhrutam Beat', '👋 Wave', '👏 Laghu Beat', '☝️ Little Finger', '✌️ Ring Finger', '🖐️ Middle Finger'],
  },
  'Mishra Chapu': {
    name: 'Mishra Chapu (3 + 2 + 2 - 7 Aksharas)',
    totalAksharas: 7,
    kriyas: ['👏 Ta (Beat)', '👏 Ki (Beat)', '👋 Ta (Wave)', '👏 Dhi (Beat)', '👋 Mi (Wave)', '👏 Ta (Beat)', '👋 Ka (Wave)'],
  },
  'Khanda Chapu': {
    name: 'Khanda Chapu (2 + 3 - 5 Aksharas)',
    totalAksharas: 5,
    kriyas: ['👏 Ta (Beat)', '👋 Ka (Wave)', '👏 Ta (Beat)', '👏 Ki (Beat)', '👋 Ta (Wave)'],
  },
  'Dhruva Tala': {
    name: 'Chatusra Dhruva Tala (I4 + O + I4 + I4 - 14 Aksharas)',
    totalAksharas: 14,
    kriyas: ['👏 Beat', '☝️ Count', '✌️ Count', '🖐️ Count', '👏 Dhrutam', '👋 Wave', '👏 Beat', '☝️ Count', '✌️ Count', '🖐️ Count', '👏 Beat', '☝️ Count', '✌️ Count', '🖐️ Count'],
  }
};

const POPULAR_RAGAS: Record<string, { name: string; mela: number; arohana: string; avarohana: string; chakra: string }> = {
  'Mayamalavagowla': {
    name: 'Mayamalavagowla',
    mela: 15,
    chakra: 'Agni (Chakra 3)',
    arohana: 'S R1 G3 M1 P D1 N3 S',
    avarohana: 'S N3 D1 P M1 G3 R1 S',
  },
  'Kalyani': {
    name: 'Mechakalyani',
    mela: 65,
    chakra: 'Rudra (Chakra 11)',
    arohana: 'S R2 G3 M2 P D2 N3 S',
    avarohana: 'S N3 D2 P M2 G3 R2 S',
  },
  'Shankarabharanam': {
    name: 'Dheerasankarabharanam',
    mela: 29,
    chakra: 'Bana (Chakra 5)',
    arohana: 'S R2 G3 M1 P D2 N3 S',
    avarohana: 'S N3 D2 P M1 G3 R2 S',
  },
  'Kharaharapriya': {
    name: 'Kharaharapriya',
    mela: 22,
    chakra: 'Veda (Chakra 4)',
    arohana: 'S R2 G2 M1 P D2 N2 S',
    avarohana: 'S N2 D2 P M1 G2 R2 S',
  },
  'Todi': {
    name: 'Hanumatodi',
    mela: 8,
    chakra: 'Netra (Chakra 2)',
    arohana: 'S R1 G2 M1 P D1 N2 S',
    avarohana: 'S N2 D1 P M1 G2 R1 S',
  },
  'Mohanam': {
    name: 'Mohanam (Audava Raga)',
    mela: 28,
    chakra: 'Janya of Harikambhoji',
    arohana: 'S R2 G3 P D2 S',
    avarohana: 'S D2 P G3 R2 S',
  },
  'Hamsadhwani': {
    name: 'Hamsadhwani (Audava Raga)',
    mela: 29,
    chakra: 'Janya of Shankarabharanam',
    arohana: 'S R2 G3 P N3 S',
    avarohana: 'S N3 P G3 R2 S',
  }
};

export const CarnaticToolsManagerModal: React.FC<CarnaticToolsManagerModalProps> = ({
  tasks,
  onClose,
}) => {
  const [activeToolTab, setActiveToolTab] = useState<'tanpura' | 'tala' | 'swaras' | 'ragas' | 'alankaras'>('tanpura');

  // Shruti / Tanpura state
  const [selectedShruti, setSelectedShruti] = useState<string>('1 Kattai (C)');
  const [isTanpuraPlaying, setIsTanpuraPlaying] = useState<boolean>(false);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const oscillatorsRef = useRef<OscillatorNode[]>([]);

  // Tala state
  const [selectedTala, setSelectedTala] = useState<string>('Adi Tala');
  const [isTalaPlaying, setIsTalaPlaying] = useState<boolean>(false);
  const [currentBeat, setCurrentBeat] = useState<number>(0);
  const [bpm, setBpm] = useState<number>(72);
  const [kalaSpeed, setKalaSpeed] = useState<'1st' | '2nd' | '3rd'>('1st');

  // Swara & Notation Pad
  const [notationOutput, setNotationOutput] = useState<string>(
    'S , R1 | G3 M1 P , || M1 P D1 | P , M1 G3 ||\nR1 G3 R1 | S , . . ||'
  );
  const [selectedRaga, setSelectedRaga] = useState<string>('Mayamalavagowla');
  const [octave, setOctave] = useState<'mandra' | 'madhya' | 'tara'>('madhya');

  // 1. TANPURA SYNTH
  const toggleTanpura = () => {
    if (isTanpuraPlaying) {
      stopTanpura();
    } else {
      startTanpura();
    }
  };

  const startTanpura = () => {
    try {
      if (!audioCtxRef.current) {
        audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      const ctx = audioCtxRef.current;
      if (ctx.state === 'suspended') ctx.resume();

      const baseFreq = SHRUTI_MAP[selectedShruti]?.freq || 130.81;
      const freqs = [baseFreq * 1.5, baseFreq * 2.0, baseFreq * 2.004, baseFreq];

      const masterGain = ctx.createGain();
      masterGain.gain.setValueAtTime(0.12, ctx.currentTime);
      masterGain.connect(ctx.destination);

      oscillatorsRef.current = freqs.map((freq, i) => {
        const osc = ctx.createOscillator();
        const stringGain = ctx.createGain();
        osc.type = i === 3 ? 'sawtooth' : 'triangle';
        osc.frequency.setValueAtTime(freq, ctx.currentTime);

        const lfo = ctx.createOscillator();
        const lfoGain = ctx.createGain();
        lfo.frequency.setValueAtTime(0.22 + i * 0.08, ctx.currentTime);
        lfoGain.gain.setValueAtTime(0.04, ctx.currentTime);
        lfo.connect(lfoGain.gain);

        osc.connect(stringGain);
        stringGain.connect(masterGain);
        osc.start();
        return osc;
      });

      setIsTanpuraPlaying(true);
    } catch (e) {
      console.warn('AudioContext error:', e);
    }
  };

  const stopTanpura = () => {
    oscillatorsRef.current.forEach(osc => {
      try { osc.stop(); osc.disconnect(); } catch {}
    });
    oscillatorsRef.current = [];
    setIsTanpuraPlaying(false);
  };

  useEffect(() => {
    return () => {
      stopTanpura();
      if (audioCtxRef.current) audioCtxRef.current.close().catch(() => {});
    };
  }, []);

  useEffect(() => {
    if (isTanpuraPlaying) {
      stopTanpura();
      startTanpura();
    }
  }, [selectedShruti]);

  // 2. PLAY SWARA
  const playSwara = (swara: string) => {
    try {
      if (!audioCtxRef.current) {
        audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      const ctx = audioCtxRef.current;
      if (ctx.state === 'suspended') ctx.resume();

      const baseFreq = SHRUTI_MAP[selectedShruti]?.freq || 130.81;
      const ratio = SWARA_RATIOS[swara] || 1.0;
      let mult = octave === 'mandra' ? 0.5 : octave === 'tara' ? 2.0 : 1.0;

      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(baseFreq * ratio * mult, ctx.currentTime);
      gain.gain.setValueAtTime(0.2, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 1.2);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 1.2);

      const symbol = octave === 'mandra' ? `${swara}̣ ` : octave === 'tara' ? `${swara}̇ ` : `${swara} `;
      setNotationOutput(prev => prev + symbol);
    } catch {}
  };

  // 3. TALA METRONOME
  useEffect(() => {
    if (!isTalaPlaying) {
      setCurrentBeat(0);
      return;
    }
    const def = TALAS[selectedTala] || TALAS['Adi Tala'];
    let mult = kalaSpeed === '2nd' ? 2 : kalaSpeed === '3rd' ? 4 : 1;
    const intervalMs = (60 / (bpm * mult)) * 1000;

    const interval = setInterval(() => {
      setCurrentBeat(prev => {
        const next = (prev + 1) % def.totalAksharas;
        try {
          if (audioCtxRef.current) {
            const ctx = audioCtxRef.current;
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.frequency.setValueAtTime(next === 0 ? 880 : 440, ctx.currentTime);
            gain.gain.setValueAtTime(0.12, ctx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.08);
            osc.connect(gain);
            gain.connect(ctx.destination);
            osc.start();
            osc.stop(ctx.currentTime + 0.08);
          }
        } catch {}
        return next;
      });
    }, intervalMs);

    return () => clearInterval(interval);
  }, [isTalaPlaying, bpm, selectedTala, kalaSpeed]);

  const activeTalaDef = TALAS[selectedTala] || TALAS['Adi Tala'];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-950/80 backdrop-blur-xs overflow-y-auto">
      <div className="relative w-full max-w-5xl rounded-3xl bg-white shadow-2xl border border-amber-300 overflow-hidden my-4 flex flex-col max-h-[92vh]">
        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-amber-200 bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 px-6 py-4 text-white">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-white/20 backdrop-blur-xs flex items-center justify-center shadow-inner">
              <Music className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-black uppercase tracking-wider bg-white/25 px-2.5 py-0.5 rounded-full">
                  Classical Fine Arts Portal
                </span>
                <span className="text-xs text-amber-100">· Faculty Master Suite</span>
              </div>
              <h3 className="text-lg font-black tracking-tight text-white mt-0.5">
                Carnatic Classical Music Tools & Sound Lab
              </h3>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-white/80 hover:text-white hover:bg-white/20 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs for Tools */}
        <div className="flex items-center border-b border-slate-200 bg-amber-50/60 px-4 overflow-x-auto text-xs font-bold gap-2 py-2">
          {[
            { id: 'tanpura', label: '1. Shruti Box & Drone', icon: Radio },
            { id: 'tala', label: '2. Tala Metronome & Kriyas', icon: Clock },
            { id: 'swaras', label: '3. Swara Keyboard & Notation', icon: Sliders },
            { id: 'ragas', label: '4. 72 Melakarta & Raga Explorer', icon: BookOpen },
            { id: 'alankaras', label: '5. Sapta Tala Alankaras', icon: Layers },
          ].map(t => {
            const Icon = t.icon;
            const isActive = activeToolTab === t.id;
            return (
              <button
                key={t.id}
                type="button"
                onClick={() => setActiveToolTab(t.id as any)}
                className={`flex items-center gap-1.5 px-4 py-2.5 rounded-xl transition cursor-pointer shrink-0 ${
                  isActive
                    ? 'bg-amber-600 text-white shadow-xs'
                    : 'text-amber-950 hover:bg-amber-100/70'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{t.label}</span>
              </button>
            );
          })}
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-50/50">
          {/* TOOL 1: SHRUTI BOX & DIGITAL TANPURA */}
          {activeToolTab === 'tanpura' && (
            <div className="space-y-4">
              <div className="bg-white p-5 rounded-2xl border border-amber-200 shadow-xs flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h4 className="text-base font-bold text-slate-900">Digital Tanpura Drone & Pitch Synthesizer</h4>
                  <p className="text-xs text-slate-500">
                    4 harmonic strings (Pa - Sa' - Sa' - Sa) with dynamic chorus shimmer and concert A4=440Hz tuning.
                  </p>
                </div>

                <button
                  type="button"
                  onClick={toggleTanpura}
                  className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-xs shadow-md transition cursor-pointer ${
                    isTanpuraPlaying
                      ? 'bg-rose-600 hover:bg-rose-700 text-white animate-pulse'
                      : 'bg-amber-600 hover:bg-amber-700 text-white'
                  }`}
                >
                  {isTanpuraPlaying ? <Square className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                  <span>{isTanpuraPlaying ? 'Stop Drone' : 'Start Tanpura Drone'}</span>
                </button>
              </div>

              {/* Pitch Selector */}
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
                {Object.entries(SHRUTI_MAP).map(([kattai, data]) => (
                  <button
                    key={kattai}
                    type="button"
                    onClick={() => setSelectedShruti(kattai)}
                    className={`p-4 rounded-xl border text-xs font-semibold flex flex-col items-center justify-center gap-1 transition cursor-pointer ${
                      selectedShruti === kattai
                        ? 'bg-gradient-to-br from-amber-500 to-amber-600 text-white border-amber-600 shadow-md ring-2 ring-amber-300'
                        : 'bg-white hover:bg-amber-50 text-slate-700 border-slate-200'
                    }`}
                  >
                    <span className="font-bold text-sm">{kattai}</span>
                    <span className="text-[11px] opacity-80 font-mono">{data.freq.toFixed(1)} Hz</span>
                    <span className="text-[10px] opacity-75">Tonic Note {data.note}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* TOOL 2: TALA METRONOME & KRIYAS */}
          {activeToolTab === 'tala' && (
            <div className="space-y-4">
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-3">
                <div className="flex flex-wrap items-center gap-3">
                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">Select Tala:</label>
                    <select
                      value={selectedTala}
                      onChange={e => setSelectedTala(e.target.value)}
                      className="rounded-xl border border-slate-300 p-2 text-xs font-bold text-slate-800 bg-white"
                    >
                      {Object.keys(TALAS).map(t => (
                        <option key={t} value={t}>{t}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">Speed (Kala):</label>
                    <div className="flex rounded-xl border border-slate-200 bg-slate-100 p-0.5">
                      {(['1st', '2nd', '3rd'] as const).map(k => (
                        <button
                          key={k}
                          type="button"
                          onClick={() => setKalaSpeed(k)}
                          className={`px-3 py-1 rounded-lg text-xs font-bold cursor-pointer ${
                            kalaSpeed === k ? 'bg-white shadow-xs text-indigo-700' : 'text-slate-600'
                          }`}
                        >
                          {k} Kala
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">Tempo ({bpm} BPM):</label>
                    <input
                      type="range"
                      min={40}
                      max={140}
                      value={bpm}
                      onChange={e => setBpm(Number(e.target.value))}
                      className="w-28 accent-indigo-600"
                    />
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => setIsTalaPlaying(!isTalaPlaying)}
                  className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-xs shadow-md transition cursor-pointer text-white ${
                    isTalaPlaying ? 'bg-rose-600' : 'bg-indigo-600 hover:bg-indigo-700'
                  }`}
                >
                  {isTalaPlaying ? <Square className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                  <span>{isTalaPlaying ? 'Stop Tala' : 'Run Live Tala Beats'}</span>
                </button>
              </div>

              {/* Tala Beats Visualization Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
                {activeTalaDef.kriyas.map((kriya, idx) => {
                  const isActive = isTalaPlaying && currentBeat === idx;
                  return (
                    <div
                      key={idx}
                      className={`p-4 rounded-2xl border flex flex-col items-center justify-center text-center transition-all ${
                        isActive
                          ? 'bg-indigo-600 text-white border-indigo-700 shadow-lg scale-105 ring-2 ring-indigo-400'
                          : 'bg-white border-slate-200 text-slate-700'
                      }`}
                    >
                      <span className="text-xs font-black mb-1">Beat {idx + 1}</span>
                      <span className="text-sm font-bold">{kriya.split(' ')[0]}</span>
                      <span className="text-[11px] opacity-80 mt-1">{kriya.slice(2)}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TOOL 3: SWARAS KEYBOARD & NOTATION PAD */}
          {activeToolTab === 'swaras' && (
            <div className="space-y-4">
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h4 className="text-base font-bold text-slate-900">Swaras Keyboard & Notation Transcriber</h4>
                  <p className="text-xs text-slate-500">
                    Click swaras to audition acoustic frequencies and build structured Akshara notations.
                  </p>
                </div>

                <div className="flex rounded-xl border border-slate-200 bg-slate-100 p-0.5 text-xs">
                  {(['mandra', 'madhya', 'tara'] as const).map(s => (
                    <button
                      key={s}
                      type="button"
                      onClick={() => setOctave(s)}
                      className={`px-3 py-1 rounded-lg capitalize font-bold cursor-pointer ${
                        octave === s ? 'bg-white text-emerald-700 shadow-xs' : 'text-slate-600'
                      }`}
                    >
                      {s} Sthayi
                    </button>
                  ))}
                </div>
              </div>

              {/* Swaras Buttons */}
              <div className="grid grid-cols-4 sm:grid-cols-6 lg:grid-cols-12 gap-2">
                {Object.keys(SWARA_RATIOS).map(swara => (
                  <button
                    key={swara}
                    type="button"
                    onClick={() => playSwara(swara)}
                    className="p-3.5 rounded-xl border border-emerald-300 bg-emerald-50 hover:bg-emerald-600 hover:text-white text-emerald-900 font-black text-sm flex flex-col items-center justify-center shadow-xs transition active:scale-95 cursor-pointer"
                  >
                    <span>{swara}</span>
                    <span className="text-[9px] font-normal opacity-80 mt-0.5">
                      {swara === 'S' ? 'Shadjam' : swara.startsWith('R') ? 'Rishabha' : swara.startsWith('G') ? 'Gandhara' : swara.startsWith('M') ? 'Madhyama' : swara === 'P' ? 'Panchama' : swara.startsWith('D') ? 'Dhaivatha' : 'Nishadha'}
                    </span>
                  </button>
                ))}
              </div>

              {/* Notation Editor Textarea */}
              <textarea
                value={notationOutput}
                onChange={e => setNotationOutput(e.target.value)}
                rows={4}
                className="w-full rounded-2xl border border-slate-300 p-4 font-mono text-xs text-slate-900 leading-relaxed bg-white shadow-inner focus:outline-hidden"
                placeholder="Notation transcribed here..."
              />
            </div>
          )}

          {/* TOOL 4: 72 MELAKARTA & RAGA EXPLORER */}
          {activeToolTab === 'ragas' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {Object.entries(POPULAR_RAGAS).map(([key, raga]) => (
                  <div key={key} className="p-4 rounded-2xl border border-amber-200 bg-white shadow-xs space-y-2">
                    <div className="flex items-center justify-between">
                      <h5 className="font-bold text-sm text-slate-900">{raga.name}</h5>
                      <span className="text-[11px] font-mono font-bold text-amber-800 bg-amber-100 px-2 py-0.5 rounded">
                        Mela #{raga.mela}
                      </span>
                    </div>
                    <span className="text-[11px] text-slate-500 font-medium block">{raga.chakra}</span>
                    <div className="bg-amber-50 p-2.5 rounded-xl border border-amber-200 text-xs font-mono space-y-1">
                      <p><strong className="text-amber-900 font-sans">Arohana:</strong> {raga.arohana}</p>
                      <p><strong className="text-amber-900 font-sans">Avarohana:</strong> {raga.avarohana}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TOOL 5: SAPTA TALA ALANKARAS */}
          {activeToolTab === 'alankaras' && (
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
              <h4 className="text-base font-bold text-slate-900">The 7 Suladi Sapta Tala Alankaras</h4>
              <p className="text-xs text-slate-500">
                Foundational rhythmic exercises formulated by Saint Purandara Dasa.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                  <span className="font-bold text-indigo-900">1. Dhruva Tala Alankara (I4 O I4 I4)</span>
                  <p className="font-mono text-slate-700">|| S R G M | P D | N S' R' G' | M' P' D' N' ||</p>
                </div>
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                  <span className="font-bold text-indigo-900">2. Matya Tala Alankara (I4 O I4)</span>
                  <p className="font-mono text-slate-700">|| S R G M | P D | N S' R' G' ||</p>
                </div>
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                  <span className="font-bold text-indigo-900">3. Rupaka Tala Alankara (O I4)</span>
                  <p className="font-mono text-slate-700">|| S R | G M P D || R G | M P D N ||</p>
                </div>
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                  <span className="font-bold text-indigo-900">4. Triputa Tala Alankara (Adi Tala) (I4 O O)</span>
                  <p className="font-mono text-slate-700">|| S R G | M P | D N || R G M | P D | N S' ||</p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-between border-t border-slate-200 bg-white px-6 py-4">
          <span className="text-xs text-slate-500">
            All tools can be attached to tasks when posting assignments or exams.
          </span>
          <button
            type="button"
            onClick={onClose}
            className="rounded-xl bg-slate-900 hover:bg-slate-800 text-white px-6 py-2.5 text-xs font-bold shadow-xs cursor-pointer"
          >
            Close Lab Tools
          </button>
        </div>
      </div>
    </div>
  );
};
