import React, { useState } from 'react';
import { 
  StudentProfile, 
  Task, 
  Submission, 
  ReportCard, 
  ReportCardItem,
  ClassGroup 
} from '../../types';
import { saveReportCard } from '../../data/storage';
import { 
  Award, 
  X, 
  Send, 
  Printer, 
  FileText, 
  CheckCircle2, 
  Sparkles, 
  User, 
  School,
  Edit3
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface ReportCardModalProps {
  students: StudentProfile[];
  tasks: Task[];
  submissions: Submission[];
  currentClass: ClassGroup;
  onClose: () => void;
  onPublished?: () => void;
}

export const ReportCardModal: React.FC<ReportCardModalProps> = ({
  students,
  tasks,
  submissions,
  currentClass,
  onClose,
  onPublished,
}) => {
  const [selectedStudentId, setSelectedStudentId] = useState<string>(students[0]?.id || 'std-1');
  const [termName, setTermName] = useState<string>('Annual Carnatic Classical & Academic Assessment 2026-27');
  const [institutionName, setInstitutionName] = useState<string>('Saraswati Sangeetha & Classical Vidyalaya');
  const [teacherRemarks, setTeacherRemarks] = useState<string>(
    'Exhibits exceptional dedication to classical arts and academic assignments. Demonstrates profound mastery over Raga Lakshana, Tala synchronization, and structured presentation.'
  );
  const [principalSign, setPrincipalSign] = useState<string>('Dr. V. Radhakrishnan (Director & Principal)');
  const [evaluatorSign, setEvaluatorSign] = useState<string>('Vidwan K. Narayanaswamy (Lead Music Guru)');

  const selectedStudent = students.find(s => s.id === selectedStudentId) || students[0];

  // Get submissions for selected student
  const studentSubs = submissions.filter(s => s.studentId === selectedStudent.id);

  // Generate Report Items from evaluated submissions
  const reportItems: ReportCardItem[] = tasks.map(task => {
    const sub = studentSubs.find(s => s.taskId === task.id);
    const marksObtained = sub?.correction?.grade ?? (sub ? Math.round(task.maxPoints * 0.85) : 0);
    const letterGrade = sub?.correction?.letterGrade ?? (
      marksObtained / task.maxPoints >= 0.9 ? 'A+' :
      marksObtained / task.maxPoints >= 0.8 ? 'A' :
      marksObtained / task.maxPoints >= 0.7 ? 'B+' : 'B'
    );
    const remarks = sub?.correction?.feedback || (sub ? 'Submitted and verified by faculty.' : 'Pending submission.');

    return {
      taskId: task.id,
      taskTitle: task.title,
      taskType: task.type,
      category: task.category,
      maxMarks: task.maxPoints,
      marksObtained,
      letterGrade,
      remarks,
    };
  });

  const totalMax = reportItems.reduce((acc, item) => acc + item.maxMarks, 0);
  const totalScored = reportItems.reduce((acc, item) => acc + item.marksObtained, 0);
  const percentage = totalMax > 0 ? Math.round((totalScored / totalMax) * 100) : 0;

  const overallGrade = 
    percentage >= 90 ? 'A+' :
    percentage >= 80 ? 'A' :
    percentage >= 70 ? 'B+' :
    percentage >= 60 ? 'B' : 'C';

  const overallStatus = 
    percentage >= 85 ? 'Distinction' :
    percentage >= 70 ? 'First Class' :
    percentage >= 50 ? 'Pass' : 'Needs Improvement';

  const handlePublish = () => {
    const reportCard: ReportCard = {
      id: `rep-${selectedStudent.id}-${Date.now()}`,
      studentId: selectedStudent.id,
      studentName: selectedStudent.name,
      classId: currentClass.id,
      className: currentClass.name,
      rollNo: selectedStudent.rollNo,
      term: termName,
      issuedDate: new Date().toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' }),
      institutionName,
      items: reportItems,
      totalMaxMarks: totalMax,
      totalMarksObtained: totalScored,
      percentage,
      overallGrade,
      overallStatus,
      attendancePercentage: selectedStudent.attendancePercentage || 96,
      teacherRemarks,
      principalSignature: principalSign,
      evaluatorName: evaluatorSign,
      publishedToStudent: true,
      publishedAt: new Date().toISOString(),
    };

    saveReportCard(reportCard);

    confetti({
      particleCount: 70,
      spread: 80,
      origin: { y: 0.6 },
    });

    if (onPublished) onPublished();
    onClose();
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-950/80 backdrop-blur-xs overflow-y-auto">
      <div className="relative w-full max-w-5xl rounded-2xl bg-white shadow-2xl border border-slate-200 overflow-hidden my-4 flex flex-col max-h-[92vh]">
        {/* Modal Top Bar */}
        <div className="flex items-center justify-between border-b border-slate-200 bg-slate-50 px-6 py-3 shrink-0">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-amber-600 text-white flex items-center justify-center font-bold">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">Official Student Report Card Generator</h3>
              <p className="text-xs text-slate-500">Provide formal template, evaluate total scores, and publish directly to student</p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Student Selector Toolbar */}
        <div className="bg-amber-50/70 border-b border-amber-200 px-6 py-3 flex flex-wrap items-center justify-between gap-3 text-xs shrink-0">
          <div className="flex items-center gap-2">
            <span className="font-bold text-amber-900">Select Student (15 Class Enrolled):</span>
            <select
              value={selectedStudentId}
              onChange={e => setSelectedStudentId(e.target.value)}
              className="rounded-lg border border-amber-300 bg-white p-1.5 font-bold text-slate-800 shadow-2xs"
            >
              {students.map(s => (
                <option key={s.id} value={s.id}>{s.name} ({s.rollNo})</option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-100 text-slate-700 font-bold transition shadow-2xs cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print Preview</span>
            </button>
            <button
              type="button"
              onClick={handlePublish}
              className="flex items-center gap-1.5 px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold transition shadow-xs cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Publish & Send to Student</span>
            </button>
          </div>
        </div>

        {/* Scrollable Report Card Template Preview */}
        <div className="flex-1 overflow-y-auto p-6 sm:p-8 bg-slate-100/60 flex justify-center">
          {/* Formal Certificate / Report Card Paper */}
          <div className="w-full max-w-4xl bg-white border-4 border-amber-600/40 rounded-xl p-8 sm:p-12 shadow-xl text-slate-900 relative flex flex-col justify-between">
            {/* Elegant Header with Academy Crest */}
            <div className="border-b-2 border-amber-800/20 pb-6 text-center space-y-2">
              <div className="flex items-center justify-center gap-2 text-amber-800 font-bold text-sm uppercase tracking-widest">
                <School className="w-5 h-5 text-amber-700" />
                <span>Affiliated Classical Fine Arts & Academic Board</span>
              </div>
              <input
                type="text"
                value={institutionName}
                onChange={e => setInstitutionName(e.target.value)}
                className="text-center font-serif text-2xl sm:text-3xl font-black text-amber-950 w-full focus:outline-hidden bg-transparent"
              />
              <input
                type="text"
                value={termName}
                onChange={e => setTermName(e.target.value)}
                className="text-center text-xs sm:text-sm font-sans font-bold text-amber-800 uppercase tracking-wider w-full focus:outline-hidden bg-transparent"
              />
            </div>

            {/* Student Bio Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 py-6 border-b border-slate-200 text-xs font-sans">
              <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200">
                <span className="text-slate-500 font-semibold block">Student Name</span>
                <span className="font-bold text-slate-900 text-sm">{selectedStudent.name}</span>
              </div>
              <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200">
                <span className="text-slate-500 font-semibold block">Roll Number</span>
                <span className="font-bold text-slate-900 text-sm font-mono">{selectedStudent.rollNo}</span>
              </div>
              <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200">
                <span className="text-slate-500 font-semibold block">Class & Section</span>
                <span className="font-bold text-slate-900 text-sm">{currentClass.name}</span>
              </div>
              <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200">
                <span className="text-slate-500 font-semibold block">Attendance</span>
                <span className="font-bold text-emerald-700 text-sm">{selectedStudent.attendancePercentage || 96}% (Regular)</span>
              </div>
            </div>

            {/* Assessment Breakdown Table */}
            <div className="py-6 space-y-3">
              <h4 className="text-xs font-black uppercase tracking-wider text-slate-700">
                Academic & Carnatic Performance Evaluation:
              </h4>

              <div className="overflow-x-auto rounded-lg border border-slate-300">
                <table className="w-full text-left text-xs border-collapse font-sans">
                  <thead>
                    <tr className="bg-amber-100/70 text-amber-950 font-bold border-b border-amber-300">
                      <th className="p-2.5">Subject / Task Title</th>
                      <th className="p-2.5 text-center">Category</th>
                      <th className="p-2.5 text-center">Max Marks</th>
                      <th className="p-2.5 text-center">Marks Scored</th>
                      <th className="p-2.5 text-center">Grade</th>
                      <th className="p-2.5">Teacher Evaluation Remarks</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {reportItems.map((item, idx) => (
                      <tr key={idx} className="hover:bg-slate-50">
                        <td className="p-2.5 font-bold text-slate-900">{item.taskTitle}</td>
                        <td className="p-2.5 text-center capitalize text-slate-600 font-medium">
                          {item.category.replace('_', ' ')}
                        </td>
                        <td className="p-2.5 text-center font-mono font-bold text-slate-700">{item.maxMarks}</td>
                        <td className="p-2.5 text-center font-mono font-black text-indigo-700">{item.marksObtained}</td>
                        <td className="p-2.5 text-center">
                          <span className="font-bold text-xs bg-indigo-50 text-indigo-800 px-2 py-0.5 rounded border border-indigo-200">
                            {item.letterGrade}
                          </span>
                        </td>
                        <td className="p-2.5 text-slate-600 italic text-[11px]">{item.remarks}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Performance Summary Banner */}
            <div className="bg-gradient-to-r from-amber-500/10 via-amber-500/20 to-amber-500/10 rounded-xl p-5 border border-amber-300 grid grid-cols-2 sm:grid-cols-4 gap-4 text-center my-4">
              <div>
                <span className="text-xs text-amber-900 font-semibold block">Total Marks</span>
                <span className="text-xl font-black text-amber-950">{totalScored} / {totalMax}</span>
              </div>
              <div>
                <span className="text-xs text-amber-900 font-semibold block">Percentage</span>
                <span className="text-xl font-black text-amber-950">{percentage}%</span>
              </div>
              <div>
                <span className="text-xs text-amber-900 font-semibold block">Overall Grade</span>
                <span className="text-xl font-black text-indigo-700">{overallGrade}</span>
              </div>
              <div>
                <span className="text-xs text-amber-900 font-semibold block">Result Standing</span>
                <span className="text-xl font-black text-emerald-700">{overallStatus}</span>
              </div>
            </div>

            {/* Teacher Remarks Box */}
            <div className="py-4 space-y-1.5">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-700 block">
                Class Guru / Teacher's Comprehensive Remarks:
              </label>
              <textarea
                value={teacherRemarks}
                onChange={e => setTeacherRemarks(e.target.value)}
                rows={3}
                className="w-full rounded-lg border border-slate-300 p-3 text-xs text-slate-800 leading-relaxed font-sans bg-slate-50 focus:outline-hidden focus:border-amber-500"
              />
            </div>

            {/* Signatures & Seal */}
            <div className="pt-8 mt-6 border-t-2 border-slate-200 grid grid-cols-2 sm:grid-cols-3 gap-6 items-end text-xs font-sans text-center">
              <div>
                <input
                  type="text"
                  value={evaluatorSign}
                  onChange={e => setEvaluatorSign(e.target.value)}
                  className="w-full text-center font-bold text-slate-900 border-b border-slate-300 pb-1 focus:outline-hidden"
                />
                <span className="text-slate-400 text-[10px] uppercase tracking-wider mt-1 block">Lead Music Guru / Faculty</span>
              </div>

              <div className="flex flex-col items-center">
                <div className="w-16 h-16 rounded-full border-2 border-dashed border-amber-600 flex items-center justify-center text-[10px] font-bold text-amber-800 uppercase text-center p-1">
                  OFFICIAL SEAL
                </div>
                <span className="text-slate-400 text-[10px] uppercase tracking-wider mt-1">Verified Accreditation</span>
              </div>

              <div>
                <input
                  type="text"
                  value={principalSign}
                  onChange={e => setPrincipalSign(e.target.value)}
                  className="w-full text-center font-bold text-slate-900 border-b border-slate-300 pb-1 focus:outline-hidden"
                />
                <span className="text-slate-400 text-[10px] uppercase tracking-wider mt-1 block">Director & Principal</span>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="border-t border-slate-200 bg-slate-50 px-6 py-3 flex items-center justify-between shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100 cursor-pointer"
          >
            Close
          </button>
          <button
            type="button"
            onClick={handlePublish}
            className="flex items-center gap-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white px-6 py-2 text-xs font-bold shadow-xs transition cursor-pointer"
          >
            <Send className="w-4 h-4" />
            <span>Publish Report Card to {selectedStudent.name}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
