import React, { useState } from 'react';
import { ClassGroup, StudentProfile } from '../../types';
import { 
  getClasses, 
  saveClass, 
  deleteClass, 
  setCurrentClass, 
  getStudentsRoster, 
  addOrUpdateStudent, 
  deleteStudent 
} from '../../data/storage';
import { Users, School, Plus, Trash2, X, Check, CheckCircle2, UserPlus, BookOpen } from 'lucide-react';

interface ClassManagementModalProps {
  currentClass: ClassGroup;
  classes: ClassGroup[];
  students: StudentProfile[];
  onClose: () => void;
  onClassChanged: (cls: ClassGroup) => void;
  onRosterUpdated: () => void;
}

const INDIAN_SAMPLE_NAMES = [
  'Aditi Deshpande', 'Harish Kalyan', 'Nandini Swaminathan', 'Varun Chandrasekhar',
  'Deepa Murthy', 'Abhinav Sundaram', 'Radhika Menon', 'Gautam Raghavan',
  'Swati Bhattacharya', 'Pranav Kulkarni', 'Archana Sastry', 'Vigneshwaran M.',
  'Tanvi Joshi', 'Manish Acharya', 'Bhavani Sankaran'
];

export const ClassManagementModal: React.FC<ClassManagementModalProps> = ({
  currentClass,
  classes,
  students,
  onClose,
  onClassChanged,
  onRosterUpdated,
}) => {
  const [activeTab, setActiveTab] = useState<'classes' | 'students'>('classes');
  
  // New Class Form
  const [isCreatingClass, setIsCreatingClass] = useState<boolean>(false);
  const [newClassName, setNewClassName] = useState<string>('Class 8 - Junior Carnatic Sangeeth');
  const [newClassSection, setNewClassSection] = useState<string>('Section A');
  const [newClassSubject, setNewClassSubject] = useState<string>('Carnatic Music & Abhyasa Ganam');

  // New Student Form
  const [isAddingStudent, setIsAddingStudent] = useState<boolean>(false);
  const [newStudentName, setNewStudentName] = useState<string>('Bhavani Sankaran');
  const [newStudentRoll, setNewStudentRoll] = useState<string>(`IND-${students.length + 1}`);

  const handleCreateClass = () => {
    if (!newClassName.trim()) return;

    const newClass: ClassGroup = {
      id: 'cls-' + Date.now(),
      name: newClassName.trim(),
      section: newClassSection.trim(),
      subject: newClassSubject.trim(),
      academicYear: '2026-2027',
      createdAt: new Date().toISOString(),
      studentCount: 15,
    };

    saveClass(newClass);

    // Auto-seed 15 default Indian students for this new class (4 bright, 3 average, 8 failing)
    INDIAN_SAMPLE_NAMES.forEach((name, idx) => {
      const tier = idx < 4 ? 'bright' : idx < 7 ? 'average' : 'failing';
      const newStd: StudentProfile = {
        id: `std-${newClass.id}-${idx + 1}`,
        name,
        avatarColor: ['#3b82f6', '#10b981', '#8b5cf6', '#f59e0b', '#ec4899', '#06b6d4', '#6366f1'][idx % 7],
        section: `${newClass.name} - ${newClass.section}`,
        rollNo: `ROLL-${(idx + 1).toString().padStart(2, '0')}`,
        classId: newClass.id,
        attendancePercentage: Math.floor(Math.random() * 8) + 92,
        tier,
      };
      addOrUpdateStudent(newStd);
    });

    onClassChanged(newClass);
    onRosterUpdated();
    setIsCreatingClass(false);
  };

  const handleAddStudent = () => {
    if (!newStudentName.trim()) return;

    const newStudent: StudentProfile = {
      id: 'std-' + Date.now(),
      name: newStudentName.trim(),
      avatarColor: '#10b981',
      section: `${currentClass.name} - ${currentClass.section}`,
      rollNo: newStudentRoll.trim() || `ROLL-${students.length + 1}`,
      classId: currentClass.id,
      attendancePercentage: 96,
      tier: 'average',
    };

    addOrUpdateStudent(newStudent);
    onRosterUpdated();
    setIsAddingStudent(false);
    setNewStudentName('');
  };

  const handleDeleteClass = (classId: string) => {
    if (classes.length <= 1) {
      alert('You must have at least one class.');
      return;
    }
    if (confirm('Delete this class?')) {
      deleteClass(classId);
      const remaining = classes.filter(c => c.id !== classId);
      onClassChanged(remaining[0]);
    }
  };

  const handleDeleteStudent = (studentId: string) => {
    if (confirm('Remove student from class roster?')) {
      deleteStudent(studentId);
      onRosterUpdated();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-950/80 backdrop-blur-xs overflow-y-auto">
      <div className="relative w-full max-w-4xl rounded-2xl bg-white shadow-2xl border border-slate-200 overflow-hidden my-4 flex flex-col max-h-[90vh]">
        {/* Top Header */}
        <div className="flex items-center justify-between border-b border-slate-200 bg-slate-50 px-6 py-3.5 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-600 text-white flex items-center justify-center font-bold">
              <School className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">Classes & Student Roster Management</h3>
              <p className="text-xs text-slate-500">
                Manage academic classes and enrolled students (Default 15 Indian Students per class)
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switcher */}
        <div className="flex items-center gap-2 px-6 pt-3 border-b border-slate-200 bg-white text-xs shrink-0">
          <button
            type="button"
            onClick={() => setActiveTab('classes')}
            className={`pb-2.5 font-bold border-b-2 transition cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'classes'
                ? 'border-indigo-600 text-indigo-700'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <School className="w-4 h-4" />
            <span>Classes & Batches ({classes.length})</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('students')}
            className={`pb-2.5 font-bold border-b-2 transition cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'students'
                ? 'border-indigo-600 text-indigo-700'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>Class Student Roster ({students.length} Indian Students)</span>
          </button>
        </div>

        {/* Tab 1: Classes */}
        <div className="flex-1 overflow-y-auto p-6 space-y-5 bg-slate-50">
          {activeTab === 'classes' && (
            <>
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-700">All Academic Classes:</span>
                <button
                  type="button"
                  onClick={() => setIsCreatingClass(true)}
                  className="flex items-center gap-1 bg-indigo-600 hover:bg-indigo-700 text-white px-3 py-1.5 rounded-lg text-xs font-bold shadow-xs cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>+ Create New Class</span>
                </button>
              </div>

              {/* Create Class Form */}
              {isCreatingClass && (
                <div className="bg-white p-5 rounded-xl border-2 border-indigo-200 shadow-sm space-y-3">
                  <h4 className="text-xs font-bold text-indigo-950 uppercase tracking-wider">
                    New Class Details (Will automatically enroll 15 Indian students):
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                    <div>
                      <label className="text-slate-600 font-semibold block mb-1">Class Name:</label>
                      <input
                        type="text"
                        value={newClassName}
                        onChange={e => setNewClassName(e.target.value)}
                        className="w-full rounded-lg border border-slate-300 p-2 font-bold text-slate-800"
                        placeholder="e.g. Class 8 - Junior Carnatic"
                      />
                    </div>
                    <div>
                      <label className="text-slate-600 font-semibold block mb-1">Section:</label>
                      <input
                        type="text"
                        value={newClassSection}
                        onChange={e => setNewClassSection(e.target.value)}
                        className="w-full rounded-lg border border-slate-300 p-2 text-slate-800"
                        placeholder="e.g. Section A"
                      />
                    </div>
                    <div>
                      <label className="text-slate-600 font-semibold block mb-1">Subject / Focus:</label>
                      <input
                        type="text"
                        value={newClassSubject}
                        onChange={e => setNewClassSubject(e.target.value)}
                        className="w-full rounded-lg border border-slate-300 p-2 text-slate-800"
                        placeholder="e.g. Carnatic Vocal"
                      />
                    </div>
                  </div>
                  <div className="flex justify-end gap-2 pt-2">
                    <button
                      type="button"
                      onClick={() => setIsCreatingClass(false)}
                      className="px-3 py-1.5 rounded text-xs text-slate-600 hover:bg-slate-100"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      onClick={handleCreateClass}
                      className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold px-4 py-1.5 rounded text-xs"
                    >
                      Save & Seed 15 Students
                    </button>
                  </div>
                </div>
              )}

              {/* Class Cards List */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {classes.map(cls => {
                  const isCurrent = cls.id === currentClass.id;
                  return (
                    <div
                      key={cls.id}
                      className={`p-5 rounded-xl border transition flex flex-col justify-between ${
                        isCurrent
                          ? 'bg-white border-indigo-500 shadow-md ring-2 ring-indigo-200'
                          : 'bg-white border-slate-200 hover:border-slate-300 shadow-2xs'
                      }`}
                    >
                      <div>
                        <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-100">
                          <span className="text-xs font-bold text-indigo-700 uppercase tracking-wider">
                            {cls.section} · {cls.academicYear}
                          </span>
                          {isCurrent && (
                            <span className="text-[11px] font-bold bg-indigo-100 text-indigo-800 px-2 py-0.5 rounded flex items-center gap-1">
                              <CheckCircle2 className="w-3 h-3 text-indigo-600" />
                              Active Class
                            </span>
                          )}
                        </div>

                        <h4 className="text-base font-bold text-slate-900">{cls.name}</h4>
                        <p className="text-xs text-slate-500 mt-1">{cls.subject}</p>
                        <p className="text-xs text-slate-600 font-semibold mt-2">
                          15 Indian Students Enrolled
                        </p>
                      </div>

                      <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-between">
                        {!isCurrent ? (
                          <button
                            type="button"
                            onClick={() => {
                              setCurrentClass(cls);
                              onClassChanged(cls);
                            }}
                            className="text-xs font-bold text-indigo-600 hover:text-indigo-800 cursor-pointer"
                          >
                            Switch to this Class →
                          </button>
                        ) : (
                          <span className="text-xs text-emerald-700 font-bold">Currently Selected</span>
                        )}

                        {classes.length > 1 && (
                          <button
                            type="button"
                            onClick={() => handleDeleteClass(cls.id)}
                            className="text-slate-400 hover:text-rose-600 p-1 cursor-pointer"
                            title="Delete Class"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </>
          )}

          {/* Tab 2: Students List (15 Indian Students) */}
          {activeTab === 'students' && (
            <>
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-bold text-slate-900">{currentClass.name} - Student Roster</h4>
                  <p className="text-xs text-slate-500">{students.length} Enrolled Indian Students</p>
                </div>

                <button
                  type="button"
                  onClick={() => setIsAddingStudent(true)}
                  className="flex items-center gap-1 bg-emerald-600 hover:bg-emerald-700 text-white px-3 py-1.5 rounded-lg text-xs font-bold shadow-xs cursor-pointer"
                >
                  <UserPlus className="w-3.5 h-3.5" />
                  <span>+ Add Student</span>
                </button>
              </div>

              {/* Add Student Form */}
              {isAddingStudent && (
                <div className="bg-white p-4 rounded-xl border-2 border-emerald-300 shadow-sm space-y-3">
                  <h5 className="text-xs font-bold text-emerald-950 uppercase tracking-wider">
                    Add New Student (Indian Name):
                  </h5>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                    <div>
                      <label className="text-slate-600 font-semibold block mb-1">Student Full Name:</label>
                      <input
                        type="text"
                        value={newStudentName}
                        onChange={e => setNewStudentName(e.target.value)}
                        className="w-full rounded border border-slate-300 p-2 font-bold text-slate-800"
                        placeholder="e.g. Bhavani Sankaran"
                      />
                    </div>
                    <div>
                      <label className="text-slate-600 font-semibold block mb-1">Roll Number:</label>
                      <input
                        type="text"
                        value={newStudentRoll}
                        onChange={e => setNewStudentRoll(e.target.value)}
                        className="w-full rounded border border-slate-300 p-2 font-mono text-slate-800"
                        placeholder="e.g. CS-16"
                      />
                    </div>
                  </div>
                  <div className="flex justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => setIsAddingStudent(false)}
                      className="px-3 py-1 rounded text-xs text-slate-600"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      onClick={handleAddStudent}
                      className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-4 py-1 rounded text-xs"
                    >
                      Save Student
                    </button>
                  </div>
                </div>
              )}

              {/* 15 Indian Students Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {students.map((student, idx) => (
                  <div
                    key={student.id}
                    className="p-3.5 bg-white rounded-xl border border-slate-200 shadow-2xs flex items-center justify-between"
                  >
                    <div className="flex items-center gap-3">
                      <div 
                        className="w-9 h-9 rounded-full flex items-center justify-center text-white font-bold text-xs shadow-xs"
                        style={{ backgroundColor: student.avatarColor || '#3b82f6' }}
                      >
                        {student.name.slice(0, 2).toUpperCase()}
                      </div>
                      <div>
                        <h5 className="text-xs font-bold text-slate-900">{student.name}</h5>
                        <p className="text-[11px] text-slate-500 font-mono">
                          {student.rollNo} · {student.attendancePercentage || 96}% Attend.
                        </p>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleDeleteStudent(student.id)}
                      className="text-slate-300 hover:text-rose-600 p-1 cursor-pointer"
                      title="Remove student"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>

        {/* Footer */}
        <div className="border-t border-slate-200 bg-white px-6 py-3 flex justify-end shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs font-bold text-slate-700 hover:bg-slate-100 cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
