import React, { useState } from 'react';
import { Task, Submission, StudentProfile, InterconnectedTaskBundle, ClassGroup } from '../../types';
import { saveTaskBundle, deleteTaskBundle } from '../../data/storage';
import { Link2, Plus, Trash2, CheckCircle2, Calculator, Award, X, Sparkles } from 'lucide-react';

interface InterconnectedTasksModalProps {
  tasks: Task[];
  submissions: Submission[];
  students: StudentProfile[];
  currentClass: ClassGroup;
  bundles: InterconnectedTaskBundle[];
  onClose: () => void;
  onOpenReportCardForStudent?: (studentId: string) => void;
  onRefreshBundles?: () => void;
}

export const InterconnectedTasksModal: React.FC<InterconnectedTasksModalProps> = ({
  tasks,
  submissions,
  students,
  currentClass,
  bundles,
  onClose,
  onOpenReportCardForStudent,
  onRefreshBundles,
}) => {
  const [selectedBundleId, setSelectedBundleId] = useState<string>(bundles[0]?.id || '');
  const [isCreatingNew, setIsCreatingNew] = useState<boolean>(bundles.length === 0);

  // New Bundle Form state
  const [bundleTitle, setBundleTitle] = useState<string>('Carnatic Music Combined Semester Assessment');
  const [bundleDescription, setBundleDescription] = useState<string>(
    'Interconnects Part A Theory Exam (40 marks) and Part B Viva Singing (10 marks) for comprehensive 50-mark evaluation.'
  );
  const [selectedTaskIds, setSelectedTaskIds] = useState<string[]>(
    tasks.slice(0, 2).map(t => t.id)
  );

  const activeBundle = bundles.find(b => b.id === selectedBundleId) || bundles[0];

  const handleToggleTask = (taskId: string) => {
    setSelectedTaskIds(prev => 
      prev.includes(taskId) ? prev.filter(id => id !== taskId) : [...prev, taskId]
    );
  };

  const handleCreateBundle = () => {
    if (!bundleTitle.trim() || selectedTaskIds.length < 2) {
      alert('Please enter a title and select at least 2 tasks to interconnect.');
      return;
    }

    const linkedTasks = tasks.filter(t => selectedTaskIds.includes(t.id));
    const totalMax = linkedTasks.reduce((acc, t) => acc + t.maxPoints, 0);

    const newBundle: InterconnectedTaskBundle = {
      id: 'bundle-' + Date.now(),
      title: bundleTitle.trim(),
      description: bundleDescription.trim(),
      classId: currentClass.id,
      taskIds: selectedTaskIds,
      totalMaxMarks: totalMax,
      createdAt: new Date().toISOString(),
    };

    saveTaskBundle(newBundle);
    setSelectedBundleId(newBundle.id);
    setIsCreatingNew(false);
    if (onRefreshBundles) onRefreshBundles();
  };

  const handleDeleteBundle = (bundleId: string) => {
    if (confirm('Delete this interconnected task bundle?')) {
      deleteTaskBundle(bundleId);
      if (onRefreshBundles) onRefreshBundles();
      setSelectedBundleId('');
    }
  };

  // Calculate scores for a given bundle across all 15 students
  const bundleTasks = activeBundle ? tasks.filter(t => activeBundle.taskIds.includes(t.id)) : [];
  const bundleTotalMax = activeBundle?.totalMaxMarks || bundleTasks.reduce((acc, t) => acc + t.maxPoints, 0);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-950/80 backdrop-blur-xs overflow-y-auto">
      <div className="relative w-full max-w-5xl rounded-2xl bg-white shadow-2xl border border-slate-200 overflow-hidden my-4 flex flex-col max-h-[92vh]">
        {/* Top Header */}
        <div className="flex items-center justify-between border-b border-slate-200 bg-slate-50 px-6 py-3.5 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-600 text-white flex items-center justify-center font-bold">
              <Link2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">Task Interconnection & Marks Aggregator</h3>
              <p className="text-xs text-slate-500">
                Connect multiple tasks (e.g. 40 Marks Theory + 10 Marks Viva) and calculate student aggregates
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-50">
          {/* Bundle Selector Bar */}
          <div className="flex flex-wrap items-center justify-between gap-3 bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
            <div className="flex items-center gap-3">
              <span className="text-xs font-bold text-slate-700">Active Assessment Bundles:</span>
              {bundles.length > 0 ? (
                <div className="flex flex-wrap gap-2">
                  {bundles.map(b => (
                    <button
                      key={b.id}
                      type="button"
                      onClick={() => {
                        setSelectedBundleId(b.id);
                        setIsCreatingNew(false);
                      }}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                        selectedBundleId === b.id && !isCreatingNew
                          ? 'bg-indigo-600 text-white shadow-xs'
                          : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                      }`}
                    >
                      {b.title} ({b.totalMaxMarks} Marks)
                    </button>
                  ))}
                </div>
              ) : (
                <span className="text-xs text-slate-400 italic">No bundles created yet.</span>
              )}
            </div>

            <button
              type="button"
              onClick={() => setIsCreatingNew(true)}
              className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white px-3 py-1.5 rounded-lg text-xs font-bold shadow-xs cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>+ Interconnect New Tasks</span>
            </button>
          </div>

          {/* Creation Form if Active */}
          {isCreatingNew && (
            <div className="bg-white p-6 rounded-xl border-2 border-indigo-200 shadow-sm space-y-4">
              <div className="flex items-center justify-between border-b border-slate-200 pb-3">
                <span className="font-bold text-sm text-slate-900 flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-indigo-600" />
                  <span>Connect Multiple Tasks into Assessment Bundle</span>
                </span>
                {bundles.length > 0 && (
                  <button
                    type="button"
                    onClick={() => setIsCreatingNew(false)}
                    className="text-xs text-slate-500 hover:underline"
                  >
                    Cancel
                  </button>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">Bundle Assessment Name:</label>
                  <input
                    type="text"
                    value={bundleTitle}
                    onChange={e => setBundleTitle(e.target.value)}
                    className="w-full text-xs font-bold text-slate-800 p-2.5 rounded-lg border border-slate-300 focus:outline-hidden focus:border-indigo-500"
                    placeholder="e.g. Carnatic Music Mid-Term (Theory 40 + Viva 10)"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">Assessment Description:</label>
                  <input
                    type="text"
                    value={bundleDescription}
                    onChange={e => setBundleDescription(e.target.value)}
                    className="w-full text-xs text-slate-800 p-2.5 rounded-lg border border-slate-300 focus:outline-hidden focus:border-indigo-500"
                    placeholder="Brief evaluation objective..."
                  />
                </div>
              </div>

              {/* Task Selection Checkboxes */}
              <div>
                <label className="text-xs font-bold text-slate-800 block mb-2">
                  Select Tasks to Interconnect & Aggregate (Check 2 or more):
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {tasks.map(t => {
                    const isChecked = selectedTaskIds.includes(t.id);
                    return (
                      <div
                        key={t.id}
                        onClick={() => handleToggleTask(t.id)}
                        className={`p-3 rounded-lg border text-xs flex items-center justify-between cursor-pointer transition ${
                          isChecked
                            ? 'bg-indigo-50/80 border-indigo-400 text-indigo-950 font-bold'
                            : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                        }`}
                      >
                        <div className="flex items-center gap-2 truncate">
                          <input
                            type="checkbox"
                            checked={isChecked}
                            onChange={() => {}}
                            className="rounded accent-indigo-600"
                          />
                          <span className="truncate">{t.title}</span>
                        </div>
                        <span className="bg-white border px-2 py-0.5 rounded font-mono text-[11px] text-slate-600 shrink-0">
                          {t.maxPoints} pts
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Calculated Total Banner */}
              <div className="flex items-center justify-between bg-slate-50 p-3 rounded-lg border border-slate-200 text-xs">
                <span className="font-semibold text-slate-600">
                  Total Max Marks for Connected Tasks:
                </span>
                <span className="text-base font-black text-indigo-700 font-mono">
                  {tasks.filter(t => selectedTaskIds.includes(t.id)).reduce((acc, t) => acc + t.maxPoints, 0)} Marks Total
                </span>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={handleCreateBundle}
                  className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold px-5 py-2 rounded-lg text-xs shadow-xs cursor-pointer"
                >
                  Save Interconnected Bundle
                </button>
              </div>
            </div>
          )}

          {/* Active Bundle Details & Multi-Student Marks Matrix */}
          {activeBundle && !isCreatingNew && (
            <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
              {/* Bundle Header */}
              <div className="p-5 border-b border-slate-200 bg-gradient-to-r from-indigo-50/60 to-white flex flex-wrap items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="text-base font-bold text-slate-900">{activeBundle.title}</h4>
                    <span className="bg-indigo-100 text-indigo-800 font-mono font-bold text-xs px-2.5 py-0.5 rounded">
                      Combined Total: {bundleTotalMax} Marks
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 mt-1">{activeBundle.description}</p>
                </div>

                <button
                  type="button"
                  onClick={() => handleDeleteBundle(activeBundle.id)}
                  className="flex items-center gap-1 text-xs text-rose-600 hover:text-rose-800 font-semibold cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Delete Bundle</span>
                </button>
              </div>

              {/* Student Marks Aggregator Table across the 15 Indian students */}
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                      <th className="p-3">Roll No</th>
                      <th className="p-3">Student Name</th>
                      {bundleTasks.map(bt => (
                        <th key={bt.id} className="p-3 text-center">
                          <span className="block truncate max-w-[140px]">{bt.title}</span>
                          <span className="text-[10px] text-slate-500 font-mono font-normal">
                            ({bt.maxPoints} pts)
                          </span>
                        </th>
                      ))}
                      <th className="p-3 text-center bg-indigo-50 text-indigo-950 font-black">
                        Combined Total ({bundleTotalMax} pts)
                      </th>
                      <th className="p-3 text-center">Percentage</th>
                      <th className="p-3 text-center">Grade</th>
                      <th className="p-3 text-center">Report Card Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {students.map(student => {
                      const studentSubs = submissions.filter(s => s.studentId === student.id);
                      
                      let studentCombinedScore = 0;
                      const taskScores = bundleTasks.map(bt => {
                        const sub = studentSubs.find(s => s.taskId === bt.id);
                        const score = sub?.correction?.grade ?? (sub ? Math.round(bt.maxPoints * 0.85) : 0);
                        studentCombinedScore += score;
                        return { task: bt, score, hasSub: !!sub };
                      });

                      const studentPct = bundleTotalMax > 0 
                        ? Math.round((studentCombinedScore / bundleTotalMax) * 100) 
                        : 0;

                      const studentGrade = 
                        studentPct >= 90 ? 'A+' :
                        studentPct >= 80 ? 'A' :
                        studentPct >= 70 ? 'B+' :
                        studentPct >= 60 ? 'B' : 'C';

                      return (
                        <tr key={student.id} className="hover:bg-slate-50 transition">
                          <td className="p-3 font-mono text-slate-500 font-bold">{student.rollNo}</td>
                          <td className="p-3 font-bold text-slate-900">{student.name}</td>
                          {taskScores.map((ts, i) => (
                            <td key={i} className="p-3 text-center font-mono">
                              {ts.hasSub ? (
                                <span className="font-bold text-slate-800">
                                  {ts.score} / {ts.task.maxPoints}
                                </span>
                              ) : (
                                <span className="text-slate-400 italic text-[11px]">Pending</span>
                              )}
                            </td>
                          ))}
                          <td className="p-3 text-center font-mono font-black text-indigo-700 bg-indigo-50/50">
                            {studentCombinedScore} / {bundleTotalMax}
                          </td>
                          <td className="p-3 text-center font-mono font-bold text-slate-800">
                            {studentPct}%
                          </td>
                          <td className="p-3 text-center">
                            <span className="font-bold px-2 py-0.5 rounded text-[11px] bg-emerald-100 text-emerald-800">
                              {studentGrade}
                            </span>
                          </td>
                          <td className="p-3 text-center">
                            {onOpenReportCardForStudent && (
                              <button
                                type="button"
                                onClick={() => {
                                  onOpenReportCardForStudent(student.id);
                                  onClose();
                                }}
                                className="text-xs font-bold text-indigo-600 hover:text-indigo-800 hover:underline cursor-pointer"
                              >
                                View / Issue Report Card
                              </button>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="border-t border-slate-200 bg-white px-6 py-3 flex items-center justify-between shrink-0">
          <span className="text-xs text-slate-500 font-medium">
            Interconnected marks update automatically whenever student tasks are evaluated.
          </span>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs font-bold text-slate-700 hover:bg-slate-100 cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
