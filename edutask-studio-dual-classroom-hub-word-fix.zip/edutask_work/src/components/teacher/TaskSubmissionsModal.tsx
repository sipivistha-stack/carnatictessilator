import React, { useState } from 'react';
import { 
  Task, 
  Submission, 
  StudentProfile, 
  TeacherCorrection,
  StudentTier
} from '../../types';
import { generateStudentSubmissionsForTask } from '../../services/aiStudentSimulator';
import { 
  X, 
  Search, 
  Edit3, 
  CheckCircle, 
  Clock, 
  Sparkles, 
  FileCheck, 
  Award, 
  AlertCircle,
  Code2,
  Music,
  FileText,
  BarChart2,
  RefreshCw,
  Layers,
  Users
} from 'lucide-react';

interface TaskSubmissionsModalProps {
  task: Task;
  submissions: Submission[];
  students: StudentProfile[];
  onClose: () => void;
  onSelectSubmissionForEval: (sub: Submission) => void;
  onSubmissionsUpdated?: () => void;
}

export const TaskSubmissionsModal: React.FC<TaskSubmissionsModalProps> = ({
  task,
  submissions,
  students,
  onClose,
  onSelectSubmissionForEval,
  onSubmissionsUpdated,
}) => {
  const [filterTier, setFilterTier] = useState<'all' | 'bright' | 'average' | 'failing' | 'submitted' | 'evaluated'>('all');
  const [search, setSearch] = useState<string>('');
  const [isGenerating, setIsGenerating] = useState<boolean>(false);

  // Get submissions specifically for this task
  const taskSubmissions = submissions.filter(s => s.taskId === task.id);

  // Map each student to their submission if present
  const studentRows = students.map(student => {
    const sub = taskSubmissions.find(s => s.studentId === student.id);
    return {
      student,
      submission: sub,
      isSubmitted: !!sub,
      isEvaluated: sub?.status === 'returned' || sub?.status === 'evaluated',
      score: sub?.correction?.grade,
      letterGrade: sub?.correction?.letterGrade,
    };
  });

  // Filter
  const filteredRows = studentRows.filter(row => {
    if (filterTier === 'bright' && row.student.tier !== 'bright') return false;
    if (filterTier === 'average' && row.student.tier !== 'average') return false;
    if (filterTier === 'failing' && row.student.tier !== 'failing') return false;
    if (filterTier === 'submitted' && !row.isSubmitted) return false;
    if (filterTier === 'evaluated' && !row.isEvaluated) return false;
    if (search) {
      const matchName = row.student.name.toLowerCase().includes(search.toLowerCase());
      const matchRoll = row.student.rollNo.toLowerCase().includes(search.toLowerCase());
      if (!matchName && !matchRoll) return false;
    }
    return true;
  });

  const submittedCount = studentRows.filter(r => r.isSubmitted).length;
  const evaluatedCount = studentRows.filter(r => r.isEvaluated).length;

  const handleSimulateAll = () => {
    setIsGenerating(true);
    setTimeout(() => {
      generateStudentSubmissionsForTask(task, false);
      setIsGenerating(false);
      if (onSubmissionsUpdated) onSubmissionsUpdated();
    }, 400);
  };

  const getTierBadge = (tier: StudentTier) => {
    switch (tier) {
      case 'bright':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-emerald-100 text-emerald-800 border border-emerald-300">
            🌟 Bright (4)
          </span>
        );
      case 'average':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-blue-100 text-blue-800 border border-blue-300">
            ⚖️ Average (3)
          </span>
        );
      case 'failing':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-rose-100 text-rose-800 border border-rose-300">
            ⚠️ Failing (8)
          </span>
        );
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-950/80 backdrop-blur-xs overflow-y-auto">
      <div className="relative w-full max-w-6xl rounded-3xl bg-white shadow-2xl border border-slate-200 overflow-hidden my-4 flex flex-col max-h-[92vh]">
        {/* Modal Top Header */}
        <div className="flex items-center justify-between border-b border-slate-200 bg-slate-50 px-6 py-4">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-indigo-600 text-white flex items-center justify-center font-bold shadow-xs">
              {task.type === 'carnatic_music' ? <Music className="w-5 h-5" /> : task.type === 'coding' ? <Code2 className="w-5 h-5" /> : <FileText className="w-5 h-5" />}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-indigo-100 text-indigo-800">
                  {task.category.replace('_', ' ')}
                </span>
                <span className="text-xs text-slate-500 font-mono">Max: {task.maxPoints} pts</span>
                <span className="text-xs text-slate-500">· {students.length} Enrolled Indian Students</span>
              </div>
              <h3 className="text-lg font-black text-slate-900 mt-0.5">{task.title}</h3>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleSimulateAll}
              disabled={isGenerating}
              className="flex items-center gap-1.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white font-bold px-4 py-2 rounded-xl text-xs shadow-xs transition active:scale-95 disabled:opacity-50 cursor-pointer"
              title="Automatically generates realistic submissions according to 4 Bright, 3 Average, and 8 Failing student tiers"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>{isGenerating ? 'Simulating AI...' : 'Auto-Submit AI Class Submissions'}</span>
            </button>

            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-200 transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Stats Banner */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 sm:px-6 bg-slate-100/60 border-b border-slate-200 text-xs">
          <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
            <span className="text-slate-500 font-bold block text-[11px]">Class Submissions</span>
            <p className="text-lg font-black text-slate-900 mt-0.5">
              {submittedCount} / {students.length} <span className="text-xs font-normal text-slate-500">({Math.round((submittedCount/students.length)*100)}%)</span>
            </p>
          </div>
          <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
            <span className="text-slate-500 font-bold block text-[11px]">Evaluated & Graded</span>
            <p className="text-lg font-black text-emerald-700 mt-0.5">
              {evaluatedCount} <span className="text-xs font-normal text-slate-500">graded</span>
            </p>
          </div>
          <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
            <span className="text-slate-500 font-bold block text-[11px]">Student Composition</span>
            <p className="text-xs font-semibold text-slate-700 mt-1">
              4 Bright · 3 Average · 8 Failing
            </p>
          </div>
          <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
            <span className="text-slate-500 font-bold block text-[11px]">Task Type</span>
            <p className="text-sm font-bold text-indigo-700 mt-0.5 uppercase tracking-wide">
              {task.type}
            </p>
          </div>
        </div>

        {/* Filters & Search Toolbar */}
        <div className="p-4 sm:px-6 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3 bg-white">
          <div className="flex flex-wrap items-center gap-1.5 text-xs">
            <span className="font-bold text-slate-500 mr-1">Roster Filter:</span>
            {[
              { id: 'all', label: `All Students (${studentRows.length})` },
              { id: 'submitted', label: `Submitted (${submittedCount})` },
              { id: 'evaluated', label: `Evaluated (${evaluatedCount})` },
              { id: 'bright', label: '🌟 Bright (4)' },
              { id: 'average', label: '⚖️ Average (3)' },
              { id: 'failing', label: '⚠️ Failing (8)' },
            ].map(tab => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setFilterTier(tab.id as any)}
                className={`px-3 py-1.5 rounded-lg font-bold transition cursor-pointer ${
                  filterTier === tab.id
                    ? 'bg-slate-900 text-white shadow-2xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search student name or roll..."
              className="pl-8 pr-3 py-1.5 rounded-xl border border-slate-300 text-xs w-56 focus:outline-hidden focus:border-indigo-500"
            />
          </div>
        </div>

        {/* Organized Submissions Table */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-slate-50/50">
          <div className="rounded-2xl border border-slate-200 bg-white overflow-hidden shadow-xs">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-100/80 border-b border-slate-200 text-slate-600 font-bold uppercase tracking-wider text-[10px]">
                  <th className="p-3.5 pl-5">Student Details</th>
                  <th className="p-3.5">Tier Category</th>
                  <th className="p-3.5">Submission Details</th>
                  <th className="p-3.5">Score & Grade</th>
                  <th className="p-3.5 pr-5 text-right">Faculty Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredRows.map(row => {
                  const sub = row.submission;
                  return (
                    <tr key={row.student.id} className="hover:bg-indigo-50/30 transition">
                      {/* Student Info */}
                      <td className="p-3.5 pl-5">
                        <div className="flex items-center gap-3">
                          <div
                            className="w-9 h-9 rounded-xl flex items-center justify-center text-white font-bold text-xs shadow-xs"
                            style={{ backgroundColor: row.student.avatarColor || '#3b82f6' }}
                          >
                            {row.student.name.slice(0, 2).toUpperCase()}
                          </div>
                          <div>
                            <span className="font-bold text-slate-900 block">{row.student.name}</span>
                            <span className="text-[11px] text-slate-500 font-mono">
                              Roll: {row.student.rollNo} · {row.student.attendancePercentage || 96}% Att.
                            </span>
                          </div>
                        </div>
                      </td>

                      {/* Tier Badge */}
                      <td className="p-3.5">
                        {getTierBadge(row.student.tier)}
                      </td>

                      {/* Submission Status & Preview */}
                      <td className="p-3.5">
                        {sub ? (
                          <div className="space-y-0.5">
                            <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                              <CheckCircle className="w-3 h-3 text-emerald-600" />
                              Submitted {new Date(sub.submittedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </span>
                            <p className="text-[11px] text-slate-600 line-clamp-1 mt-0.5">
                              {sub.payload.textResponse || sub.payload.docTitle || sub.payload.carnaticRaga || (sub.payload.code ? `${sub.payload.codeLanguage} Solution` : 'Response Attached')}
                            </p>
                            {sub.payload.matplotlibPlotUrl && (
                              <span className="text-[10px] text-purple-600 font-bold block">
                                • Matplotlib Graphic Included
                              </span>
                            )}
                          </div>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
                            <Clock className="w-3 h-3" />
                            Pending Submission
                          </span>
                        )}
                      </td>

                      {/* Score & Grade */}
                      <td className="p-3.5 font-mono">
                        {row.isEvaluated ? (
                          <div>
                            <span className="text-sm font-black text-indigo-700">
                              {row.score} / {task.maxPoints} pts
                            </span>
                            <span className="text-[11px] font-bold text-emerald-700 block">
                              Grade {row.letterGrade} ({Math.round(((row.score || 0) / task.maxPoints) * 100)}%)
                            </span>
                          </div>
                        ) : sub ? (
                          <span className="text-amber-700 bg-amber-50 px-2 py-0.5 rounded border border-amber-200 text-[11px] font-bold">
                            Needs Grading
                          </span>
                        ) : (
                          <span className="text-slate-400 text-xs">—</span>
                        )}
                      </td>

                      {/* Actions */}
                      <td className="p-3.5 pr-5 text-right">
                        {sub ? (
                          <button
                            type="button"
                            onClick={() => {
                              onSelectSubmissionForEval(sub);
                            }}
                            className="inline-flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs px-3.5 py-1.5 rounded-xl shadow-xs transition active:scale-95 cursor-pointer"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                            <span>{row.isEvaluated ? 'Re-Evaluate with Pen' : 'Grade with Pen'}</span>
                          </button>
                        ) : (
                          <span className="text-[11px] text-slate-400 italic">Awaiting work</span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-between border-t border-slate-200 bg-white px-6 py-4">
          <span className="text-xs text-slate-500 font-medium">
            Showing {filteredRows.length} of {students.length} students enrolled in this classroom.
          </span>
          <button
            type="button"
            onClick={onClose}
            className="rounded-xl border border-slate-300 bg-white px-5 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
          >
            Close Roster
          </button>
        </div>
      </div>
    </div>
  );
};
