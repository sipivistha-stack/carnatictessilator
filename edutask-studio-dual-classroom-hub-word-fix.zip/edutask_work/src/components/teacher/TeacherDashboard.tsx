import React, { useState } from 'react';
import { 
  Task, 
  Submission, 
  StudentProfile, 
  TeacherCorrection, 
  TaskCategory, 
  TaskType,
  ClassGroup,
  InterconnectedTaskBundle 
} from '../../types';
import { TaskCreateModal } from './TaskCreateModal';
import { EvaluationModal } from './EvaluationModal';
import { ReportCardModal } from './ReportCardModal';
import { InterconnectedTasksModal } from './InterconnectedTasksModal';
import { ClassManagementModal } from './ClassManagementModal';
import { CarnaticToolsManagerModal } from './CarnaticToolsManagerModal';
import { TaskSubmissionsModal } from './TaskSubmissionsModal';
import { StudentPerformanceModal } from './StudentPerformanceModal';
import { AttendanceManagerModal } from './AttendanceManagerModal';
import { AnnouncementManagerModal } from './AnnouncementManagerModal';
import { generateStudentSubmissionsForTask } from '../../services/aiStudentSimulator';
import { 
  getClasses, 
  getTaskBundles, 
  getCurrentClass, 
  setCurrentClass,
  getStudentsRoster,
  getAnnouncements,
  getAttendanceSessions
} from '../../data/storage';
import { 
  Plus, 
  Play, 
  Pause, 
  Trash2, 
  FileCheck, 
  Clock, 
  Users, 
  Search, 
  Filter,
  CheckCircle,
  AlertCircle,
  Eye,
  Layers,
  Sparkles,
  BookOpen,
  Music,
  Keyboard,
  Link2,
  Award,
  School,
  FileText,
  Edit3,
  Calculator,
  BarChart3,
  Radio,
  UserCheck,
  Megaphone,
  ShieldCheck,
  AlertTriangle,
  Pin
} from 'lucide-react';

interface TeacherDashboardProps {
  tasks: Task[];
  submissions: Submission[];
  students: StudentProfile[];
  onSaveTask: (task: Task) => void;
  onUpdateTaskStatus: (taskId: string, status: 'active' | 'stopped') => void;
  onDeleteTask: (taskId: string) => void;
  onSaveEvaluation: (submissionId: string, correction: TeacherCorrection, status: 'evaluated' | 'returned') => void;
  onSeedStarters: () => void;
  onClearData: () => void;
  onRefreshData?: () => void;
}

export const TeacherDashboard: React.FC<TeacherDashboardProps> = ({
  tasks,
  submissions,
  students,
  onSaveTask,
  onUpdateTaskStatus,
  onDeleteTask,
  onSaveEvaluation,
  onSeedStarters,
  onClearData,
  onRefreshData,
}) => {
  const [activeTab, setActiveTab] = useState<'tasks' | 'submissions' | 'bundles' | 'roster'>('tasks');
  
  // Modals state
  const [isCreateModalOpen, setIsCreateModalOpen] = useState<boolean>(false);
  const [isReportCardModalOpen, setIsReportCardModalOpen] = useState<boolean>(false);
  const [isInterconnectedModalOpen, setIsInterconnectedModalOpen] = useState<boolean>(false);
  const [isClassModalOpen, setIsClassModalOpen] = useState<boolean>(false);
  const [isCarnaticToolsModalOpen, setIsCarnaticToolsModalOpen] = useState<boolean>(false);
  const [isStudentPerformanceModalOpen, setIsStudentPerformanceModalOpen] = useState<boolean>(false);
  const [isAttendanceModalOpen, setIsAttendanceModalOpen] = useState<boolean>(false);
  const [isAnnouncementModalOpen, setIsAnnouncementModalOpen] = useState<boolean>(false);
  const [selectedTaskForSubmissions, setSelectedTaskForSubmissions] = useState<Task | null>(null);
  const [selectedStudentForPerformance, setSelectedStudentForPerformance] = useState<StudentProfile | null>(null);
  const [selectedSubmissionForEval, setSelectedSubmissionForEval] = useState<Submission | null>(null);

  // Classes & Bundles
  const [currentClass, setCurrentClassState] = useState<ClassGroup>(getCurrentClass());
  const classes = getClasses();
  const bundles = getTaskBundles();
  const announcements = getAnnouncements(currentClass.id);
  const barredCount = students.filter(s => (s.attendancePercentage ?? 85) < 75).length;
  const eligibleCount = students.length - barredCount;

  // Filters
  const [taskFilterCategory, setTaskFilterCategory] = useState<'all' | 'examination' | 'assignment' | 'temporary_task'>('all');
  const [submissionFilterStatus, setSubmissionFilterStatus] = useState<'all' | 'submitted' | 'returned'>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Stats
  const examCount = tasks.filter(t => t.category === 'examination').length;
  const activeTasksCount = tasks.filter(t => t.status === 'active').length;
  const pendingEvaluationCount = submissions.filter(s => s.status === 'submitted').length;
  const returnedCount = submissions.filter(s => s.status === 'returned').length;

  const filteredTasks = tasks.filter(t => {
    if (taskFilterCategory !== 'all' && t.category !== taskFilterCategory) return false;
    if (searchQuery && !t.title.toLowerCase().includes(searchQuery.toLowerCase())) return false;
    return true;
  });

  const filteredSubmissions = submissions.filter(s => {
    if (submissionFilterStatus !== 'all' && s.status !== submissionFilterStatus) return false;
    if (searchQuery) {
      const matchName = s.studentName.toLowerCase().includes(searchQuery.toLowerCase());
      const matchTitle = s.taskTitle.toLowerCase().includes(searchQuery.toLowerCase());
      if (!matchName && !matchTitle) return false;
    }
    return true;
  });

  const handleClassChange = (cls: ClassGroup) => {
    setCurrentClassState(cls);
    setCurrentClass(cls);
    if (onRefreshData) onRefreshData();
  };

  return (
    <div className="space-y-6">
      {/* Top Banner & Faculty Control Room */}
      <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-indigo-700 bg-indigo-50 px-2.5 py-0.5 rounded-full">
                Lead Faculty Control Room
              </span>
              <span className="text-xs text-slate-500">· Classical Fine Arts, Carnatic Sangeeth & Academics</span>
            </div>
            <h1 className="text-2xl font-black text-slate-900 mt-1">Teacher Dashboard</h1>
            <p className="text-xs text-slate-500 mt-0.5 max-w-3xl">
              Conduct examinations, interconnect multi-part tasks (e.g. 40 Marks Theory + 10 Marks Viva), evaluate with multi-color visual pen sheets, and publish official report cards to 15 enrolled students.
            </p>
          </div>

          {/* Quick Action Buttons */}
          <div className="flex flex-wrap items-center gap-2">
            {/* Active Class Selector */}
            <button
              type="button"
              onClick={() => setIsClassModalOpen(true)}
              className="flex items-center gap-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold px-3 py-2 rounded-xl text-xs border border-slate-300 shadow-2xs cursor-pointer"
              title="Switch or manage classes and 15 enrolled Indian students"
            >
              <School className="w-3.5 h-3.5 text-indigo-600" />
              <span>{currentClass.name.split('-')[0]}</span>
            </button>

            {/* Interconnect Tasks Button */}
            <button
              type="button"
              onClick={() => setIsInterconnectedModalOpen(true)}
              className="flex items-center gap-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-900 font-bold px-3.5 py-2 rounded-xl text-xs border border-indigo-200 shadow-2xs cursor-pointer"
            >
              <Link2 className="w-3.5 h-3.5 text-indigo-600" />
              <span>Interconnect Tasks ({bundles.length})</span>
            </button>

            {/* Carnatic Music Tools Suite Button */}
            <button
              type="button"
              onClick={() => setIsCarnaticToolsModalOpen(true)}
              className="flex items-center gap-1.5 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white font-bold px-3.5 py-2 rounded-xl text-xs shadow-xs transition active:scale-95 cursor-pointer"
              title="Explore, test, and view all Carnatic music tools (Tanpura, Tala Metronome, Swara Transcriber, 72 Melakartas)"
            >
              <Music className="w-3.5 h-3.5" />
              <span>Carnatic Tools Suite</span>
            </button>

            {/* Performance & Taking Average Analytics Button */}
            <button
              type="button"
              onClick={() => {
                setSelectedStudentForPerformance(students[0] || null);
                setIsStudentPerformanceModalOpen(true);
              }}
              className="flex items-center gap-1.5 bg-purple-50 hover:bg-purple-100 text-purple-900 font-bold px-3.5 py-2 rounded-xl text-xs border border-purple-200 shadow-2xs cursor-pointer"
              title="View student performance, score trends, and detailed exam-by-exam average calculation breakdown"
            >
              <BarChart3 className="w-3.5 h-3.5 text-purple-600" />
              <span>Performance & Average</span>
            </button>

            {/* Issue Report Card Button */}
            <button
              type="button"
              onClick={() => setIsReportCardModalOpen(true)}
              className="flex items-center gap-1.5 bg-amber-50 hover:bg-amber-100 text-amber-900 font-bold px-3.5 py-2 rounded-xl text-xs border border-amber-300 shadow-2xs cursor-pointer"
            >
              <Award className="w-3.5 h-3.5 text-amber-600" />
              <span>Issue Report Cards</span>
            </button>

            {/* Mark Attendance Button */}
            <button
              type="button"
              onClick={() => setIsAttendanceModalOpen(true)}
              className="flex items-center gap-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-900 font-bold px-3.5 py-2 rounded-xl text-xs border border-emerald-300 shadow-2xs cursor-pointer"
              title="Mark student attendance and check 75% exam eligibility"
            >
              <UserCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>Mark Attendance</span>
              {barredCount > 0 ? (
                <span className="bg-rose-600 text-white text-[10px] font-mono px-1.5 py-0.2 rounded-full font-bold">
                  {barredCount} Barred
                </span>
              ) : (
                <span className="bg-emerald-600 text-white text-[10px] font-mono px-1.5 py-0.2 rounded-full font-bold">
                  All Eligible
                </span>
              )}
            </button>

            {/* Post Announcements Button */}
            <button
              type="button"
              onClick={() => setIsAnnouncementModalOpen(true)}
              className="flex items-center gap-1.5 bg-amber-50 hover:bg-amber-100 text-amber-900 font-bold px-3.5 py-2 rounded-xl text-xs border border-amber-300 shadow-2xs cursor-pointer"
              title="Post announcements, examination guidelines, and word doc templates"
            >
              <Megaphone className="w-3.5 h-3.5 text-amber-600" />
              <span>Announcements ({announcements.length})</span>
            </button>

            {/* Post New Task Button */}
            <button
              type="button"
              onClick={() => setIsCreateModalOpen(true)}
              className="flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold px-4 py-2 rounded-xl text-xs shadow-xs transition active:scale-95 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>+ Post Task / Exam</span>
            </button>
          </div>
        </div>

        {/* Faculty Broadcast / Active Announcement Strip */}
        {announcements.length > 0 && (
          <div className="mt-4 p-3 bg-amber-50/80 rounded-xl border border-amber-200 flex flex-wrap items-center justify-between gap-2 text-xs">
            <div className="flex items-center gap-2">
              <Megaphone className="w-4 h-4 text-amber-600 shrink-0" />
              <span className="font-bold text-amber-950">Active Announcement:</span>
              <span className="text-amber-900 font-medium line-clamp-1">{announcements[0].title}</span>
            </div>
            <button
              type="button"
              onClick={() => setIsAnnouncementModalOpen(true)}
              className="text-amber-800 hover:text-amber-950 font-bold text-[11px] underline cursor-pointer"
            >
              Manage / Post Circulars ({announcements.length}) →
            </button>
          </div>
        )}

        {/* Dashboard Stat Badges */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-5 border-t border-slate-100">
          <div className="p-3 bg-indigo-50/70 rounded-xl border border-indigo-100">
            <span className="text-[11px] font-bold uppercase tracking-wider text-indigo-700">Examinations Conducted</span>
            <p className="text-xl font-black text-indigo-950 mt-0.5">{examCount}</p>
          </div>
          <div className="p-3 bg-emerald-50/70 rounded-xl border border-emerald-100">
            <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-700">Enrolled Students</span>
            <p className="text-xl font-black text-emerald-950 mt-0.5">{students.length} Indian Students</p>
          </div>
          <div className="p-3 bg-amber-50/70 rounded-xl border border-amber-100">
            <span className="text-[11px] font-bold uppercase tracking-wider text-amber-700">Pending Evaluation</span>
            <p className="text-xl font-black text-amber-950 mt-0.5">{pendingEvaluationCount}</p>
          </div>
          <div className="p-3 bg-purple-50/70 rounded-xl border border-purple-100">
            <span className="text-[11px] font-bold uppercase tracking-wider text-purple-700">Evaluated & Returned</span>
            <p className="text-xl font-black text-purple-950 mt-0.5">{returnedCount}</p>
          </div>
        </div>
      </div>

      {/* Primary Section Tabs */}
      <div className="flex items-center justify-between border-b border-slate-200 pb-1">
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setActiveTab('tasks')}
            className={`px-4 py-2 rounded-xl font-bold text-xs transition cursor-pointer flex items-center gap-2 ${
              activeTab === 'tasks' ? 'bg-indigo-600 text-white shadow-xs' : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>Task & Exam Management ({tasks.length})</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('submissions')}
            className={`px-4 py-2 rounded-xl font-bold text-xs transition cursor-pointer flex items-center gap-2 ${
              activeTab === 'submissions' ? 'bg-indigo-600 text-white shadow-xs' : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <FileCheck className="w-3.5 h-3.5" />
            <span>Submissions & Grading ({submissions.length})</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('bundles')}
            className={`px-4 py-2 rounded-xl font-bold text-xs transition cursor-pointer flex items-center gap-2 ${
              activeTab === 'bundles' ? 'bg-indigo-600 text-white shadow-xs' : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <Link2 className="w-3.5 h-3.5" />
            <span>Interconnected Bundles ({bundles.length})</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('roster')}
            className={`px-4 py-2 rounded-xl font-bold text-xs transition cursor-pointer flex items-center gap-2 ${
              activeTab === 'roster' ? 'bg-indigo-600 text-white shadow-xs' : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>Class Roster ({students.length} Students)</span>
          </button>
        </div>

        {/* Preset seeds */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onSeedStarters}
            className="text-xs text-indigo-700 bg-indigo-50 border border-indigo-200 px-3 py-1 rounded-lg font-bold hover:bg-indigo-100 cursor-pointer"
          >
            Load Carnatic Starter Pack
          </button>
        </div>
      </div>

      {/* TAB 1: TASK & EXAM MANAGEMENT */}
      {activeTab === 'tasks' && (
        <div className="space-y-4">
          {/* Sub-Filter Bar */}
          <div className="flex flex-wrap items-center justify-between gap-3 bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-slate-500">Filter Group:</span>
              {(['all', 'examination', 'assignment', 'temporary_task'] as const).map(cat => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setTaskFilterCategory(cat)}
                  className={`px-3 py-1 rounded-lg text-xs font-bold capitalize transition cursor-pointer ${
                    taskFilterCategory === cat ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {cat === 'all' ? 'All Activities' : cat === 'temporary_task' ? 'Temporary Tasks' : cat}
                </button>
              ))}
            </div>

            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Search tasks..."
                className="pl-8 pr-3 py-1 rounded-lg border border-slate-300 text-xs w-48 focus:outline-hidden focus:border-indigo-500"
              />
            </div>
          </div>

          {/* Tasks Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredTasks.map(task => {
              const taskSubCount = submissions.filter(s => s.taskId === task.id).length;
              const isActive = task.status === 'active';

              return (
                <div
                  key={task.id}
                  className={`p-5 rounded-2xl border transition flex flex-col justify-between ${
                    isActive ? 'bg-white border-slate-200 shadow-2xs hover:shadow-xs' : 'bg-slate-50 border-slate-200 opacity-75'
                  }`}
                >
                  <div>
                    {/* Header */}
                    <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-100 text-xs">
                      <div className="flex items-center gap-1.5">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                          task.category === 'examination' ? 'bg-indigo-100 text-indigo-800' :
                          task.category === 'assignment' ? 'bg-blue-100 text-blue-800' :
                          'bg-amber-100 text-amber-800'
                        }`}>
                          {task.category.replace('_', ' ')}
                        </span>
                        <span className="text-[10px] text-slate-400 font-mono">
                          {task.type}
                        </span>
                      </div>

                      <span className="font-mono font-black text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded text-xs">
                        {task.maxPoints} pts
                      </span>
                    </div>

                    <h4 className="text-sm font-bold text-slate-900 line-clamp-2">{task.title}</h4>
                    <p className="text-xs text-slate-500 mt-1 line-clamp-2">{task.description}</p>

                    {/* Carnatic Raga & Tala info */}
                    {task.carnaticConfig && (
                      <div className="mt-2.5 bg-amber-50/70 p-2 rounded-lg border border-amber-200 text-[11px] text-amber-900 space-y-0.5">
                        <p><strong>Raga:</strong> {task.carnaticConfig.raga}</p>
                        <p><strong>Tala:</strong> {task.carnaticConfig.tala}</p>
                      </div>
                    )}
                  </div>

                  {/* Footer Controls */}
                  <div className="pt-4 mt-4 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2 text-xs">
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => setSelectedTaskForSubmissions(task)}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-900 border border-indigo-200 font-bold text-xs transition cursor-pointer shadow-2xs"
                        title="View organized student submissions roster for this specific task"
                      >
                        <Users className="w-3.5 h-3.5 text-indigo-600" />
                        <span>Submissions ({taskSubCount}/15)</span>
                      </button>

                      {task.linkedBundleId && (
                        <span className="text-[10px] font-bold text-indigo-600 bg-indigo-50 px-1.5 py-0.5 rounded border border-indigo-200">
                          Linked
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-1.5">
                      {/* Start / Stop Toggle */}
                      <button
                        type="button"
                        onClick={() => onUpdateTaskStatus(task.id, isActive ? 'stopped' : 'active')}
                        className={`flex items-center gap-1 px-2.5 py-1 rounded-lg font-bold text-[11px] cursor-pointer ${
                          isActive ? 'bg-amber-50 text-amber-800 border border-amber-200 hover:bg-amber-100' : 'bg-emerald-50 text-emerald-800 border border-emerald-200 hover:bg-emerald-100'
                        }`}
                        title={isActive ? 'Stop task (hide from student dashboard)' : 'Start task (show to students)'}
                      >
                        {isActive ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
                        <span>{isActive ? 'Stop' : 'Start'}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => onDeleteTask(task.id)}
                        className="text-slate-400 hover:text-rose-600 p-1 cursor-pointer"
                        title="Delete task"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 2: SUBMISSIONS & GRADING */}
      {activeTab === 'submissions' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="p-4 border-b border-slate-200 bg-slate-50 flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2">
              <span className="font-bold text-slate-600">Filter Submissions:</span>
              {(['all', 'submitted', 'returned'] as const).map(st => (
                <button
                  key={st}
                  type="button"
                  onClick={() => setSubmissionFilterStatus(st)}
                  className={`px-3 py-1 rounded-lg font-bold capitalize cursor-pointer ${
                    submissionFilterStatus === st ? 'bg-indigo-600 text-white' : 'bg-white border text-slate-700'
                  }`}
                >
                  {st === 'submitted' ? 'Needs Grading' : st === 'returned' ? 'Evaluated & Returned' : 'All'}
                </button>
              ))}
            </div>
            <span className="text-slate-500 font-medium">Showing {filteredSubmissions.length} submissions</span>
          </div>

          <div className="divide-y divide-slate-200">
            {filteredSubmissions.map(sub => {
              const correspondingTask = tasks.find(t => t.id === sub.taskId);
              const maxPoints = correspondingTask?.maxPoints || sub.correction?.maxPoints || 100;
              const isEvaluated = sub.status === 'returned' || sub.status === 'evaluated';

              return (
                <div key={sub.id} className="p-4 sm:p-5 flex flex-wrap items-center justify-between gap-4 hover:bg-slate-50 transition">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-900 text-sm">{sub.studentName}</span>
                      <span className="text-xs text-slate-500 font-mono">({sub.taskCategory.replace('_', ' ')})</span>
                      <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-slate-100 text-slate-700">
                        {sub.taskType}
                      </span>
                    </div>

                    <h5 className="text-xs font-semibold text-indigo-900">{sub.taskTitle}</h5>
                    <p className="text-[11px] text-slate-400">
                      Submitted on {new Date(sub.submittedAt).toLocaleString()}
                    </p>
                  </div>

                  <div className="flex items-center gap-4">
                    {isEvaluated ? (
                      <div className="text-right font-mono">
                        <span className="text-sm font-black text-indigo-700 block">
                          {sub.correction?.grade} / {maxPoints} pts
                        </span>
                        <span className="text-[11px] font-bold text-emerald-700">
                          Grade {sub.correction?.letterGrade} (Returned)
                        </span>
                      </div>
                    ) : (
                      <span className="text-xs font-bold text-amber-700 bg-amber-50 px-2.5 py-1 rounded border border-amber-200">
                        Needs Evaluation
                      </span>
                    )}

                    <button
                      type="button"
                      onClick={() => setSelectedSubmissionForEval(sub)}
                      className="flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs px-4 py-2 rounded-xl shadow-xs transition active:scale-95 cursor-pointer"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                      <span>{isEvaluated ? 'Re-Evaluate with Pen' : 'Grade with Pen'}</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 3: INTERCONNECTED BUNDLES */}
      {activeTab === 'bundles' && (
        <div className="space-y-4">
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-3">
            <div>
              <h3 className="text-base font-bold text-slate-900">Interconnected Assessment Bundles</h3>
              <p className="text-xs text-slate-500">
                Connected tasks (e.g. 40 Marks Theory Exam + 10 Marks Viva) automatically calculate cumulative totals.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setIsInterconnectedModalOpen(true)}
              className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs px-4 py-2 rounded-xl shadow-xs cursor-pointer"
            >
              Open Interconnection Manager & Matrix
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {bundles.map(b => (
              <div key={b.id} className="p-5 rounded-2xl border border-indigo-200 bg-indigo-50/40 space-y-3">
                <div className="flex items-center justify-between pb-2 border-b border-indigo-200">
                  <h4 className="font-bold text-sm text-indigo-950">{b.title}</h4>
                  <span className="font-mono font-black text-indigo-700 text-xs bg-white px-2 py-0.5 rounded border border-indigo-200">
                    Total: {b.totalMaxMarks} Marks
                  </span>
                </div>
                <p className="text-xs text-indigo-800">{b.description}</p>
                <div className="text-xs text-slate-600 space-y-1">
                  <strong>Connected Components:</strong>
                  {tasks.filter(t => b.taskIds.includes(t.id)).map(t => (
                    <div key={t.id} className="flex justify-between bg-white/80 p-2 rounded border border-indigo-100">
                      <span>{t.title}</span>
                      <span className="font-mono font-bold text-slate-700">{t.maxPoints} pts</span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 4: CLASS ROSTER (15 INDIAN STUDENTS) */}
      {activeTab === 'roster' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-6 space-y-4">
          <div className="flex flex-wrap items-center justify-between pb-4 border-b border-slate-200 gap-3">
            <div>
              <h3 className="text-base font-bold text-slate-900">{currentClass.name} - Enrolled Roster</h3>
              <p className="text-xs text-slate-500">15 Enrolled Indian Students · Academic Year {currentClass.academicYear}</p>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setIsReportCardModalOpen(true)}
                className="bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs px-4 py-2 rounded-xl shadow-xs cursor-pointer"
              >
                Issue Class Report Cards
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {students.map((student, idx) => {
              const studentSubs = submissions.filter(s => s.studentId === student.id);
              const evaluatedSubs = studentSubs.filter(s => s.status === 'returned' || s.status === 'evaluated');

              return (
                <div key={student.id} className="p-4 rounded-xl border border-slate-200 bg-slate-50/60 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div
                      className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-xs shadow-xs"
                      style={{ backgroundColor: student.avatarColor || '#3b82f6' }}
                    >
                      {student.name.slice(0, 2).toUpperCase()}
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-slate-900">{student.name}</h4>
                      <p className="text-[11px] text-slate-500 font-mono">
                        {student.rollNo} · {student.attendancePercentage || 96}% Attend.
                      </p>
                      <span className="text-[10px] text-emerald-700 font-semibold block mt-0.5">
                        {evaluatedSubs.length} of {tasks.length} evaluated
                      </span>
                    </div>
                  </div>

                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => {
                          setSelectedStudentForPerformance(student);
                          setIsStudentPerformanceModalOpen(true);
                        }}
                        className="text-xs font-bold text-purple-700 bg-purple-50 hover:bg-purple-100 border border-purple-200 px-2.5 py-1.5 rounded-lg cursor-pointer"
                        title="View individual performance and taking average breakdown"
                      >
                        Performance
                      </button>

                      <button
                        type="button"
                        onClick={() => setIsReportCardModalOpen(true)}
                        className="text-xs font-bold text-amber-700 bg-amber-50 hover:bg-amber-100 border border-amber-300 px-2.5 py-1.5 rounded-lg cursor-pointer"
                      >
                        Report Card
                      </button>
                    </div>
                  </div>
                );
              })}
          </div>
        </div>
      )}

      {/* Modals */}
      <TaskCreateModal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        onSaveTask={onSaveTask}
      />

      {/* Carnatic Music Tools Suite Modal */}
      {isCarnaticToolsModalOpen && (
        <CarnaticToolsManagerModal
          tasks={tasks}
          onClose={() => setIsCarnaticToolsModalOpen(false)}
        />
      )}

      {/* Specific Task Submissions Roster Modal */}
      {selectedTaskForSubmissions && (
        <TaskSubmissionsModal
          task={selectedTaskForSubmissions}
          submissions={submissions}
          students={students}
          onClose={() => setSelectedTaskForSubmissions(null)}
          onSelectSubmissionForEval={(sub) => {
            setSelectedSubmissionForEval(sub);
          }}
          onSubmissionsUpdated={() => {
            if (onRefreshData) onRefreshData();
          }}
        />
      )}

      {/* Student Performance & Taking Average Analytics Modal */}
      {isStudentPerformanceModalOpen && (
        <StudentPerformanceModal
          students={students}
          tasks={tasks}
          submissions={submissions}
          bundles={bundles}
          initialStudentId={selectedStudentForPerformance?.id}
          onClose={() => {
            setIsStudentPerformanceModalOpen(false);
            setSelectedStudentForPerformance(null);
          }}
          onOpenReportCardForStudent={() => {
            setIsStudentPerformanceModalOpen(false);
            setIsReportCardModalOpen(true);
          }}
        />
      )}

      {isReportCardModalOpen && (
        <ReportCardModal
          students={students}
          tasks={tasks}
          submissions={submissions}
          currentClass={currentClass}
          onClose={() => setIsReportCardModalOpen(false)}
          onPublished={() => {
            if (onRefreshData) onRefreshData();
          }}
        />
      )}

      {isInterconnectedModalOpen && (
        <InterconnectedTasksModal
          tasks={tasks}
          submissions={submissions}
          students={students}
          currentClass={currentClass}
          bundles={bundles}
          onClose={() => setIsInterconnectedModalOpen(false)}
          onOpenReportCardForStudent={() => setIsReportCardModalOpen(true)}
          onRefreshBundles={() => {
            if (onRefreshData) onRefreshData();
          }}
        />
      )}

      {isAttendanceModalOpen && (
        <AttendanceManagerModal
          onClose={() => setIsAttendanceModalOpen(false)}
          onAttendanceUpdated={() => {
            if (onRefreshData) onRefreshData();
          }}
        />
      )}

      {isAnnouncementModalOpen && (
        <AnnouncementManagerModal
          onClose={() => setIsAnnouncementModalOpen(false)}
          onAnnouncementsUpdated={() => {
            if (onRefreshData) onRefreshData();
          }}
        />
      )}

      {isClassModalOpen && (
        <ClassManagementModal
          currentClass={currentClass}
          classes={classes}
          students={students}
          onClose={() => setIsClassModalOpen(false)}
          onClassChanged={handleClassChange}
          onRosterUpdated={() => {
            if (onRefreshData) onRefreshData();
          }}
        />
      )}

      {selectedSubmissionForEval && (
        <EvaluationModal
          submission={selectedSubmissionForEval}
          task={tasks.find(t => t.id === selectedSubmissionForEval.taskId)}
          onClose={() => setSelectedSubmissionForEval(null)}
          onSaveEvaluation={onSaveEvaluation}
        />
      )}
    </div>
  );
};
