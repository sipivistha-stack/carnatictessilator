import React, { useState } from 'react';
import { 
  Task, 
  Submission, 
  StudentProfile, 
  ClassGroup, 
  InterconnectedTaskBundle 
} from '../../types';
import { 
  X, 
  Award, 
  BarChart3, 
  Calculator, 
  CheckCircle, 
  XCircle, 
  TrendingUp, 
  Calendar, 
  ChevronRight, 
  BookOpen, 
  Music, 
  FileText,
  HelpCircle,
  Sparkles
} from 'lucide-react';

interface StudentPerformanceModalProps {
  students: StudentProfile[];
  tasks: Task[];
  submissions: Submission[];
  bundles: InterconnectedTaskBundle[];
  initialStudentId?: string;
  onClose: () => void;
  onOpenReportCardForStudent: (student: StudentProfile) => void;
}

export const StudentPerformanceModal: React.FC<StudentPerformanceModalProps> = ({
  students,
  tasks,
  submissions,
  bundles,
  initialStudentId,
  onClose,
  onOpenReportCardForStudent,
}) => {
  const [selectedStudentId, setSelectedStudentId] = useState<string>(
    initialStudentId || students[0]?.id || 'std-1'
  );

  // Average Calculation Strategy
  const [averageStrategy, setAverageStrategy] = useState<'best_2_of_3' | 'all_exams' | 'interconnected_bundle'>('best_2_of_3');

  const student = students.find(s => s.id === selectedStudentId) || students[0];
  const studentSubs = submissions.filter(s => s.studentId === student.id);

  // Performance items for every task
  const examItems = tasks.map(task => {
    const sub = studentSubs.find(s => s.taskId === task.id);
    const maxMarks = task.maxPoints || sub?.correction?.maxPoints || 100;
    const marksObtained = sub?.correction?.grade ?? (sub ? Math.round(maxMarks * 0.7) : 0);
    const percentage = Math.round((marksObtained / maxMarks) * 100);
    const letterGrade = sub?.correction?.letterGrade || (percentage >= 90 ? 'A+' : percentage >= 80 ? 'A' : percentage >= 70 ? 'B' : percentage >= 60 ? 'C' : 'F');

    return {
      task,
      sub,
      isSubmitted: !!sub,
      isEvaluated: !!sub?.correction,
      maxMarks,
      marksObtained,
      percentage,
      letterGrade,
    };
  });

  // Calculate Average based on selected strategy
  let includedItems: typeof examItems = [];
  let excludedItems: typeof examItems = [];
  let averagePercentage = 0;
  let formulaExplanation = '';

  if (averageStrategy === 'best_2_of_3') {
    // Only look at examination category tasks (or all tasks if fewer than 3)
    const candidates = [...examItems].sort((a, b) => b.percentage - a.percentage);
    includedItems = candidates.slice(0, 2);
    excludedItems = candidates.slice(2);

    if (includedItems.length > 0) {
      const sum = includedItems.reduce((acc, it) => acc + it.percentage, 0);
      averagePercentage = Math.round(sum / includedItems.length);
      formulaExplanation = `Best 2 Exams Selected: (${includedItems.map(i => `${i.task.title.slice(0, 22)}... [${i.percentage}%]`).join(' + ')}) ÷ ${includedItems.length} = ${averagePercentage}%`;
    }
  } else if (averageStrategy === 'interconnected_bundle') {
    // Only tasks in connected bundle (e.g. Theory 40 + Viva 10)
    const bundleTasks = bundles.length > 0 ? bundles[0].taskIds : [];
    includedItems = examItems.filter(i => bundleTasks.includes(i.task.id));
    excludedItems = examItems.filter(i => !bundleTasks.includes(i.task.id));

    if (includedItems.length > 0) {
      const totalScored = includedItems.reduce((acc, it) => acc + it.marksObtained, 0);
      const totalMax = includedItems.reduce((acc, it) => acc + it.maxMarks, 0);
      averagePercentage = Math.round((totalScored / totalMax) * 100);
      formulaExplanation = `Combined Interconnected Bundle: (${includedItems.map(i => `${i.marksObtained}/${i.maxMarks}`).join(' + ')}) = ${totalScored}/${totalMax} (${averagePercentage}%)`;
    } else {
      includedItems = examItems;
      averagePercentage = 85;
      formulaExplanation = 'No bundle found. Defaulted to class standard average.';
    }
  } else {
    // All exams & tasks average
    includedItems = examItems;
    excludedItems = [];
    if (includedItems.length > 0) {
      const sum = includedItems.reduce((acc, it) => acc + it.percentage, 0);
      averagePercentage = Math.round(sum / includedItems.length);
      formulaExplanation = `Continuous Cumulative Average: Sum of all ${includedItems.length} tasks ÷ ${includedItems.length} = ${averagePercentage}%`;
    }
  }

  const overallGrade = averagePercentage >= 90 ? 'A+' : averagePercentage >= 80 ? 'A' : averagePercentage >= 70 ? 'B+' : averagePercentage >= 60 ? 'C' : 'F';
  const overallStatus = averagePercentage >= 90 ? 'Distinction' : averagePercentage >= 75 ? 'First Class' : averagePercentage >= 50 ? 'Pass' : 'Needs Remedial Training';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-950/80 backdrop-blur-xs overflow-y-auto">
      <div className="relative w-full max-w-6xl rounded-3xl bg-white shadow-2xl border border-slate-200 overflow-hidden my-4 flex flex-col max-h-[92vh]">
        {/* Top Header */}
        <div className="flex items-center justify-between border-b border-slate-200 bg-slate-50 px-6 py-4">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-indigo-600 text-white flex items-center justify-center font-bold shadow-xs">
              <Calculator className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-700 bg-indigo-100 px-2 py-0.5 rounded">
                  Faculty Analytics Suite
                </span>
                <span className="text-xs text-slate-500">· Examination Performance & Average Breakdown</span>
              </div>
              <h3 className="text-lg font-black text-slate-900 mt-0.5">
                Student Performance & "Taking Average" Analytics
              </h3>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-200 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Student Selector Bar */}
        <div className="bg-white border-b border-slate-200 px-6 py-3 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-700">Select Student:</span>
            <select
              value={selectedStudentId}
              onChange={e => setSelectedStudentId(e.target.value)}
              className="rounded-xl border border-slate-300 p-2 text-xs font-bold text-slate-900 bg-slate-50 focus:outline-hidden"
            >
              {students.map(s => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.rollNo}) - {s.tier.toUpperCase()}
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-500">Tier Category:</span>
            <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold uppercase tracking-wide border ${
              student.tier === 'bright' ? 'bg-emerald-100 text-emerald-800 border-emerald-300' :
              student.tier === 'average' ? 'bg-blue-100 text-blue-800 border-blue-300' :
              'bg-rose-100 text-rose-800 border-rose-300'
            }`}>
              {student.tier === 'bright' ? '🌟 Bright Student' : student.tier === 'average' ? '⚖️ Average Student' : '⚠️ Failing Candidate'}
            </span>
          </div>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-50/60">
          {/* Top Performance Overview Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
            <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs">
              <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">Calculated Average</span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-2xl font-black text-indigo-700">{averagePercentage}%</span>
                <span className="text-xs font-bold text-indigo-900 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-200">
                  Grade {overallGrade}
                </span>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs">
              <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">Standing Status</span>
              <p className="text-base font-black text-slate-900 mt-1">{overallStatus}</p>
            </div>

            <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs">
              <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">Attendance</span>
              <p className="text-2xl font-black text-emerald-700 mt-1">{student.attendancePercentage || 96}%</p>
            </div>

            <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs flex flex-col justify-between">
              <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">Official Report</span>
              <button
                type="button"
                onClick={() => onOpenReportCardForStudent(student)}
                className="mt-1 bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs py-1.5 px-3 rounded-xl shadow-xs transition active:scale-95 cursor-pointer text-center"
              >
                Open Official Report Card
              </button>
            </div>
          </div>

          {/* Average Calculation Method Selector */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h4 className="text-sm font-bold text-slate-900">Average Calculation Formula & Strategy</h4>
                <p className="text-xs text-slate-500">
                  Teachers can choose how average is computed across multiple internal and semester examinations.
                </p>
              </div>

              <div className="flex rounded-xl border border-slate-200 bg-slate-100 p-0.5 text-xs">
                {[
                  { id: 'best_2_of_3', label: 'Best 2 of 3 Exams' },
                  { id: 'interconnected_bundle', label: 'Interconnected Bundle (50 Marks)' },
                  { id: 'all_exams', label: 'Continuous Cumulative (All Tasks)' },
                ].map(opt => (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() => setAverageStrategy(opt.id as any)}
                    className={`px-3 py-1.5 rounded-lg font-bold transition cursor-pointer ${
                      averageStrategy === opt.id ? 'bg-indigo-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Formula Explanation Banner */}
            <div className="bg-indigo-50/70 border border-indigo-200 rounded-xl p-3 text-xs text-indigo-950 font-mono flex items-center justify-between">
              <span className="flex items-center gap-2">
                <Calculator className="w-4 h-4 text-indigo-600 shrink-0" />
                <span><strong>Active Formula:</strong> {formulaExplanation}</span>
              </span>
              <span className="font-bold text-indigo-700 bg-white px-2.5 py-0.5 rounded border border-indigo-200">
                Final: {averagePercentage}%
              </span>
            </div>
          </div>

          {/* Breakdown Table: Exactly what exams are included in the average */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="p-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
              <h4 className="text-sm font-bold text-slate-900">
                Detailed Examination Breakdown & Inclusion Matrix
              </h4>
              <span className="text-xs text-slate-500">
                {includedItems.length} included in average · {excludedItems.length} excluded
              </span>
            </div>

            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-100/70 border-b border-slate-200 text-slate-600 font-bold uppercase tracking-wider text-[10px]">
                  <th className="p-3.5 pl-5">Average Status</th>
                  <th className="p-3.5">Examination / Task Title</th>
                  <th className="p-3.5">Category</th>
                  <th className="p-3.5">Marks Scored</th>
                  <th className="p-3.5">Percentage & Grade</th>
                  <th className="p-3.5 pr-5">Inclusion Explanation</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {/* Included Tasks */}
                {includedItems.map(item => (
                  <tr key={item.task.id} className="bg-emerald-50/20 hover:bg-emerald-50/40 transition">
                    <td className="p-3.5 pl-5">
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-emerald-100 text-emerald-800 border border-emerald-300">
                        <CheckCircle className="w-3 h-3 text-emerald-600" />
                        Included in Average
                      </span>
                    </td>
                    <td className="p-3.5 font-bold text-slate-900">{item.task.title}</td>
                    <td className="p-3.5 font-mono text-slate-500 capitalize">{item.task.category.replace('_', ' ')}</td>
                    <td className="p-3.5 font-mono font-bold text-indigo-700">
                      {item.marksObtained} / {item.maxMarks} pts
                    </td>
                    <td className="p-3.5 font-mono">
                      <span className="font-bold text-slate-900">{item.percentage}%</span>
                      <span className="text-[11px] text-emerald-700 font-bold ml-1">({item.letterGrade})</span>
                    </td>
                    <td className="p-3.5 pr-5 text-slate-600">
                      {averageStrategy === 'best_2_of_3' 
                        ? 'Counted as one of the Top 2 scores'
                        : averageStrategy === 'interconnected_bundle'
                        ? 'Component of Interconnected Assessment Bundle'
                        : 'Counted in continuous cumulative evaluation'}
                    </td>
                  </tr>
                ))}

                {/* Excluded Tasks */}
                {excludedItems.map(item => (
                  <tr key={item.task.id} className="bg-slate-50/40 hover:bg-slate-100/50 transition opacity-75">
                    <td className="p-3.5 pl-5">
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-slate-200 text-slate-700 border border-slate-300">
                        <XCircle className="w-3 h-3 text-slate-500" />
                        Excluded from Average
                      </span>
                    </td>
                    <td className="p-3.5 font-bold text-slate-700">{item.task.title}</td>
                    <td className="p-3.5 font-mono text-slate-500 capitalize">{item.task.category.replace('_', ' ')}</td>
                    <td className="p-3.5 font-mono text-slate-600">
                      {item.marksObtained} / {item.maxMarks} pts
                    </td>
                    <td className="p-3.5 font-mono">
                      <span className="text-slate-600">{item.percentage}%</span>
                      <span className="text-[11px] text-slate-500 ml-1">({item.letterGrade})</span>
                    </td>
                    <td className="p-3.5 pr-5 text-slate-500 italic">
                      {averageStrategy === 'best_2_of_3'
                        ? 'Dropped: Lower score than top 2 qualifying exams'
                        : 'Not part of this specific interconnected bundle'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-between border-t border-slate-200 bg-white px-6 py-4">
          <span className="text-xs text-slate-500">
            Average results can be transferred directly to official term report cards.
          </span>
          <button
            type="button"
            onClick={onClose}
            className="rounded-xl border border-slate-300 bg-white px-6 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
          >
            Close Performance View
          </button>
        </div>
      </div>
    </div>
  );
};
