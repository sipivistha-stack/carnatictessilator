/**
 * Storage and Data Store for EduTask Studio
 * Manages Tasks, Submissions, Classes, 15 Indian Students, Bundles, and Report Cards in LocalStorage.
 */

import { 
  Task, 
  Submission, 
  StudentProfile, 
  TeacherCorrection, 
  ClassGroup, 
  InterconnectedTaskBundle, 
  ReportCard,
  Announcement,
  AttendanceSession,
  AttendanceRecord
} from '../types';

const TASKS_KEY = 'edutask_tasks_v2';
const SUBMISSIONS_KEY = 'edutask_submissions_v2';
const CURRENT_STUDENT_KEY = 'edutask_current_student_v2';
const STUDENTS_ROSTER_KEY = 'edutask_students_roster_v2';
const CLASSES_KEY = 'edutask_classes_v2';
const CURRENT_CLASS_KEY = 'edutask_current_class_v2';
const BUNDLES_KEY = 'edutask_bundles_v2';
const REPORT_CARDS_KEY = 'edutask_report_cards_v2';
const ANNOUNCEMENTS_KEY = 'edutask_announcements_v2';
const ATTENDANCE_SESSIONS_KEY = 'edutask_attendance_sessions_v2';

export const DEFAULT_CLASSES: ClassGroup[] = [
  {
    id: 'cls-10-carnatic',
    name: 'Class 10 - Carnatic Music & Fine Arts',
    section: 'Section A',
    subject: 'Carnatic Classical Sangeeth & Music Theory',
    academicYear: '2026-2027',
    createdAt: new Date().toISOString(),
    studentCount: 15,
  },
  {
    id: 'cls-9-sangeeth',
    name: 'Class 9 - Classical Sangeeth & Raga Studies',
    section: 'Section B',
    subject: 'Carnatic Vocal & Instrumental',
    academicYear: '2026-2027',
    createdAt: new Date().toISOString(),
    studentCount: 15,
  }
];

// 15 Default Indian Students per class (4 Bright, 3 Average, 8 Failing)
export const DEFAULT_INDIAN_STUDENTS: StudentProfile[] = [
  // 4 Bright Students (High achievers: 85-100%)
  { id: 'std-1', name: 'Aarav Sharma', avatarColor: '#3b82f6', section: 'Class 10 - Carnatic & Fine Arts', rollNo: 'CS-01', classId: 'cls-10-carnatic', attendancePercentage: 98, tier: 'bright' },
  { id: 'std-2', name: 'Ananya Iyer', avatarColor: '#10b981', section: 'Class 10 - Carnatic & Fine Arts', rollNo: 'CS-02', classId: 'cls-10-carnatic', attendancePercentage: 99, tier: 'bright' },
  { id: 'std-3', name: 'Sai Krishna', avatarColor: '#6366f1', section: 'Class 10 - Carnatic & Fine Arts', rollNo: 'CS-03', classId: 'cls-10-carnatic', attendancePercentage: 97, tier: 'bright' },
  { id: 'std-4', name: 'Meera Sundaram', avatarColor: '#14b8a6', section: 'Class 10 - Carnatic & Fine Arts', rollNo: 'CS-04', classId: 'cls-10-carnatic', attendancePercentage: 98, tier: 'bright' },

  // 3 Average Students (Moderate performance: 55-75%)
  { id: 'std-5', name: 'Rohan Deshmukh', avatarColor: '#8b5cf6', section: 'Class 10 - Carnatic & Fine Arts', rollNo: 'CS-05', classId: 'cls-10-carnatic', attendancePercentage: 91, tier: 'average' },
  { id: 'std-6', name: 'Sneha Kulkarni', avatarColor: '#06b6d4', section: 'Class 10 - Carnatic & Fine Arts', rollNo: 'CS-06', classId: 'cls-10-carnatic', attendancePercentage: 92, tier: 'average' },
  { id: 'std-7', name: 'Divya Radhakrishnan', avatarColor: '#4f46e5', section: 'Class 10 - Carnatic & Fine Arts', rollNo: 'CS-07', classId: 'cls-10-carnatic', attendancePercentage: 93, tier: 'average' },

  // 8 Failing Candidates (Need improvement / low score: 15-45%)
  { id: 'std-8', name: 'Priya Venkatesh', avatarColor: '#f59e0b', section: 'Class 10 - Carnatic & Fine Arts', rollNo: 'CS-08', classId: 'cls-10-carnatic', attendancePercentage: 84, tier: 'failing' },
  { id: 'std-9', name: 'Aditya Nair', avatarColor: '#ec4899', section: 'Class 10 - Carnatic & Fine Arts', rollNo: 'CS-09', classId: 'cls-10-carnatic', attendancePercentage: 81, tier: 'failing' },
  { id: 'std-10', name: 'Vikramaditya Rao', avatarColor: '#f97316', section: 'Class 10 - Carnatic & Fine Arts', rollNo: 'CS-10', classId: 'cls-10-carnatic', attendancePercentage: 78, tier: 'failing' },
  { id: 'std-11', name: 'Kavya Subramanian', avatarColor: '#84cc16', section: 'Class 10 - Carnatic & Fine Arts', rollNo: 'CS-11', classId: 'cls-10-carnatic', attendancePercentage: 76, tier: 'failing' },
  // Candidates having attendance below 75% - Barred from writing examination:
  { id: 'std-12', name: 'Karthik Balaji', avatarColor: '#e11d48', section: 'Class 10 - Carnatic & Fine Arts', rollNo: 'CS-12', classId: 'cls-10-carnatic', attendancePercentage: 74, tier: 'failing' },
  { id: 'std-13', name: 'Arjun Nambiar', avatarColor: '#059669', section: 'Class 10 - Carnatic & Fine Arts', rollNo: 'CS-13', classId: 'cls-10-carnatic', attendancePercentage: 70, tier: 'failing' },
  { id: 'std-14', name: 'Pooja Hegde', avatarColor: '#d97706', section: 'Class 10 - Carnatic & Fine Arts', rollNo: 'CS-14', classId: 'cls-10-carnatic', attendancePercentage: 67, tier: 'failing' },
  { id: 'std-15', name: 'Siddharth Raman', avatarColor: '#7c3aed', section: 'Class 10 - Carnatic & Fine Arts', rollNo: 'CS-15', classId: 'cls-10-carnatic', attendancePercentage: 62, tier: 'failing' },
];

export const TEN_PAGE_SAMPLE_DATA = [
  {
    pageNumber: 1,
    title: 'Quantum Logic Gate Realization & Multi-Qubit Fidelity Analysis',
    subtitle: 'Page 1 of 10 · Executive Abstract, Project Scope & Nomenclature',
    content: `Abstract:\nThis 10-page thesis presents empirical laboratory findings regarding superconducting transmon qubits operated in a dilution refrigerator environment. We systematically investigate single-qubit Clifford gate fidelities and two-qubit entanglement dynamics using randomized benchmarking protocols.\n\n1. Introduction & Theoretical Motivation:\nSolid-state quantum computation requires balancing gate execution speed against environmental decoherence. Microwave drive lines and dispersive readout resonators allow non-destructive quantum state measurements.\n\nKey Parameters Investigated:\n• Base temperature: T_base = 12.4 mK\n• Transmon charging energy: E_C = 280 MHz\n• Josephson energy: E_J / E_C = 74.2\n• Readout cavity frequency: omega_r = 7.12 GHz`
  },
  {
    pageNumber: 2,
    title: 'Theoretical Formalism & Hamiltonian Evolution',
    subtitle: 'Page 2 of 10 · Mathematical Framework of the Transmon Regime',
    content: `2. Qubit Hamiltonian Formulation:\nThe transmon qubit is modeled by the standard multi-level Hamiltonian:\nH = 4*E_C*(n - n_g)^2 - E_J*cos(phi)\n\nIn the weakly anharmonic approximation, this evolves into a Duffing oscillator:\nH / hbar = omega_01 * a_dagger * a + (alpha / 2) * a_dagger^2 * a^2\n\nWhere alpha = -E_C represents the negative anharmonicity parameter essential for addressing the computational subspace {|0>, |1>} without leaking into higher leakage states {|2>, |3>}.\n\nNumerical simulation demonstrates that spectral leakage remains below 0.04% for pulse envelopes exceeding 16 ns width.`
  },
  {
    pageNumber: 3,
    title: 'Cryogenic Apparatus & Microwave Attenuation Scheme',
    subtitle: 'Page 3 of 10 · Experimental Instrumentation & Thermal Shielding',
    content: `3. Cryogenic Configuration & Shielding:\nThe experimental device was mounted within an Oxford Instruments Triton dilution refrigerator. Cryostat stage breakdown:\n• Room Temperature (300 K): FPGA pulse synthesis and DAC/ADC conversion\n• 50 K Stage: 20 dB thermal attenuators, stainless steel coaxial cabling\n• 4 K Stage: High-electron-mobility transistor (HEMT) amplifiers with 38 dB gain\n• 100 mK Still Stage: Low-pass reflective filtering\n• Base Plate (12.4 mK): Cryoperm magnetic shielding and infrared absorptive filters\n\nThermal photon population on the drive line was benchmarked at n_th < 0.008 photons/mode, mitigating spurious dephasing.`
  },
  {
    pageNumber: 4,
    title: 'Rabi Oscillations & Single-Qubit Gate Calibration',
    subtitle: 'Page 4 of 10 · Pulse Amplitude Tuning & Quadrature Optimization',
    content: `4. Rabi Flopping & Pi-Pulse Calibration:\nA continuous-wave microwave signal resonant with omega_01 was applied with variable duration tau from 0 to 200 ns. The excited state population P_1 exhibited damped sinusoidal oscillation:\nP_1(tau) = 0.5 * [1 - exp(-tau / T_decay) * cos(Omega_Rabi * tau)]\n\nBy measuring the oscillation frequency as a function of drive amplitude, the pi-pulse duration was calibrated to exactly 20.0 ns. DRAG pulsing was applied to suppress quadrature phase distortion, reducing Phase Error from 1.2% to 0.08%.`
  },
  {
    pageNumber: 5,
    title: 'Decoherence Spectroscopy: T1 and T2* Measurements',
    subtitle: 'Page 5 of 10 · Energy Relaxation & Ramsey Fringe Decay',
    content: `5. Longitudinal Relaxation (T1) Measurements:\nFollowing a calibrated pi-pulse, the qubit was allowed to relax for delay time Delta_t before readout. Fitting to exp(-Delta_t / T1) yielded:\nT1 = 84.6 ± 2.1 microseconds across 1,000 averages.\n\n6. Transverse Dephasing (T2* and T2_echo):\nRamsey interferometry was conducted using two pi/2 pulses separated by variable delay. Artificial detuning Delta_f = 2.0 MHz produced characteristic oscillations with envelope:\nT2* = 52.3 ± 1.8 microseconds.`
  },
  {
    pageNumber: 6,
    title: 'Cross-Resonance Hamiltonian & Two-Qubit Entanglement',
    subtitle: 'Page 6 of 10 · Cross-Resonance Drive Dynamics & Echo Pulses',
    content: `7. Two-Qubit Gate Architecture:\nQubits Q0 (control, 4.88 GHz) and Q1 (target, 5.12 GHz) were coupled via a fixed-frequency bus resonator with coupling constant g = 18 MHz. Driving Q0 at Q1's resonance frequency activates the effective cross-resonance interaction:\nH_CR = (Omega_CR / 2) * (Z_0 * X_1) + (Omega_IX / 2) * (I_0 * X_1)`
  },
  {
    pageNumber: 7,
    title: 'Quantum State Tomography of Maximally Entangled Bell State',
    subtitle: 'Page 7 of 10 · Density Matrix Reconstruction & Concurrence',
    content: `9. Quantum State Tomography:\nStarting from ground state |00>, the CNOT gate produced the Bell state |Phi+> = (|00> + |11>) / sqrt(2). Over-complete state tomography was performed by applying 16 Pauli projection operators {I, X/2, Y/2, X} on both registers.\n\nReconstructed Density Matrix rho elements:\n• rho_{00,00} = 0.488\n• rho_{11,11} = 0.472\n• State fidelity F = <Phi+| rho |Phi+> = 96.2 ± 0.6%`
  },
  {
    pageNumber: 8,
    title: 'Clifford Randomized Benchmarking (RB) Protocols',
    subtitle: 'Page 8 of 10 · Gate Error Rates & Scalable Error Mitigation',
    content: `10. Clifford Group Characterization:\nRandomized benchmarking was executed by applying random sequences of m Clifford gates chosen uniformly from the 24-element single-qubit Clifford group.\n\nSequence lengths were varied: m = [2, 4, 8, 16, 32, 64, 128, 256, 512].\n\n• Single-qubit gate error: r = 0.00019 (99.981% fidelity)\n• Two-qubit interleaved RB gate fidelity for CNOT: 98.42%.`
  },
  {
    pageNumber: 9,
    title: 'Scalability Roadmaps & Cryostat Thermal Management',
    subtitle: 'Page 9 of 10 · Multi-Node Routing & Dissipation Thresholds',
    content: `11. Scalability Constraints at the 1,000-Qubit Frontier:\nInterconnecting thousands of transmon qubits introduces stringent thermal dissipation ceilings. The total cooling power of modern dilution fridges at 100 mK is roughly 400 microwatts, and at 15 mK is approximately 20 microwatts.\n\nThermal Load Budgeting:\n• Superconducting flex cabling: 1.2 nW per line\n• Attenuator thermal anchoring dissipation: 4.8 microwatts at 4 K stage`
  },
  {
    pageNumber: 10,
    title: 'Conclusions, Student Acknowledgments & Academic Citations',
    subtitle: 'Page 10 of 10 · Synthesis, Review Signatures & References',
    content: `12. Final Synthesis & Conclusions:\nIn this 10-page study, we demonstrated superconducting qubit coherence exceeding 110 microseconds and two-qubit gate fidelities reaching 98.4%.\n\nAcademic References:\n[1] Barends et al., Nature 508, 500–503 (2014).\n[2] Gambetta et al., Phys. Rev. A 83, 012308 (2011).\n[3] IEEE Transactions on Quantum Engineering, 2024.`
  }
];

export function getTasks(): Task[] {
  try {
    const raw = localStorage.getItem(TASKS_KEY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

export function saveTask(task: Task): void {
  const tasks = getTasks();
  const index = tasks.findIndex(t => t.id === task.id);
  if (index >= 0) {
    tasks[index] = task;
  } else {
    tasks.unshift(task);
  }
  localStorage.setItem(TASKS_KEY, JSON.stringify(tasks));
  notifyStorageChange();
}

export function updateTaskStatus(taskId: string, status: 'active' | 'stopped'): void {
  const tasks = getTasks();
  const task = tasks.find(t => t.id === taskId);
  if (task) {
    task.status = status;
    localStorage.setItem(TASKS_KEY, JSON.stringify(tasks));
    notifyStorageChange();
  }
}

export function deleteTask(taskId: string): void {
  const tasks = getTasks().filter(t => t.id !== taskId);
  localStorage.setItem(TASKS_KEY, JSON.stringify(tasks));
  notifyStorageChange();
}

export function getSubmissions(): Submission[] {
  try {
    const raw = localStorage.getItem(SUBMISSIONS_KEY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

export function saveSubmission(submission: Submission): void {
  const submissions = getSubmissions();
  const index = submissions.findIndex(s => s.id === submission.id);
  if (index >= 0) {
    submissions[index] = submission;
  } else {
    submissions.unshift(submission);
  }
  localStorage.setItem(SUBMISSIONS_KEY, JSON.stringify(submissions));
  notifyStorageChange();
}

export function updateSubmissionCorrection(
  submissionId: string,
  correction: TeacherCorrection,
  status: 'evaluated' | 'returned' = 'returned'
): void {
  const submissions = getSubmissions();
  const sub = submissions.find(s => s.id === submissionId);
  if (sub) {
    sub.correction = correction;
    sub.status = status;
    localStorage.setItem(SUBMISSIONS_KEY, JSON.stringify(submissions));
    notifyStorageChange();
  }
}

// CLASSES MANAGEMENT
export function getClasses(): ClassGroup[] {
  try {
    const raw = localStorage.getItem(CLASSES_KEY);
    if (!raw) {
      localStorage.setItem(CLASSES_KEY, JSON.stringify(DEFAULT_CLASSES));
      return DEFAULT_CLASSES;
    }
    return JSON.parse(raw);
  } catch {
    return DEFAULT_CLASSES;
  }
}

export function saveClass(cls: ClassGroup): void {
  const classes = getClasses();
  const index = classes.findIndex(c => c.id === cls.id);
  if (index >= 0) {
    classes[index] = cls;
  } else {
    classes.push(cls);
  }
  localStorage.setItem(CLASSES_KEY, JSON.stringify(classes));
  notifyStorageChange();
}

export function deleteClass(classId: string): void {
  const classes = getClasses().filter(c => c.id !== classId);
  localStorage.setItem(CLASSES_KEY, JSON.stringify(classes));
  notifyStorageChange();
}

export function getCurrentClass(): ClassGroup {
  try {
    const raw = localStorage.getItem(CURRENT_CLASS_KEY);
    if (!raw) {
      const cls = getClasses()[0] || DEFAULT_CLASSES[0];
      localStorage.setItem(CURRENT_CLASS_KEY, JSON.stringify(cls));
      return cls;
    }
    return JSON.parse(raw);
  } catch {
    return DEFAULT_CLASSES[0];
  }
}

export function setCurrentClass(cls: ClassGroup): void {
  localStorage.setItem(CURRENT_CLASS_KEY, JSON.stringify(cls));
  notifyStorageChange();
}

// STUDENTS ROSTER (15 Indian Students)
export function getStudentsRoster(): StudentProfile[] {
  try {
    const raw = localStorage.getItem(STUDENTS_ROSTER_KEY);
    if (!raw) {
      localStorage.setItem(STUDENTS_ROSTER_KEY, JSON.stringify(DEFAULT_INDIAN_STUDENTS));
      return DEFAULT_INDIAN_STUDENTS;
    }
    const parsed: StudentProfile[] = JSON.parse(raw);
    // If empty or older roster with non-Indian names, upgrade to 15 Indian students
    if (!parsed || parsed.length < 15 || parsed[0]?.name === 'Alex Rivera' || !parsed[0]?.tier) {
      localStorage.setItem(STUDENTS_ROSTER_KEY, JSON.stringify(DEFAULT_INDIAN_STUDENTS));
      return DEFAULT_INDIAN_STUDENTS;
    }
    return parsed;
  } catch {
    return DEFAULT_INDIAN_STUDENTS;
  }
}

export function addOrUpdateStudent(student: StudentProfile): void {
  const roster = getStudentsRoster();
  const index = roster.findIndex(s => s.id === student.id || s.name.toLowerCase() === student.name.toLowerCase());
  if (index >= 0) {
    roster[index] = { ...roster[index], ...student };
  } else {
    roster.push(student);
  }
  localStorage.setItem(STUDENTS_ROSTER_KEY, JSON.stringify(roster));
  notifyStorageChange();
}

export function deleteStudent(studentId: string): void {
  const roster = getStudentsRoster().filter(s => s.id !== studentId);
  localStorage.setItem(STUDENTS_ROSTER_KEY, JSON.stringify(roster));
  notifyStorageChange();
}

export function getCurrentStudent(): StudentProfile {
  try {
    const raw = localStorage.getItem(CURRENT_STUDENT_KEY);
    if (!raw) {
      const roster = getStudentsRoster();
      const first = roster[0] || DEFAULT_INDIAN_STUDENTS[0];
      localStorage.setItem(CURRENT_STUDENT_KEY, JSON.stringify(first));
      return first;
    }
    const student: StudentProfile = JSON.parse(raw);
    if (student.name === 'Alex Rivera') {
      const first = DEFAULT_INDIAN_STUDENTS[0];
      localStorage.setItem(CURRENT_STUDENT_KEY, JSON.stringify(first));
      return first;
    }
    return student;
  } catch {
    return DEFAULT_INDIAN_STUDENTS[0];
  }
}

export function setCurrentStudent(student: StudentProfile): void {
  localStorage.setItem(CURRENT_STUDENT_KEY, JSON.stringify(student));
  addOrUpdateStudent(student);
  notifyStorageChange();
}

// INTERCONNECTED TASK BUNDLES (e.g. Carnatic Theory 40 marks + Viva 10 marks = 50 total)
export function getTaskBundles(): InterconnectedTaskBundle[] {
  try {
    const raw = localStorage.getItem(BUNDLES_KEY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

export function saveTaskBundle(bundle: InterconnectedTaskBundle): void {
  const bundles = getTaskBundles();
  const index = bundles.findIndex(b => b.id === bundle.id);
  if (index >= 0) {
    bundles[index] = bundle;
  } else {
    bundles.push(bundle);
  }
  localStorage.setItem(BUNDLES_KEY, JSON.stringify(bundles));
  notifyStorageChange();
}

export function deleteTaskBundle(bundleId: string): void {
  const bundles = getTaskBundles().filter(b => b.id !== bundleId);
  localStorage.setItem(BUNDLES_KEY, JSON.stringify(bundles));
  notifyStorageChange();
}

// REPORT CARDS
export function getReportCards(): ReportCard[] {
  try {
    const raw = localStorage.getItem(REPORT_CARDS_KEY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

export function saveReportCard(report: ReportCard): void {
  const reports = getReportCards();
  const index = reports.findIndex(r => r.id === report.id || (r.studentId === report.studentId && r.term === report.term));
  if (index >= 0) {
    reports[index] = report;
  } else {
    reports.unshift(report);
  }
  localStorage.setItem(REPORT_CARDS_KEY, JSON.stringify(reports));
  notifyStorageChange();
}

export function getReportCardsForStudent(studentId: string): ReportCard[] {
  return getReportCards().filter(r => r.studentId === studentId && r.publishedToStudent);
}

export function clearAllData(): void {
  localStorage.removeItem(TASKS_KEY);
  localStorage.removeItem(SUBMISSIONS_KEY);
  localStorage.removeItem(CURRENT_STUDENT_KEY);
  localStorage.removeItem(STUDENTS_ROSTER_KEY);
  localStorage.removeItem(CLASSES_KEY);
  localStorage.removeItem(CURRENT_CLASS_KEY);
  localStorage.removeItem(BUNDLES_KEY);
  localStorage.removeItem(REPORT_CARDS_KEY);
  notifyStorageChange();
}

// SEED STARTER ACTIVITIES (Includes Carnatic Music Internal 40 marks, Viva 10 marks, Connected Bundle, and Report Cards)
export function seedStarterActivities(): void {
  const starterTasks: Task[] = [
    {
      id: 'task-carnatic-internal-40',
      title: 'Carnatic Music Theory & Raga Lakshana Internal Exam',
      description: 'Comprehensive 40-mark theory examination covering Melakarta Ragas, Tala Dasa Pranas, and Swara Sthayis.',
      category: 'examination',
      type: 'carnatic_music',
      status: 'active',
      maxPoints: 40,
      dueDate: new Date(Date.now() + 86400000 * 3).toISOString().split('T')[0],
      createdAt: new Date(Date.now() - 3600000 * 24).toISOString(),
      classId: 'cls-10-carnatic',
      linkedBundleId: 'bundle-carnatic-term-1',
      timeLimitMinutes: 60,
      carnaticConfig: {
        raga: 'Mayamalavagowla (15th Melakarta)',
        tala: 'Adi Tala (Chatusra Nadai - 8 Aksharas)',
        baseShruti: 'C (1 Kattai)',
        taskAspect: 'theory_internal',
        recommendedSpeed: '2nd Kala (Madhyama)',
        sampleNotation: 'S R1 G3 M1 | P D1 | N3 S || S N3 D1 P | M1 G3 | R1 S ||',
        instructions: 'Write the complete Raga Lakshana of Mayamalavagowla. State the Arohana, Avarohana, Vadi, Samvadi, and transcribe the 1st Geetham in Rupaka Tala with proper akshara spacing.',
      },
    },
    {
      id: 'task-carnatic-viva-10',
      title: 'Carnatic Music Practical Singing & Manodharma Viva',
      description: '10-mark live singing and oral viva on Raga Alapana, Kalpana Swaram, and Tala synchronization.',
      category: 'examination',
      type: 'carnatic_music',
      status: 'active',
      maxPoints: 10,
      dueDate: new Date(Date.now() + 86400000 * 4).toISOString().split('T')[0],
      createdAt: new Date(Date.now() - 3600000 * 20).toISOString(),
      classId: 'cls-10-carnatic',
      linkedBundleId: 'bundle-carnatic-term-1',
      timeLimitMinutes: 15,
      carnaticConfig: {
        raga: 'Mohanam & Kalyani',
        tala: 'Adi Tala / Mishra Chapu',
        baseShruti: 'C# (1.5 Kattai)',
        taskAspect: 'viva_vocal',
        recommendedSpeed: '1st & 2nd Kala',
        instructions: 'Record 2 minutes of Mohanam Raga Alapana with steady Shruti alignment. Demonstrate Adi Tala kriya with claps and finger counts.',
      },
    },
    {
      id: 'asg-word-classical',
      title: 'History of Trinity of Carnatic Music (Tyagaraja, Dikshitar, Sastri)',
      description: 'Prepare an essay with Microsoft Word formatting on the Golden Age of Carnatic Classical Music.',
      category: 'assignment',
      type: 'word_doc',
      status: 'active',
      maxPoints: 50,
      dueDate: new Date(Date.now() + 86400000 * 5).toISOString().split('T')[0],
      createdAt: new Date(Date.now() - 3600000 * 18).toISOString(),
      classId: 'cls-10-carnatic',
      docConfig: {
        prompt: 'Compose an essay detailing the distinctive compositional styles of Saint Tyagaraja (Kritis/Pancharatnam), Muthuswami Dikshitar (Navavarna/Sanskrit), and Syama Sastri (Swarajati/Chowka Kala). Format headers, margins, and typography.',
        minWords: 300,
        sampleTemplate: `THE TRINITY OF CARNATIC MUSIC\nA Historical & Musical Study\n\n1. Introduction\nThe 18th century in Thiruvarur, Tamil Nadu witnessed a golden renaissance with the emergence of three supreme vaggeyakaras...\n\n2. Saint Tyagaraja (1767–1847)\nMaster of devotional lyricism and Telugu kritis. His Pancharatna Kritis in Nattaj, Gaula, Arabhi, Varali, and Sri Raga stand as monuments...\n\n3. Muthuswami Dikshitar (1775–1835)\nMajestic Sanskrit compositions with vilambita kala gamakas, Madhyamakala sahityas, and deep Advaitic philosophy...\n\n4. Syama Sastri (1762–1827)\nIntricate rhythmic mastery with Anandabhairavi and Yadukulakambhoji Swarajatis set to complex chapu talas.`,
      }
    },
    {
      id: 'asg-ppt-tala',
      title: 'PowerPoint Slide Deck: The 35 Talas & Sapta Tala Scheme',
      description: 'Create an illustrative presentation explaining the 7 Suladi Talas and 5 Jathis with Microsoft PowerPoint layouts.',
      category: 'assignment',
      type: 'ppt',
      status: 'active',
      maxPoints: 50,
      dueDate: new Date(Date.now() + 86400000 * 6).toISOString().split('T')[0],
      createdAt: new Date(Date.now() - 3600000 * 12).toISOString(),
      classId: 'cls-10-carnatic',
      pptConfig: {
        prompt: 'Build a multi-slide presentation covering the 6 Angas (Shadangas: Anudhrutam, Dhrutam, Laghu, Guru, Plutam, Kakapadam), the 7 Parent Talas (Dhruva, Matya, Rupaka, Jhampa, Triputa, Ata, Eka), and the 35 Tala matrix.',
        recommendedSlideCount: 4,
      }
    },
    {
      id: 'task-c-coding',
      title: 'C Programming: Compute Factorial & Fibonacci',
      description: 'Write a C program to recursively calculate factorial and the first 10 terms of the Fibonacci sequence.',
      category: 'temporary_task',
      type: 'coding',
      status: 'active',
      maxPoints: 100,
      dueDate: new Date(Date.now() + 86400000 * 2).toISOString().split('T')[0],
      createdAt: new Date(Date.now() - 3600000 * 8).toISOString(),
      classId: 'cls-10-carnatic',
      codingConfig: {
        language: 'c',
        starterCode: `#include <stdio.h>\n\nint factorial(int n) {\n    if (n <= 1) return 1;\n    return n * factorial(n - 1);\n}\n\nint main() {\n    printf("Factorial of 5: %d\\n", factorial(5));\n    return 0;\n}`,
        instructions: 'Implement recursive and iterative solutions. Print output cleanly to stdout.',
      },
    },
  ];

  // Interconnected Bundle linking Carnatic Theory (40 marks) + Viva (10 marks) = 50 marks total
  const starterBundles: InterconnectedTaskBundle[] = [
    {
      id: 'bundle-carnatic-term-1',
      title: 'Carnatic Music Mid-Term Assessment (Theory + Viva)',
      description: 'Interconnected evaluation combining Part A: Theory Exam (40 marks) and Part B: Practical Viva (10 marks). Total: 50 Marks.',
      classId: 'cls-10-carnatic',
      taskIds: ['task-carnatic-internal-40', 'task-carnatic-viva-10'],
      totalMaxMarks: 50,
      createdAt: new Date().toISOString(),
    }
  ];

  const starterSubmissions: Submission[] = [
    {
      id: 'sub-carnatic-internal-ananya',
      taskId: 'task-carnatic-internal-40',
      taskTitle: 'Carnatic Music Theory & Raga Lakshana Internal Exam',
      taskType: 'carnatic_music',
      taskCategory: 'examination',
      studentId: 'std-2',
      studentName: 'Ananya Iyer',
      submittedAt: new Date(Date.now() - 3600000 * 10).toISOString(),
      status: 'returned',
      payload: {
        carnaticRaga: 'Mayamalavagowla',
        carnaticTala: 'Adi Tala',
        carnaticShruti: 'C (1 Kattai)',
        carnaticSwaraNotation: `RAGA MAYAMALAVAGOWLA LAKSHANA\n\nArohana: S R1 G3 M1 P D1 N3 S'\nAvarohana: S' N3 D1 P M1 G3 R1 S\n\nJanya Ragas: Malahari, Saveri, Bauli, Revagupti\n\nGEETHAM (Rupaka Tala - 6 Aksharas):\nS , R1 | G3 M1 P , || M1 P D1 | P , M1 G3 ||\nR1 G3 R1 | S , . . ||`,
        textResponse: 'Completed the full 40-mark theory paper covering Melakarta classification, Shuddha Swara positions, and Geetham notation.',
      },
      correction: {
        grade: 38,
        maxPoints: 40,
        letterGrade: 'A+',
        feedback: 'Superb Raga Lakshana explanation and immaculate Geetham notation transcription. Full marks for swara interval classification.',
        evaluatedAt: new Date(Date.now() - 3600000 * 6).toISOString(),
        evaluatorName: 'Vidwan K. Narayanaswamy (Lead Music Guru)',
        penStrokes: [
          {
            id: 'st-1',
            color: '#10b981',
            width: 3,
            points: [{ x: 90, y: 140 }, { x: 110, y: 165 }, { x: 160, y: 120 }],
            type: 'pen',
          }
        ],
        stamps: [
          { id: 'stamp-1', x: 220, y: 110, color: '#10b981', iconType: 'check', text: '✓' },
          { id: 'stamp-2', x: 300, y: 110, color: '#ef4444', iconType: 'hundred', text: '100' }
        ]
      }
    },
    {
      id: 'sub-carnatic-viva-ananya',
      taskId: 'task-carnatic-viva-10',
      taskTitle: 'Carnatic Music Practical Singing & Manodharma Viva',
      taskType: 'carnatic_music',
      taskCategory: 'examination',
      studentId: 'std-2',
      studentName: 'Ananya Iyer',
      submittedAt: new Date(Date.now() - 3600000 * 8).toISOString(),
      status: 'returned',
      payload: {
        carnaticRaga: 'Mohanam',
        carnaticTala: 'Adi Tala',
        carnaticShruti: 'C# (1.5 Kattai)',
        carnaticAudioUrl: 'data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEARKwAAIhYAQACABAAZGF0YQAAAAA=',
        textResponse: 'Rendered Mohanam Alapana with Gandhara Karvai and Panchama sthayi sancharas. Performed 1st & 2nd speed Sarali varisais in Adi Tala.',
      },
      correction: {
        grade: 9,
        maxPoints: 10,
        letterGrade: 'A+',
        feedback: 'Clear gamaka modulation on Antara Gandhara. Tala kriya sync was precise throughout both speeds.',
        evaluatedAt: new Date(Date.now() - 3600000 * 4).toISOString(),
        evaluatorName: 'Vidwan K. Narayanaswamy (Lead Music Guru)',
        penStrokes: [
          {
            id: 'st-v-1',
            color: '#10b981',
            width: 3,
            points: [{ x: 70, y: 80 }, { x: 95, y: 105 }, { x: 135, y: 70 }],
            type: 'pen',
          }
        ],
        stamps: [
          { id: 'stamp-v-1', x: 200, y: 75, color: '#10b981', iconType: 'check', text: '✓' }
        ]
      }
    },
    {
      id: 'sub-carnatic-internal-aarav',
      taskId: 'task-carnatic-internal-40',
      taskTitle: 'Carnatic Music Theory & Raga Lakshana Internal Exam',
      taskType: 'carnatic_music',
      taskCategory: 'examination',
      studentId: 'std-1',
      studentName: 'Aarav Sharma',
      submittedAt: new Date(Date.now() - 3600000 * 9).toISOString(),
      status: 'returned',
      payload: {
        carnaticRaga: 'Mayamalavagowla',
        carnaticTala: 'Adi Tala',
        carnaticShruti: 'C (1 Kattai)',
        carnaticSwaraNotation: 'S R1 G3 M1 P D1 N3 S\nS N3 D1 P M1 G3 R1 S\nArohana and Avarohana written with Katapayadi sankhya.',
      },
      correction: {
        grade: 35,
        maxPoints: 40,
        letterGrade: 'A',
        feedback: 'Good theoretical breakdown. Practice Rupaka Tala structure and akshara kala spacing.',
        evaluatedAt: new Date(Date.now() - 3600000 * 5).toISOString(),
        evaluatorName: 'Vidwan K. Narayanaswamy (Lead Music Guru)',
        penStrokes: [],
      }
    },
    {
      id: 'sub-carnatic-viva-aarav',
      taskId: 'task-carnatic-viva-10',
      taskTitle: 'Carnatic Music Practical Singing & Manodharma Viva',
      taskType: 'carnatic_music',
      taskCategory: 'examination',
      studentId: 'std-1',
      studentName: 'Aarav Sharma',
      submittedAt: new Date(Date.now() - 3600000 * 7).toISOString(),
      status: 'returned',
      payload: {
        carnaticRaga: 'Kalyani',
        carnaticTala: 'Adi Tala',
        textResponse: 'Practiced Kalyani Varnam in 1st speed.',
      },
      correction: {
        grade: 8,
        maxPoints: 10,
        letterGrade: 'B+',
        feedback: 'Good pitch stability. Maintain steadier Tala beat during higher speed transitions.',
        evaluatedAt: new Date(Date.now() - 3600000 * 3).toISOString(),
        evaluatorName: 'Vidwan K. Narayanaswamy (Lead Music Guru)',
        penStrokes: [],
      }
    }
  ];

  // Official Report Cards published to students
  const starterReportCards: ReportCard[] = [
    {
      id: 'rep-ananya-2026',
      studentId: 'std-2',
      studentName: 'Ananya Iyer',
      classId: 'cls-10-carnatic',
      className: 'Class 10 - Carnatic Music & Fine Arts',
      rollNo: 'CS-02',
      term: 'Carnatic Classical & Fine Arts Mid-Term Examination 2026-27',
      issuedDate: new Date().toLocaleDateString(),
      institutionName: 'Saraswati Sangeetha & Classical Vidyalaya',
      items: [
        {
          taskId: 'task-carnatic-internal-40',
          taskTitle: 'Carnatic Music Theory (Raga Lakshana & Melakarta)',
          taskType: 'carnatic_music',
          category: 'examination',
          maxMarks: 40,
          marksObtained: 38,
          letterGrade: 'A+',
          remarks: 'Outstanding precision in swara sthanas and notation.'
        },
        {
          taskId: 'task-carnatic-viva-10',
          taskTitle: 'Carnatic Vocal Singing & Manodharma Viva',
          taskType: 'carnatic_music',
          category: 'examination',
          maxMarks: 10,
          marksObtained: 9,
          letterGrade: 'A+',
          remarks: 'Excellent shruti alignment and gamaka fidelity.'
        },
        {
          taskId: 'asg-word-classical',
          taskTitle: 'History of Musical Trinity (Word Document Essay)',
          taskType: 'word_doc',
          category: 'assignment',
          maxMarks: 50,
          marksObtained: 47,
          letterGrade: 'A+',
          remarks: 'In-depth historical research on Saint Tyagaraja & Dikshitar.'
        }
      ],
      totalMaxMarks: 100,
      totalMarksObtained: 94,
      percentage: 94,
      overallGrade: 'A+',
      overallStatus: 'Distinction',
      attendancePercentage: 98,
      teacherRemarks: 'Ananya has exhibited extraordinary artistic dedication. Her command of Raga Mayamalavagowla and Adi Tala kriya is exemplary. Highly recommended for advanced concert manodharma training.',
      principalSignature: 'Dr. V. Radhakrishnan (Director & Principal)',
      evaluatorName: 'Vidwan K. Narayanaswamy (Lead Music Guru)',
      publishedToStudent: true,
      publishedAt: new Date().toISOString(),
    },
    {
      id: 'rep-aarav-2026',
      studentId: 'std-1',
      studentName: 'Aarav Sharma',
      classId: 'cls-10-carnatic',
      className: 'Class 10 - Carnatic Music & Fine Arts',
      rollNo: 'CS-01',
      term: 'Carnatic Classical & Fine Arts Mid-Term Examination 2026-27',
      issuedDate: new Date().toLocaleDateString(),
      institutionName: 'Saraswati Sangeetha & Classical Vidyalaya',
      items: [
        {
          taskId: 'task-carnatic-internal-40',
          taskTitle: 'Carnatic Music Theory (Raga Lakshana & Melakarta)',
          taskType: 'carnatic_music',
          category: 'examination',
          maxMarks: 40,
          marksObtained: 35,
          letterGrade: 'A',
          remarks: 'Commendable understanding of 72 Melakarta scheme.'
        },
        {
          taskId: 'task-carnatic-viva-10',
          taskTitle: 'Carnatic Vocal Singing & Manodharma Viva',
          taskType: 'carnatic_music',
          category: 'examination',
          maxMarks: 10,
          marksObtained: 8,
          letterGrade: 'B+',
          remarks: 'Good shruti maintenance. Practice higher speed varisais.'
        },
        {
          taskId: 'task-c-coding',
          taskTitle: 'C Programming: Algorithms & Recursion',
          taskType: 'coding',
          category: 'temporary_task',
          maxMarks: 100,
          marksObtained: 92,
          letterGrade: 'A',
          remarks: 'Solid computational logic and terminal output verification.'
        }
      ],
      totalMaxMarks: 150,
      totalMarksObtained: 135,
      percentage: 90,
      overallGrade: 'A',
      overallStatus: 'First Class',
      attendancePercentage: 96,
      teacherRemarks: 'Aarav has shown strong academic and musical aptitude. Maintain focus on rhythm precision in Tala transitions.',
      principalSignature: 'Dr. V. Radhakrishnan (Director & Principal)',
      evaluatorName: 'Vidwan K. Narayanaswamy (Lead Music Guru)',
      publishedToStudent: true,
      publishedAt: new Date().toISOString(),
    }
  ];

  localStorage.setItem(CLASSES_KEY, JSON.stringify(DEFAULT_CLASSES));
  localStorage.setItem(STUDENTS_ROSTER_KEY, JSON.stringify(DEFAULT_INDIAN_STUDENTS));
  localStorage.setItem(CURRENT_CLASS_KEY, JSON.stringify(DEFAULT_CLASSES[0]));
  localStorage.setItem(CURRENT_STUDENT_KEY, JSON.stringify(DEFAULT_INDIAN_STUDENTS[1])); // Ananya Iyer
  localStorage.setItem(TASKS_KEY, JSON.stringify(starterTasks));
  localStorage.setItem(BUNDLES_KEY, JSON.stringify(starterBundles));
  localStorage.setItem(SUBMISSIONS_KEY, JSON.stringify(starterSubmissions.map(sub => ({ ...sub, correction: undefined, status: 'submitted' as const }))));
  localStorage.setItem(REPORT_CARDS_KEY, JSON.stringify(starterReportCards));
  localStorage.setItem(ANNOUNCEMENTS_KEY, JSON.stringify(DEFAULT_ANNOUNCEMENTS));
  notifyStorageChange();
}

export const DEFAULT_ANNOUNCEMENTS: Announcement[] = [
  {
    id: 'ann-1',
    title: '⚠️ Mandatory 75% Minimum Attendance Requirement for Final Examinations',
    content: 'Notice to all candidates: Pursuant to Academic Board Regulation 14(b), candidates having cumulative attendance below 75% are strictly barred from entering the Examination Hall and writing semester examinations. Review your eligibility status in the Student Portal.',
    priority: 'exam_alert',
    classId: 'all',
    postedBy: 'Academic Dean & Controller of Examinations',
    postedAt: new Date(Date.now() - 3600000 * 2).toISOString(),
    pinned: true,
    tags: ['Attendance Notice', '75% Rule', 'Exam Hall Rule']
  },
  {
    id: 'ann-2',
    title: 'Carnatic Classical Sangeeth: Word Document Template & Viva Instructions',
    content: 'Class 10 Section A: When writing the Carnatic Kriti Analysis thesis, please utilize the faculty-provided Word Document template with pre-structured sections for Arohana/Avarohana, Tala structure, and Sahitya.',
    priority: 'important',
    classId: 'cls-10-carnatic',
    postedBy: 'Vidwan K. Narayanaswamy (Lead Music Guru)',
    postedAt: new Date(Date.now() - 3600000 * 6).toISOString(),
    pinned: true,
    tags: ['Carnatic Music', 'Word Template', 'Assignment']
  },
  {
    id: 'ann-3',
    title: 'Data Science & Audio Acoustics: Matplotlib and Pandas Compiler Available',
    content: 'Students can now execute Python scripts using Matplotlib, NumPy, and Pandas to visualize acoustic harmonics and pitch curves, or build interactive web interfaces with HTML/CSS in the updated multi-color compiler.',
    priority: 'normal',
    classId: 'all',
    postedBy: 'Prof. S. R. Venkataraman (HOD)',
    postedAt: new Date(Date.now() - 3600000 * 24).toISOString(),
    pinned: false,
    tags: ['Python', 'Matplotlib', 'HTML/CSS']
  }
];

// ANNOUNCEMENTS
export function getAnnouncements(classId?: string): Announcement[] {
  try {
    const raw = localStorage.getItem(ANNOUNCEMENTS_KEY);
    let list: Announcement[] = raw ? JSON.parse(raw) : DEFAULT_ANNOUNCEMENTS;
    if (!raw) {
      localStorage.setItem(ANNOUNCEMENTS_KEY, JSON.stringify(DEFAULT_ANNOUNCEMENTS));
    }
    if (classId && classId !== 'all') {
      list = list.filter(a => !a.classId || a.classId === 'all' || a.classId === classId);
    }
    // Pinned first, then newest
    return list.sort((a, b) => {
      if (a.pinned && !b.pinned) return -1;
      if (!a.pinned && b.pinned) return 1;
      return new Date(b.postedAt).getTime() - new Date(a.postedAt).getTime();
    });
  } catch {
    return DEFAULT_ANNOUNCEMENTS;
  }
}

export function saveAnnouncements(announcements: Announcement[]): void {
  localStorage.setItem(ANNOUNCEMENTS_KEY, JSON.stringify(announcements));
  notifyStorageChange();
}

export function addAnnouncement(data: Omit<Announcement, 'id' | 'postedAt'>): Announcement {
  const current = getAnnouncements();
  const newAnn: Announcement = {
    ...data,
    id: 'ann-' + Date.now(),
    postedAt: new Date().toISOString(),
  };
  const updated = [newAnn, ...current];
  saveAnnouncements(updated);
  return newAnn;
}

export function deleteAnnouncement(id: string): void {
  const current = getAnnouncements();
  const updated = current.filter(a => a.id !== id);
  saveAnnouncements(updated);
}

export function togglePinAnnouncement(id: string): void {
  const current = getAnnouncements();
  const updated = current.map(a => a.id === id ? { ...a, pinned: !a.pinned } : a);
  saveAnnouncements(updated);
}

// ATTENDANCE SESSIONS & STUDENT PERCENTAGE MANAGEMENT
export function getAttendanceSessions(classId?: string): AttendanceSession[] {
  try {
    const raw = localStorage.getItem(ATTENDANCE_SESSIONS_KEY);
    if (!raw) return [];
    const list: AttendanceSession[] = JSON.parse(raw);
    if (classId) {
      return list.filter(s => s.classId === classId);
    }
    return list;
  } catch {
    return [];
  }
}

export function saveAttendanceSession(session: AttendanceSession): void {
  const sessions = getAttendanceSessions();
  const existingIdx = sessions.findIndex(s => s.id === session.id);
  if (existingIdx >= 0) {
    sessions[existingIdx] = session;
  } else {
    sessions.unshift(session);
  }
  localStorage.setItem(ATTENDANCE_SESSIONS_KEY, JSON.stringify(sessions));
  notifyStorageChange();
}

export function updateStudentAttendance(studentId: string, newPercentage: number): void {
  const roster = getStudentsRoster();
  const student = roster.find(s => s.id === studentId);
  if (student) {
    student.attendancePercentage = Math.min(100, Math.max(0, Math.round(newPercentage)));
    localStorage.setItem(STUDENTS_ROSTER_KEY, JSON.stringify(roster));
    
    // Also update current student if matches
    const current = getCurrentStudent();
    if (current.id === studentId) {
      current.attendancePercentage = student.attendancePercentage;
      localStorage.setItem(CURRENT_STUDENT_KEY, JSON.stringify(current));
    }
    notifyStorageChange();
  }
}

export function recordClassAttendance(
  date: string,
  classId: string,
  className: string,
  sessionTitle: string,
  records: {
    studentId: string;
    studentName: string;
    rollNo: string;
    status: 'present' | 'absent' | 'late' | 'excused';
    cumulativePercentage: number;
    remarks?: string;
  }[]
): AttendanceSession {
  const newSession: AttendanceSession = {
    id: 'att-session-' + Date.now(),
    date,
    classId,
    className,
    sessionTitle,
    records,
    createdAt: new Date().toISOString(),
  };

  saveAttendanceSession(newSession);

  // Update the roster with the teacher-entered cumulative percentage and
  // the exact present/absent/late/excused status recorded for this session.
  const roster = getStudentsRoster();
  records.forEach(rec => {
    const std = roster.find(s => s.id === rec.studentId);
    if (std) std.attendancePercentage = rec.cumulativePercentage;
  });
  localStorage.setItem(STUDENTS_ROSTER_KEY, JSON.stringify(roster));

  // Also sync current student if in this class
  const current = getCurrentStudent();
  const matchingRec = records.find(r => r.studentId === current.id);
  if (matchingRec) {
    current.attendancePercentage = matchingRec.cumulativePercentage;
    localStorage.setItem(CURRENT_STUDENT_KEY, JSON.stringify(current));
  }

  notifyStorageChange();
  return newSession;
}

const STORAGE_EVENT_NAME = 'edutask_storage_updated';

function notifyStorageChange() {
  window.dispatchEvent(new Event(STORAGE_EVENT_NAME));
}

export function subscribeToDataChanges(callback: () => void): () => void {
  window.addEventListener(STORAGE_EVENT_NAME, callback);
  window.addEventListener('storage', callback);
  return () => {
    window.removeEventListener(STORAGE_EVENT_NAME, callback);
    window.removeEventListener('storage', callback);
  };
}
