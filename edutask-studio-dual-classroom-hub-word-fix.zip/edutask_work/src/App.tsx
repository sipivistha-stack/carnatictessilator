/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Role, Task, Submission, StudentProfile, TeacherCorrection } from './types';
import { 
  getTasks, 
  saveTask, 
  updateTaskStatus, 
  deleteTask, 
  getSubmissions, 
  saveSubmission, 
  updateSubmissionCorrection, 
  getStudentsRoster, 
  getCurrentStudent, 
  setCurrentStudent, 
  seedStarterActivities, 
  clearAllData,
  subscribeToDataChanges 
} from './data/storage';
import { generateStudentSubmissionsForTask } from './services/aiStudentSimulator';

import { Header } from './components/common/Header';
import { StudentDashboard } from './components/student/StudentDashboard';
import { TeacherDashboard } from './components/teacher/TeacherDashboard';

export default function App() {
  const [currentRole, setCurrentRole] = useState<Role>('teacher'); // Teacher by default so they see how to add first, or easily toggle to student
  const [tasks, setTasks] = useState<Task[]>([]);
  const [submissions, setSubmissions] = useState<Submission[]>([]);
  const [students, setStudents] = useState<StudentProfile[]>([]);
  const [currentStudent, setCurrentStudentState] = useState<StudentProfile>(getCurrentStudent());

  const syncStateFromStorage = () => {
    setTasks(getTasks());
    setSubmissions(getSubmissions());
    setStudents(getStudentsRoster());
    setCurrentStudentState(getCurrentStudent());
  };

  useEffect(() => {
    syncStateFromStorage();
    const unsubscribe = subscribeToDataChanges(() => {
      syncStateFromStorage();
    });
    return () => unsubscribe();
  }, []);

  const handleSelectRole = (role: Role) => {
    setCurrentRole(role);
  };

  const handleSaveTask = (task: Task) => {
    saveTask(task);
  };

  const handleUpdateTaskStatus = (taskId: string, status: 'active' | 'stopped') => {
    updateTaskStatus(taskId, status);
  };

  const handleDeleteTask = (taskId: string) => {
    deleteTask(taskId);
  };

  const handleSaveEvaluation = (
    submissionId: string, 
    correction: TeacherCorrection, 
    status: 'evaluated' | 'returned'
  ) => {
    updateSubmissionCorrection(submissionId, correction, status);
  };

  const handleSubmitTask = (submission: Submission) => {
    saveSubmission(submission);
  };

  const handleSelectStudent = (student: StudentProfile) => {
    setCurrentStudent(student);
    setCurrentStudentState(student);
  };

  const handleCustomStudentName = (name: string) => {
    const newStudent: StudentProfile = {
      id: 'custom-' + Date.now(),
      name,
      avatarColor: '#6366f1',
      section: 'Grade 10 - Section A',
      rollNo: 'CS-' + Math.floor(10 + Math.random() * 89),
      tier: 'average',
    };
    setCurrentStudent(newStudent);
    setCurrentStudentState(newStudent);
  };

  const handleSeedStarters = () => {
    seedStarterActivities();
    const currentTasks = getTasks();
    currentTasks.forEach(t => {
      generateStudentSubmissionsForTask(t, false);
    });
    syncStateFromStorage();
  };

  const handleClearData = () => {
    clearAllData();
  };

  return (
    <div className="min-h-screen bg-slate-100/70 text-slate-900 flex flex-col font-sans selection:bg-indigo-100 selection:text-indigo-900">
      {/* Top Header with Role Switcher ("Are you Teacher or Student?") */}
      <Header
        currentRole={currentRole}
        onSelectRole={handleSelectRole}
        currentStudent={currentStudent}
        students={students}
        onSelectStudent={handleSelectStudent}
      />

      {/* Main Workspace Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8">
        {currentRole === 'teacher' ? (
          <TeacherDashboard
            tasks={tasks}
            submissions={submissions}
            students={students}
            onSaveTask={handleSaveTask}
            onUpdateTaskStatus={handleUpdateTaskStatus}
            onDeleteTask={handleDeleteTask}
            onSaveEvaluation={handleSaveEvaluation}
            onSeedStarters={handleSeedStarters}
            onClearData={handleClearData}
          />
        ) : (
          <StudentDashboard
            tasks={tasks}
            submissions={submissions}
            students={students}
            currentStudent={currentStudent}
            onSelectStudent={handleSelectStudent}
            onCustomStudentName={handleCustomStudentName}
            onSubmitTask={handleSubmitTask}
          />
        )}
      </main>
    </div>
  );
}
