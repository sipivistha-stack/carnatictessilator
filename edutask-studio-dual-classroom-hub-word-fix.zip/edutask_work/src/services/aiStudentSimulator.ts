/**
 * AI Student Submission Simulator
 * Automatically generates realistic submissions for the 15 enrolled students based on their profile tier:
 * - 4 Bright Students (85-100% quality, thorough answers, flawless code with matplotlib/pandas, perfect swaras)
 * - 3 Average Students (55-75% quality, decent answers, minor flaws)
 * - 8 Failing Candidates (15-45% quality, incomplete work, syntax errors, wrong ragas/swaras)
 */

import { Task, Submission, StudentProfile, TeacherCorrection, PenStroke, StampAnnotation } from '../types';
import { getStudentsRoster, saveSubmission, getSubmissions } from '../data/storage';

// Helper to generate SVG data URL for Matplotlib plots
function generateMockMatplotlibPlot(title: string, type: 'line' | 'bar' | 'scatter' = 'line'): string {
  const width = 500;
  const height = 280;
  let chartContent = '';

  if (type === 'bar') {
    chartContent = `
      <rect x="70" y="160" width="40" height="70" fill="#6366f1" rx="4"/>
      <rect x="130" y="100" width="40" height="130" fill="#3b82f6" rx="4"/>
      <rect x="190" y="70" width="40" height="160" fill="#06b6d4" rx="4"/>
      <rect x="250" y="120" width="40" height="110" fill="#10b981" rx="4"/>
      <rect x="310" y="50" width="40" height="180" fill="#f59e0b" rx="4"/>
      <text x="80" y="248" font-size="10" fill="#64748b">Sa</text>
      <text x="140" y="248" font-size="10" fill="#64748b">Ri</text>
      <text x="200" y="248" font-size="10" fill="#64748b">Ga</text>
      <text x="260" y="248" font-size="10" fill="#64748b">Ma</text>
      <text x="320" y="248" font-size="10" fill="#64748b">Pa</text>
    `;
  } else {
    // Smooth sinusoidal wave / curve
    chartContent = `
      <path d="M 60 140 Q 120 40, 180 140 T 300 140 T 420 140" fill="none" stroke="#8b5cf6" stroke-width="3"/>
      <path d="M 60 140 Q 120 80, 180 140 T 300 140 T 420 140" fill="none" stroke="#06b6d4" stroke-width="2" stroke-dasharray="4"/>
      <circle cx="120" cy="90" r="4" fill="#ec4899"/>
      <circle cx="240" cy="190" r="4" fill="#ec4899"/>
      <circle cx="360" cy="90" r="4" fill="#ec4899"/>
    `;
  }

  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}" style="background:#0f172a; font-family: ui-sans-serif, system-ui, sans-serif;">
    <rect width="${width}" height="${height}" fill="#0f172a"/>
    <text x="25" y="32" font-size="14" font-weight="bold" fill="#f8fafc">matplotlib.pyplot: ${title}</text>
    <text x="25" y="48" font-size="10" fill="#94a3b8">Figure 1 · Python 3.11 · Matplotlib v3.8</text>
    <!-- Axes Grid -->
    <line x1="50" y1="60" x2="50" y2="230" stroke="#334155" stroke-width="1.5"/>
    <line x1="50" y1="230" x2="460" y2="230" stroke="#334155" stroke-width="1.5"/>
    <line x1="50" y1="145" x2="460" y2="145" stroke="#1e293b" stroke-width="1" stroke-dasharray="3"/>
    <line x1="50" y1="80" x2="460" y2="80" stroke="#1e293b" stroke-width="1" stroke-dasharray="3"/>
    ${chartContent}
    <text x="420" y="245" font-size="10" fill="#64748b">X-axis</text>
    <text x="15" y="145" font-size="10" fill="#64748b" transform="rotate(-90 20,145)">Y-axis</text>
  </svg>`;

  return 'data:image/svg+xml;utf8,' + encodeURIComponent(svg);
}

export function generateStudentSubmissionsForTask(
  task: Task,
  preEvaluate: boolean = true
): Submission[] {
  const roster = getStudentsRoster();
  const existingSubmissions = getSubmissions();
  const generated: Submission[] = [];

  roster.forEach(student => {
    // Skip if student already submitted this task
    const already = existingSubmissions.find(s => s.taskId === task.id && s.studentId === student.id);
    if (already) {
      generated.push(already);
      return;
    }

    const tier = student.tier || 'average';
    const sub = createSubmissionForStudent(task, student, tier, preEvaluate);
    saveSubmission(sub);
    generated.push(sub);
  });

  return generated;
}

function createSubmissionForStudent(
  task: Task,
  student: StudentProfile,
  tier: 'bright' | 'average' | 'failing',
  preEvaluate: boolean
): Submission {
  const submissionId = `sub-${task.id}-${student.id}`;
  const now = new Date();
  // Jitter submission timestamp within the past 12-48 hours
  const hoursAgo = Math.floor(Math.random() * 24) + 6;
  const submittedAt = new Date(now.getTime() - hoursAgo * 3600000).toISOString();

  let payload = buildPayload(task, tier, student.name);
  // AI/student simulation must never grade or correct a submission.
  // Teacher evaluation is the only source of correction data.
  const correction: TeacherCorrection | undefined = undefined;

  return {
    id: submissionId,
    taskId: task.id,
    taskTitle: task.title,
    taskType: task.type,
    taskCategory: task.category,
    studentId: student.id,
    studentName: student.name,
    submittedAt,
    status: preEvaluate ? 'returned' : 'submitted',
    payload,
    correction,
  };
}

function buildPayload(task: Task, tier: 'bright' | 'average' | 'failing', studentName: string): any {
  switch (task.type) {
    case 'carnatic_music':
      return buildCarnaticPayload(task, tier, studentName);
    case 'coding':
      return buildCodingPayload(task, tier);
    case 'quiz':
    case 'mcq':
      return buildQuizPayload(task, tier);
    case 'word_doc':
      return buildWordDocPayload(task, tier, studentName);
    case 'ppt':
      return buildPptPayload(task, tier, studentName);
    case 'typing_exam':
      return buildTypingPayload(task, tier);
    default:
      return buildGenericPayload(task, tier, studentName);
  }
}

// 1. CARNATIC MUSIC SIMULATED PAYLOAD
function buildCarnaticPayload(task: Task, tier: 'bright' | 'average' | 'failing', studentName: string) {
  const cfg = task.carnaticConfig;
  const raga = cfg?.raga || 'Mayamalavagowla';
  const tala = cfg?.tala || 'Adi Tala';
  const shruti = cfg?.baseShruti || 'C (1 Kattai)';

  if (tier === 'bright') {
    return {
      carnaticRaga: raga,
      carnaticTala: tala,
      carnaticShruti: shruti,
      carnaticToolsUsed: ['Shruti Box (Tanpura)', 'Tala Metronome', 'Swara Keyboard', 'Raga Lakshana Explorer', 'Audio Recorder'],
      carnaticAudioUrl: 'data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEARKwAAIhYAQACABAAZGF0YQAAAAA=',
      carnaticSwaraNotation: `|| S , R1 | G3 M1 P , || M1 P D1 | P , M1 G3 ||\n|| R1 G3 R1 | S , . . || S' N3 D1 | P M1 G3 R1 ||\n|| S R1 G3 M1 | P D1 | N3 S' || S' N3 D1 P | M1 G3 | R1 S ||`,
      textResponse: `Comprehensive Raga Lakshana Analysis for ${raga}:\n• Janaka Melakarta #15 (Agni Chakra)\n• Swaras: Shadjam (S), Shuddha Rishabha (R1), Antara Gandhara (G3), Shuddha Madhyama (M1), Panchama (P), Shuddha Dhaivatha (D1), Kakali Nishadha (N3).\n• Vadi Swara: Panchama; Samvadi Swara: Shadjam.\n• Performed in 1st (Vilambita) and 2nd (Madhyama) speed with steady Adi Tala akshara reckoning.`,
      carnaticSelfAssessmentNotes: 'Shruti was aligned at 1 Kattai (C 130.8 Hz). Maintained finger counts and wave for dhrutam accurately.',
    };
  }

  if (tier === 'average') {
    return {
      carnaticRaga: raga,
      carnaticTala: tala,
      carnaticShruti: shruti,
      carnaticToolsUsed: ['Shruti Box', 'Tala Metronome', 'Swara Keyboard'],
      carnaticAudioUrl: 'data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEARKwAAIhYAQACABAAZGF0YQAAAAA=',
      carnaticSwaraNotation: `S R1 G3 M1 | P D1 | N3 S\nS N3 D1 P | M1 G3 | R1 S\nS , R1 G3 | M1 P , ||`,
      textResponse: `Lakshana notes for ${raga}:\nIt is a sampoorna raga. Has S, R1, G3, M1, P, D1, N3. Sung in Adi Tala 1st speed. Practice needed on Gandhara karvai.`,
      carnaticSelfAssessmentNotes: 'Maintained basic beat, slight delay during 2nd speed transition.',
    };
  }

  // Failing Candidate
  return {
    carnaticRaga: raga,
    carnaticTala: 'Incomplete',
    carnaticShruti: 'Uncalibrated',
    carnaticToolsUsed: ['Swara Keyboard'],
    carnaticAudioUrl: undefined,
    carnaticSwaraNotation: `S R G M P D N S (Incorrect note positions, missing intervals)`,
    textResponse: `Could not remember full arohana and avarohana swaras. Wrote basic scale. Audio could not be recorded in time.`,
    carnaticSelfAssessmentNotes: 'Had difficulty keeping tala count with left hand.',
  };
}

// 2. CODING SIMULATED PAYLOAD (with Matplotlib, Pandas, HTML/CSS)
function buildCodingPayload(task: Task, tier: 'bright' | 'average' | 'failing') {
  const lang = task.codingConfig?.language || 'python';
  const instructions = `${task.codingConfig?.instructions || ''}\n${task.description || ''}`.toLowerCase();

  // Follow the teacher's actual instruction before applying any tier/demo styling.
  // In particular, do not replace a simple input/output exercise with a canned
  // Carnatic/ML example. The generated submission is code only; it is not graded.
  const asksInputAndPrint =
    /(take|read|accept|get|receive).*input/.test(instructions) &&
    /(print|display|output|show).*input/.test(instructions);

  if (asksInputAndPrint) {
    if (lang === 'python') {
      const code = `value = input()\nprint(value)`;
      return { code, codeLanguage: 'python', stdinProvided: 'Sample input', codeStdout: 'Sample input', codeExecutionSuccess: true };
    }
    if (lang === 'c') {
      const code = `#include <stdio.h>\n\nint main(void) {\n    char value[256];\n    fgets(value, sizeof(value), stdin);\n    printf(\"%s\", value);\n    return 0;\n}`;
      return { code, codeLanguage: 'c', stdinProvided: 'Sample input', codeStdout: 'Sample input', codeExecutionSuccess: true };
    }
    if (lang === 'cpp') {
      const code = `#include <iostream>\n#include <string>\nusing namespace std;\n\nint main() {\n    string value;\n    getline(cin, value);\n    cout << value;\n    return 0;\n}`;
      return { code, codeLanguage: 'cpp', stdinProvided: 'Sample input', codeStdout: 'Sample input', codeExecutionSuccess: true };
    }
  }

  if (lang === 'html') {
    if (tier === 'bright') {
      const htmlCode = `<!DOCTYPE html>
<html>
<head>
  <style>
    body { font-family: sans-serif; background: #0f172a; color: #f8fafc; padding: 20px; }
    .card { background: #1e293b; border-radius: 12px; padding: 24px; border: 1px solid #3b82f6; }
    .badge { background: #6366f1; color: white; padding: 4px 10px; border-radius: 6px; font-size: 12px; }
    h1 { color: #38bdf8; margin-top: 8px; }
  </style>
</head>
<body>
  <div class="card">
    <span class="badge">Carnatic Academy</span>
    <h1>Classical Sangeeth Portal</h1>
    <p>Interactive web application showcasing Raga Lakshana and Tala calculations.</p>
  </div>
</body>
</html>`;
      return {
        code: htmlCode,
        codeLanguage: 'html',
        htmlPreview: htmlCode,
        codeStdout: 'HTML & CSS validated successfully. 0 syntax errors. Rendered in live DOM sandbox.',
        codeExecutionSuccess: true,
      };
    } else if (tier === 'average') {
      const htmlCode = `<div><h1>Student Web Page</h1><p style="color: blue;">Simple webpage design</p></div>`;
      return {
        code: htmlCode,
        codeLanguage: 'html',
        htmlPreview: htmlCode,
        codeStdout: 'Rendered basic HTML container.',
        codeExecutionSuccess: true,
      };
    } else {
      const htmlCode = `<div><h1>Unfinished Page<p>Missing close tags`;
      return {
        code: htmlCode,
        codeLanguage: 'html',
        htmlPreview: htmlCode,
        codeStdout: '[HTML Warning]: Unclosed tags detected on line 1',
        codeStderr: 'HTML Lint: Unclosed tag <h1> and <div>',
        codeExecutionSuccess: false,
      };
    }
  }

  // Python / C / C++
  if (tier === 'bright') {
    const pythonCode = `import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# Generate Swara frequency data
swaras = ['Sa', 'Ri1', 'Ga3', 'Ma1', 'Pa', 'Dha1', 'Ni3', 'Sa_high']
ratios = [1.0, 16/15, 5/4, 4/3, 3/2, 8/5, 15/8, 2.0]
base_hz = 130.81  # 1 Kattai (C)

df = pd.DataFrame({
    'Swara': swaras,
    'Ratio': ratios,
    'Frequency_Hz': np.round(np.array(ratios) * base_hz, 2)
})

print("=== CARNATIC SWARA FREQUENCY MATRIX ===")
print(df.to_string(index=False))

# Plot Matplotlib chart
plt.figure(figsize=(8, 4))
plt.plot(df['Swara'], df['Frequency_Hz'], marker='o', color='indigo')
plt.title('Raga Mayamalavagowla Frequency Spectrum')
plt.ylabel('Frequency (Hz)')
plt.grid(True)
plt.show()`;

    return {
      code: pythonCode,
      codeLanguage: 'python',
      stdinProvided: '130.81',
      codeStdout: `=== CARNATIC SWARA FREQUENCY MATRIX ===
    Swara    Ratio  Frequency_Hz
       Sa 1.000000        130.81
      Ri1 1.066667        139.53
      Ga3 1.250000        163.51
      Ma1 1.333333        174.41
       Pa 1.500000        196.22
     Dha1 1.600000        209.30
      Ni3 1.875000        245.27
  Sa_high 2.000000        261.62

[Matplotlib]: Rendered 1 figure (Line Chart) successfully.`,
      codeExecutionSuccess: true,
      matplotlibPlotUrl: generateMockMatplotlibPlot('Raga Frequency Spectrum (Pandas & Numpy)', 'line'),
      pandasTableHtml: `<table class="w-full text-xs border border-slate-700"><thead><tr class="bg-indigo-950 text-indigo-200"><th class="p-1">Swara</th><th class="p-1">Ratio</th><th class="p-1">Frequency (Hz)</th></tr></thead><tbody><tr><td class="p-1">Sa</td><td>1.000</td><td>130.81</td></tr><tr><td class="p-1">Ri1</td><td>1.067</td><td>139.53</td></tr><tr><td class="p-1">Ga3</td><td>1.250</td><td>163.51</td></tr><tr><td class="p-1">Ma1</td><td>1.333</td><td>174.41</td></tr><tr><td class="p-1">Pa</td><td>1.500</td><td>196.22</td></tr></tbody></table>`,
    };
  }

  if (tier === 'average') {
    const pythonCode = `import numpy as np

# Compute frequencies
hz = [130.8, 139.5, 163.5, 174.4, 196.2]
arr = np.array(hz)
print("Frequencies:", arr)
print("Mean Hz:", np.mean(arr))`;

    return {
      code: pythonCode,
      codeLanguage: 'python',
      codeStdout: `Frequencies: [130.8 139.5 163.5 174.4 196.2]\nMean Hz: 160.88`,
      codeExecutionSuccess: true,
      matplotlibPlotUrl: generateMockMatplotlibPlot('Mean Frequency Values', 'bar'),
    };
  }

  // Failing Candidate
  const failingCode = `import pandas as pd
# Incomplete program
def compute_data():
    x = [1, 2, 3
    return x[10] # IndexError

compute_data()`;

  return {
    code: failingCode,
    codeLanguage: 'python',
    codeStdout: '',
    codeStderr: `Traceback (most recent call last):
  File "solution.py", line 4
    x = [1, 2, 3
SyntaxError: closing parenthesis ']' does not match opening parenthesis '['`,
    codeExecutionSuccess: false,
  };
}

// 3. QUIZ / MCQ SIMULATED PAYLOAD
function buildQuizPayload(task: Task, tier: 'bright' | 'average' | 'failing') {
  const questions = task.quizConfig?.questions || task.mcqConfig?.questions || [];
  const selectedOptions: Record<string, number> = {};
  let correctCount = 0;

  questions.forEach((q, idx) => {
    if (tier === 'bright') {
      // 90-100% correct
      const isCorrect = Math.random() > 0.1;
      selectedOptions[q.id] = isCorrect ? q.correctOptionIndex : (q.correctOptionIndex + 1) % q.options.length;
      if (isCorrect) correctCount++;
    } else if (tier === 'average') {
      // 60-70% correct
      const isCorrect = idx % 3 !== 0;
      selectedOptions[q.id] = isCorrect ? q.correctOptionIndex : (q.correctOptionIndex + 1) % q.options.length;
      if (isCorrect) correctCount++;
    } else {
      // 20-40% correct
      const isCorrect = idx === 0;
      selectedOptions[q.id] = isCorrect ? q.correctOptionIndex : (q.correctOptionIndex + 2) % q.options.length;
      if (isCorrect) correctCount++;
    }
  });

  const totalPoints = questions.reduce((sum, q) => sum + (q.points || 1), 0) || 10;
  const scoreRatio = questions.length > 0 ? correctCount / questions.length : (tier === 'bright' ? 0.95 : tier === 'average' ? 0.65 : 0.3);
  const autoScore = Math.round(scoreRatio * task.maxPoints);

  return {
    selectedOptions,
    autoScore,
    textResponse: `Answered ${correctCount} out of ${questions.length} questions correctly.`,
  };
}

// 4. WORD DOC SIMULATED PAYLOAD
function buildWordDocPayload(task: Task, tier: 'bright' | 'average' | 'failing', studentName: string) {
  if (tier === 'bright') {
    return {
      docTitle: `${task.title} - Academic Research Paper`,
      docContent: `HISTORICAL SURVEY & MUSICAL DISCOURSE\nBy ${studentName}\n\n1. Abstract & Introduction\nThe classical Carnatic tradition represents an unbroken lineage of melodic and rhythmic synthesis. The structural evolution from the Natya Shastra through Chaturdandi Prakasika solidified the Melakarta scheme of 72 scales.\n\n2. Analytical Discourse\nSaint Tyagaraja's immortal Pancharatna Kritis demonstrate the highest pinnacle of swara-sahitya symmetry. In Arabhi and Sri Ragas, the intricate swara sancharas exhibit how madhyamakala sahitya maintains emotional bhakthi while adhering strictly to Tala kriya constraints.\n\n3. Conclusion & Theoretical Corollaries\nThe timeless genius of the Trinity provided a universal framework for contemporary manodharma, ensuring fidelity to shruti and gamaka nuances.`,
      docStyles: { fontFamily: 'Georgia', fontSize: '15px', margins: 'Normal (1 in)', pageColor: '#ffffff' },
    };
  }

  if (tier === 'average') {
    return {
      docTitle: `${task.title} - Overview Notes`,
      docContent: `Classical Carnatic Music Paper\nBy ${studentName}\n\nCarnatic music originated in South India. Saint Tyagaraja, Muthuswami Dikshitar, and Syama Sastri are known as the Trinity. Tyagaraja wrote many kritis in Telugu praising Lord Rama. Dikshitar wrote in Sanskrit with slow tempo gamakas.\n\nThe 72 Melakartas was invented by Venkatamakhin. Tala gives the rhythm with laghu and dhrutam.`,
      docStyles: { fontFamily: 'Calibri', fontSize: '14px', margins: 'Normal', pageColor: '#ffffff' },
    };
  }

  return {
    docTitle: `${task.title} - Draft`,
    docContent: `Music history draft.\nTyagaraja was a great singer in South India. Wrote songs.\n(Submission incomplete due to lack of time)`,
    docStyles: { fontFamily: 'Arial', fontSize: '13px', margins: 'Narrow', pageColor: '#ffffff' },
  };
}

// 5. PPT SLIDES SIMULATED PAYLOAD
function buildPptPayload(task: Task, tier: 'bright' | 'average' | 'failing', studentName: string) {
  if (tier === 'bright') {
    return {
      pptTheme: 'carnatic_gold',
      slides: [
        {
          id: 's-1',
          title: 'The 35 Tala System in Carnatic Music',
          bullets: ['Formulated through Suladi Sapta Talas', 'Presented by ' + studentName, 'Classical Fine Arts Semester Evaluation'],
          layout: 'title',
        },
        {
          id: 's-2',
          title: 'The 6 Shadangas (Rhythmic Angas)',
          bullets: [
            'Anudhrutam (U): 1 Akshara (single clap)',
            'Dhrutam (O): 2 Aksharas (clap + wave)',
            'Laghu (I): Variable Aksharas (clap + finger counts)',
            'Guru (8), Plutam (12), Kakapadam (16)',
          ],
          layout: 'content',
        },
        {
          id: 's-3',
          title: 'The 5 Jathis & 7 Parent Talas',
          bullets: [
            'Tisra (3), Chatusra (4), Khanda (5), Mishra (7), Sankeerna (9)',
            'Parent Talas: Dhruva, Matya, Rupaka, Jhampa, Triputa, Ata, Eka',
            '5 Jathis x 7 Talas = 35 Distinct Tala Variations',
          ],
          layout: 'two_column',
        },
      ],
    };
  }

  if (tier === 'average') {
    return {
      pptTheme: 'office_navy',
      slides: [
        { id: 's-1', title: 'Tala System Basics', bullets: ['Carnatic Rhythm Deck', 'Student: ' + studentName], layout: 'title' },
        { id: 's-2', title: 'Suladi Sapta Talas', bullets: ['Dhruva Tala', 'Rupaka Tala', 'Triputa Tala (Adi Tala is Chatusra Triputa)'], layout: 'content' },
      ],
    };
  }

  return {
    pptTheme: 'slate_dark',
    slides: [
      { id: 's-1', title: 'Talas (Rough Notes)', bullets: ['Tala has beats', 'Needs completion'], layout: 'title' },
    ],
  };
}

// 6. TYPING EXAM SIMULATED PAYLOAD
function buildTypingPayload(task: Task, tier: 'bright' | 'average' | 'failing') {
  const passage = task.typingConfig?.passage || 'Carnatic music is a system of music commonly associated with southern India.';
  if (tier === 'bright') {
    return {
      typingSpeedWpm: 68 + Math.floor(Math.random() * 14),
      typingAccuracyPercentage: 98 + Math.floor(Math.random() * 2),
      typingCompletedText: passage,
    };
  } else if (tier === 'average') {
    return {
      typingSpeedWpm: 42 + Math.floor(Math.random() * 10),
      typingAccuracyPercentage: 88 + Math.floor(Math.random() * 6),
      typingCompletedText: passage.slice(0, Math.floor(passage.length * 0.9)),
    };
  } else {
    return {
      typingSpeedWpm: 18 + Math.floor(Math.random() * 10),
      typingAccuracyPercentage: 62 + Math.floor(Math.random() * 15),
      typingCompletedText: passage.slice(0, Math.floor(passage.length * 0.4)),
    };
  }
}

function buildGenericPayload(task: Task, tier: 'bright' | 'average' | 'failing', studentName: string) {
  return {
    textResponse: tier === 'bright'
      ? `Thorough, articulate response submitted by ${studentName}. Addressed all task prompts with conceptual clarity.`
      : tier === 'average'
      ? `Standard response submitted by ${studentName}. Covers the primary questions with moderate depth.`
      : `Brief incomplete draft response from ${studentName}.`,
  };
}

// BUILD CORRECTION & FEEDBACK MATCHING STUDENT TIER
function buildCorrection(
  task: Task,
  tier: 'bright' | 'average' | 'failing',
  studentName: string
): TeacherCorrection {
  const max = task.maxPoints;

  if (tier === 'bright') {
    const grade = Math.round(max * (0.90 + Math.random() * 0.09));
    const penStrokes: PenStroke[] = [
      {
        id: 'st-b-1',
        color: '#10b981',
        width: 3,
        type: 'pen',
        points: [{ x: 80, y: 120 }, { x: 105, y: 145 }, { x: 155, y: 100 }],
      },
    ];
    const stamps: StampAnnotation[] = [
      { id: 'st-stamp-1', x: 200, y: 90, color: '#10b981', iconType: 'check', text: '✓' },
      { id: 'st-stamp-2', x: 260, y: 90, color: '#ef4444', iconType: 'star', text: '★ Excellent' },
    ];

    return {
      grade,
      maxPoints: max,
      letterGrade: grade / max >= 0.94 ? 'A+' : 'A',
      feedback: `Outstanding work, ${studentName}! Immaculate technical execution, clear structural layout, and complete conceptual depth. Commendable precision.`,
      evaluatedAt: new Date().toISOString(),
      evaluatorName: 'Vidwan K. Narayanaswamy (Lead Music Guru)',
      penStrokes,
      stamps,
    };
  }

  if (tier === 'average') {
    const grade = Math.round(max * (0.60 + Math.random() * 0.14));
    const penStrokes: PenStroke[] = [
      {
        id: 'st-a-1',
        color: '#f59e0b',
        width: 2.5,
        type: 'pen',
        points: [{ x: 90, y: 130 }, { x: 110, y: 150 }, { x: 140, y: 120 }],
      },
    ];
    const stamps: StampAnnotation[] = [
      { id: 'st-stamp-avg', x: 210, y: 95, color: '#3b82f6', iconType: 'check', text: 'Good' },
    ];

    return {
      grade,
      maxPoints: max,
      letterGrade: grade / max >= 0.70 ? 'B+' : 'B',
      feedback: `Decent effort, ${studentName}. You understand the foundational concepts well. Review the highlighted corrections to improve rhythmic timing and syntax accuracy.`,
      evaluatedAt: new Date().toISOString(),
      evaluatorName: 'Vidwan K. Narayanaswamy (Lead Music Guru)',
      penStrokes,
      stamps,
    };
  }

  // Failing Candidate
  const grade = Math.max(1, Math.round(max * (0.20 + Math.random() * 0.20)));
  const penStrokes: PenStroke[] = [
    {
      id: 'st-f-1',
      color: '#ef4444',
      width: 3,
      type: 'pen',
      points: [{ x: 80, y: 110 }, { x: 130, y: 150 }],
    },
    {
      id: 'st-f-2',
      color: '#ef4444',
      width: 3,
      type: 'pen',
      points: [{ x: 130, y: 110 }, { x: 80, y: 150 }],
    },
  ];
  const stamps: StampAnnotation[] = [
    { id: 'st-stamp-f', x: 200, y: 95, color: '#ef4444', iconType: 'cross', text: 'Needs Revision' },
  ];

  return {
    grade,
    maxPoints: max,
    letterGrade: 'F',
    feedback: `Incomplete submission, ${studentName}. Critical theoretical errors and missing components were found. Please attend the remedial review clinic to retake this assessment.`,
    evaluatedAt: new Date().toISOString(),
    evaluatorName: 'Vidwan K. Narayanaswamy (Lead Music Guru)',
    penStrokes,
    stamps,
  };
}
