/** Reliable browser-side .docx reader. */
import JSZip from 'jszip';

function xmlToPlainText(xml: string): string {
  const parser = new DOMParser();
  const doc = parser.parseFromString(xml, 'application/xml');
  if (doc.querySelector('parsererror')) {
    throw new Error('The DOCX XML could not be read.');
  }

  const paragraphs = Array.from(doc.getElementsByTagName('w:p'));
  return paragraphs.map(p => {
    const parts: string[] = [];
    Array.from(p.childNodes).forEach(node => {
      if (node.nodeType !== Node.ELEMENT_NODE) return;
      const el = node as Element;
      if (el.localName === 'r') {
        Array.from(el.getElementsByTagName('w:t')).forEach(t => parts.push(t.textContent || ''));
        if (el.getElementsByTagName('w:tab').length) parts.push('\t');
      } else if (el.localName === 'hyperlink') {
        Array.from(el.getElementsByTagName('w:t')).forEach(t => parts.push(t.textContent || ''));
      } else if (el.localName === 'br') {
        parts.push('\n');
      }
    });
    // Fallback for runs nested in less common Word XML structures.
    if (!parts.length) {
      Array.from(p.getElementsByTagName('w:t')).forEach(t => parts.push(t.textContent || ''));
    }
    return parts.join('');
  }).join('\n').replace(/\n{3,}/g, '\n\n').trim();
}

export async function parseDocxText(file: File): Promise<string> {
  if (!file.name.toLowerCase().endsWith('.docx')) {
    throw new Error('Please select a .docx Word document.');
  }
  if (file.size === 0) {
    throw new Error('The selected Word document is empty.');
  }

  try {
    const zip = await JSZip.loadAsync(await file.arrayBuffer());
    const documentEntry = zip.file('word/document.xml');
    if (!documentEntry) {
      throw new Error('word/document.xml was not found. Please upload a valid .docx file.');
    }
    const xml = await documentEntry.async('string');
    const text = xmlToPlainText(xml);
    if (!text) throw new Error('The Word document contains no readable text.');
    return text;
  } catch (err) {
    if (err instanceof Error && err.message.startsWith('word/document.xml')) throw err;
    if (err instanceof Error && err.message.includes('no readable text')) throw err;
    throw new Error('Unable to read this Word document. Please upload a valid .docx file saved from Microsoft Word or LibreOffice.');
  }
}

export async function parseDocxPages(file: File) {
  const text = await parseDocxText(file);
  const lines = text.split('\n');
  const pageSize = 45;
  const pages = [];
  for (let i = 0; i < lines.length; i += pageSize) {
    pages.push({
      pageNumber: pages.length + 1,
      title: file.name.replace(/\.[^/.]+$/, ''),
      subtitle: `Imported from Word · Page ${pages.length + 1}`,
      content: lines.slice(i, i + pageSize).join('\n'),
    });
  }
  return pages.length ? pages : [{ pageNumber: 1, title: file.name, content: text }];
}
