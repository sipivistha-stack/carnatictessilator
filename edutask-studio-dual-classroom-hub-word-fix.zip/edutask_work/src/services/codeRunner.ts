/**
 * Code Execution Engine
 * Simulates compilation and execution for:
 * - HTML & CSS (Live DOM render sandbox)
 * - Python 3.11 with Matplotlib, Pandas, NumPy, and stdin inputs
 * - C (GCC 12 / C17) with stdin inputs
 * - C++ (G++ 20) with stdin inputs
 * - JavaScript (Node.js) with console / stdin inputs
 * - Java (OpenJDK 17)
 */

import { ProgrammingLanguage } from '../types';

export interface ExecutionResult {
  success: boolean;
  compileOutput?: string;
  stdout: string;
  stderr?: string;
  exitCode: number;
  executionTimeMs: number;
  memoryUsageKb: number;
  matplotlibPlotUrl?: string;
  pandasTableHtml?: string;
  htmlPreview?: string;
}

export function executeCode(
  language: ProgrammingLanguage,
  code: string,
  stdin: string = ''
): ExecutionResult {
  const startTime = performance.now();

  try {
    switch (language) {
      case 'html':
        return runHtml(code, startTime);
      case 'python':
        return runPython(code, stdin, startTime);
      case 'c':
        return runC(code, stdin, startTime);
      case 'cpp':
        return runCpp(code, stdin, startTime);
      case 'javascript':
        return runJavaScript(code, stdin, startTime);
      case 'java':
        return runJava(code, stdin, startTime);
      default:
        return {
          success: false,
          stdout: '',
          stderr: `Unsupported language: ${language}`,
          exitCode: 1,
          executionTimeMs: Math.round(performance.now() - startTime),
          memoryUsageKb: 1024,
        };
    }
  } catch (err: any) {
    return {
      success: false,
      stdout: '',
      stderr: `Runtime Error: ${err.message || String(err)}`,
      exitCode: 1,
      executionTimeMs: Math.round(performance.now() - startTime),
      memoryUsageKb: 1240,
    };
  }
}

/**
 * HTML & CSS Live Rendering Sandbox
 */
function runHtml(code: string, startTime: number): ExecutionResult {
  const cleanCode = code.trim();
  const errors: string[] = [];

  // Basic validation
  if (!cleanCode) {
    return {
      success: false,
      stdout: '',
      stderr: 'Error: Empty HTML source provided.',
      exitCode: 1,
      executionTimeMs: Math.round(performance.now() - startTime),
      memoryUsageKb: 512,
    };
  }

  // Count open vs closing tags for basic validation
  const tags = ['div', 'p', 'h1', 'h2', 'h3', 'table', 'style', 'script', 'ul', 'ol', 'li'];
  for (const tag of tags) {
    const openMatches = (cleanCode.match(new RegExp(`<${tag}[^>]*>`, 'gi')) || []).length;
    const closeMatches = (cleanCode.match(new RegExp(`</${tag}>`, 'gi')) || []).length;
    if (openMatches > closeMatches) {
      errors.push(`Warning: Potential unclosed <${tag}> tag (found ${openMatches} open, ${closeMatches} closed)`);
    }
  }

  return {
    success: true,
    compileOutput: `[HTML5 & CSS3 Engine]: DOM parsed successfully.\nCSS rules compiled with 0 fatal errors.`,
    stdout: `[Live Web Server]: Mounted HTML/CSS document.\nDOM nodes rendered: ${(cleanCode.match(/<[a-z0-9]+/gi) || []).length}\nStylesheets active: ${(cleanCode.match(/<style/gi) || []).length}`,
    stderr: errors.length > 0 ? errors.join('\n') : undefined,
    exitCode: 0,
    executionTimeMs: Math.max(10, Math.round(performance.now() - startTime)),
    memoryUsageKb: 1420,
    htmlPreview: cleanCode,
  };
}

/**
 * Matplotlib Graphic Generator
 */
function generateMatplotlibSvg(title: string, plotType: 'line' | 'bar' | 'scatter' = 'line'): string {
  const width = 580;
  const height = 300;
  let chartGraphic = '';

  if (plotType === 'bar') {
    chartGraphic = `
      <g>
        <rect x="75" y="160" width="45" height="80" fill="#6366f1" rx="4"/>
        <rect x="145" y="90" width="45" height="150" fill="#3b82f6" rx="4"/>
        <rect x="215" y="50" width="45" height="190" fill="#06b6d4" rx="4"/>
        <rect x="285" y="110" width="45" height="130" fill="#10b981" rx="4"/>
        <rect x="355" y="40" width="45" height="200" fill="#f59e0b" rx="4"/>
        <rect x="425" y="130" width="45" height="110" fill="#ec4899" rx="4"/>
        <text x="97" y="260" font-size="11" fill="#94a3b8" text-anchor="middle">S (1.0)</text>
        <text x="167" y="260" font-size="11" fill="#94a3b8" text-anchor="middle">R1 (1.06)</text>
        <text x="237" y="260" font-size="11" fill="#94a3b8" text-anchor="middle">G3 (1.25)</text>
        <text x="307" y="260" font-size="11" fill="#94a3b8" text-anchor="middle">M1 (1.33)</text>
        <text x="377" y="260" font-size="11" fill="#94a3b8" text-anchor="middle">P (1.50)</text>
        <text x="447" y="260" font-size="11" fill="#94a3b8" text-anchor="middle">D1 (1.60)</text>
      </g>
    `;
  } else if (plotType === 'scatter') {
    chartGraphic = `
      <g>
        <circle cx="90" cy="200" r="5" fill="#f43f5e"/>
        <circle cx="150" cy="160" r="6" fill="#38bdf8"/>
        <circle cx="210" cy="110" r="5" fill="#a855f7"/>
        <circle cx="270" cy="90" r="7" fill="#22c55e"/>
        <circle cx="330" cy="60" r="5" fill="#eab308"/>
        <circle cx="390" cy="130" r="6" fill="#ec4899"/>
        <circle cx="450" cy="70" r="5" fill="#6366f1"/>
        <line x1="60" y1="210" x2="480" y2="60" stroke="#f43f5e" stroke-dasharray="4" stroke-width="1.5"/>
      </g>
    `;
  } else {
    // Smooth Curve (Sine Wave / Frequency response)
    chartGraphic = `
      <g>
        <path d="M 60 150 Q 120 40, 180 150 T 300 150 T 420 150 T 510 150" fill="none" stroke="#818cf8" stroke-width="3"/>
        <path d="M 60 150 Q 120 80, 180 150 T 300 150 T 420 150 T 510 150" fill="none" stroke="#2dd4bf" stroke-width="2" stroke-dasharray="4"/>
        <circle cx="120" cy="95" r="4.5" fill="#ec4899"/>
        <circle cx="240" cy="205" r="4.5" fill="#ec4899"/>
        <circle cx="360" cy="95" r="4.5" fill="#ec4899"/>
        <circle cx="480" cy="205" r="4.5" fill="#ec4899"/>
      </g>
    `;
  }

  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}" style="background:#0f172a; font-family: ui-sans-serif, system-ui, -apple-system, sans-serif;">
    <rect width="${width}" height="${height}" fill="#0f172a" rx="10"/>
    <text x="24" y="32" font-size="14" font-weight="700" fill="#f8fafc">matplotlib.pyplot: ${title}</text>
    <text x="24" y="48" font-size="10" fill="#64748b">Matplotlib Figure 1 · Python 3.11.8 Engine · High-DPI Output</text>
    
    <!-- Axes Grid -->
    <line x1="60" y1="60" x2="60" y2="240" stroke="#334155" stroke-width="1.5"/>
    <line x1="60" y1="240" x2="520" y2="240" stroke="#334155" stroke-width="1.5"/>
    <line x1="60" y1="150" x2="520" y2="150" stroke="#1e293b" stroke-width="1" stroke-dasharray="3"/>
    <line x1="60" y1="90" x2="520" y2="90" stroke="#1e293b" stroke-width="1" stroke-dasharray="3"/>
    
    ${chartGraphic}
    
    <text x="490" y="255" font-size="10" fill="#94a3b8">Time / X-Axis</text>
    <text x="18" y="150" font-size="10" fill="#94a3b8" transform="rotate(-90 18,150)">Amplitude / Y-Axis</text>
  </svg>`;

  return 'data:image/svg+xml;utf8,' + encodeURIComponent(svg);
}

/**
 * Python 3.11 Execution (with Matplotlib, Pandas, NumPy, and Stdin)
 */
function runPython(code: string, stdin: string, startTime: number): ExecutionResult {
  const outputs: string[] = [];
  const errors: string[] = [];
  let plotUrl: string | undefined = undefined;
  let pandasHtml: string | undefined = undefined;

  // Split stdin lines for input()
  const stdinLines = stdin ? stdin.split('\n') : [];
  let stdinIndex = 0;

  // Check imports
  const usesMatplotlib = code.includes('matplotlib') || code.includes('plt.');
  const usesPandas = code.includes('pandas') || code.includes('pd.');
  const usesNumpy = code.includes('numpy') || code.includes('np.');

  // Parse lines to evaluate prints or simulate simple Python
  const lines = code.split('\n');
  const pyVars: Record<string, any> = {};

  try {
    for (let i = 0; i < lines.length; i++) {
      const rawLine = lines[i];
      const line = rawLine.trim();
      if (!line || line.startsWith('#')) continue;

      // Check for syntax errors like unclosed parenthesis/brackets
      const openParen = (line.match(/\(/g) || []).length;
      const closeParen = (line.match(/\)/g) || []).length;
      if (openParen !== closeParen && !line.endsWith(':')) {
        return {
          success: false,
          compileOutput: `python3 solution.py`,
          stdout: '',
          stderr: `Traceback (most recent call last):\n  File "solution.py", line ${i + 1}\n    ${line}\nSyntaxError: unmatched '${openParen > closeParen ? '(' : ')'}'`,
          exitCode: 1,
          executionTimeMs: Math.round(performance.now() - startTime),
          memoryUsageKb: 4120,
        };
      }

      // Handle input()
      if (line.includes('input(')) {
        const promptMatch = line.match(/input\s*\(\s*["']?([^"']*)["']?\s*\)/);
        const promptText = promptMatch ? promptMatch[1] : '';
        const inputVal = stdinIndex < stdinLines.length ? stdinLines[stdinIndex++] : (stdin || '10');
        if (promptText) outputs.push(promptText + inputVal);

        // Assign to variable
        if (line.includes('=')) {
          const varName = line.split('=')[0].trim();
          pyVars[varName] = isNaN(Number(inputVal)) ? inputVal : Number(inputVal);
        }
        continue;
      }

      // Handle simple print(...)
      if (line.startsWith('print(') && line.endsWith(')')) {
        const inside = line.slice(6, -1);
        try {
          const evalScope = Object.keys(pyVars)
            .map(k => `const ${k} = ${JSON.stringify(pyVars[k])};`)
            .join(' ');
          const res = Function(`${evalScope} "use strict"; return (${inside});`)();
          outputs.push(typeof res === 'object' ? JSON.stringify(res, null, 2) : String(res));
        } catch {
          if ((inside.startsWith('"') && inside.endsWith('"')) || (inside.startsWith("'") && inside.endsWith("'"))) {
            outputs.push(inside.slice(1, -1));
          } else {
            outputs.push(pyVars[inside] !== undefined ? String(pyVars[inside]) : inside);
          }
        }
      } else if (line.includes('=') && !line.includes('==') && !line.startsWith('if') && !line.startsWith('for')) {
        const [varName, expr] = line.split('=').map(s => s.trim());
        if (/^[a-zA-Z_]\w*$/.test(varName)) {
          try {
            // Check for numpy operations
            if (expr.includes('np.array')) {
              pyVars[varName] = [1, 2, 3, 4, 5];
            } else if (expr.includes('np.mean')) {
              pyVars[varName] = 3.0;
            } else if (expr.includes('np.linspace')) {
              pyVars[varName] = [0.0, 2.5, 5.0, 7.5, 10.0];
            } else {
              const evalScope = Object.keys(pyVars)
                .map(k => `const ${k} = ${JSON.stringify(pyVars[k])};`)
                .join(' ');
              pyVars[varName] = Function(`${evalScope} "use strict"; return (${expr});`)();
            }
          } catch {
            pyVars[varName] = expr;
          }
        }
      }
    }

    // Handle Matplotlib
    if (usesMatplotlib) {
      let plotType: 'line' | 'bar' | 'scatter' = 'line';
      if (code.includes('plt.bar')) plotType = 'bar';
      if (code.includes('plt.scatter')) plotType = 'scatter';

      let plotTitle = 'Data Visualization';
      const titleMatch = code.match(/plt\.title\s*\(\s*["']([^"']+)["']\s*\)/);
      if (titleMatch) plotTitle = titleMatch[1];

      plotUrl = generateMatplotlibSvg(plotTitle, plotType);
      outputs.push(`[matplotlib.pyplot]: Generated 1 figure (${plotType.toUpperCase()}) -> Rendered in Canvas`);
    }

    // Handle Pandas
    if (usesPandas) {
      pandasHtml = `
        <div class="overflow-x-auto rounded-lg border border-slate-700 bg-slate-900/90 p-2 my-2 font-mono text-xs">
          <div class="text-[11px] font-bold text-sky-400 mb-1 flex items-center justify-between">
            <span>pandas.DataFrame (8 rows × 3 columns)</span>
            <span class="text-slate-500 font-normal">df.to_html()</span>
          </div>
          <table class="w-full text-left border-collapse">
            <thead>
              <tr class="border-b border-slate-700 text-slate-300 text-[11px] bg-slate-800/60">
                <th class="p-1.5">Index</th>
                <th class="p-1.5">Swara</th>
                <th class="p-1.5">Ratio</th>
                <th class="p-1.5">Frequency_Hz</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800 text-slate-200">
              <tr><td class="p-1.5 text-slate-500">0</td><td class="p-1.5 font-bold text-amber-300">Sa</td><td class="p-1.5">1.000</td><td class="p-1.5 text-emerald-400">130.81</td></tr>
              <tr><td class="p-1.5 text-slate-500">1</td><td class="p-1.5 font-bold text-amber-300">Ri1</td><td class="p-1.5">1.067</td><td class="p-1.5 text-emerald-400">139.53</td></tr>
              <tr><td class="p-1.5 text-slate-500">2</td><td class="p-1.5 font-bold text-amber-300">Ga3</td><td class="p-1.5">1.250</td><td class="p-1.5 text-emerald-400">163.51</td></tr>
              <tr><td class="p-1.5 text-slate-500">3</td><td class="p-1.5 font-bold text-amber-300">Ma1</td><td class="p-1.5">1.333</td><td class="p-1.5 text-emerald-400">174.41</td></tr>
              <tr><td class="p-1.5 text-slate-500">4</td><td class="p-1.5 font-bold text-amber-300">Pa</td><td class="p-1.5">1.500</td><td class="p-1.5 text-emerald-400">196.22</td></tr>
              <tr><td class="p-1.5 text-slate-500">5</td><td class="p-1.5 font-bold text-amber-300">Dha1</td><td class="p-1.5">1.600</td><td class="p-1.5 text-emerald-400">209.30</td></tr>
              <tr><td class="p-1.5 text-slate-500">6</td><td class="p-1.5 font-bold text-amber-300">Ni3</td><td class="p-1.5">1.875</td><td class="p-1.5 text-emerald-400">245.27</td></tr>
              <tr><td class="p-1.5 text-slate-500">7</td><td class="p-1.5 font-bold text-amber-300">Sa'</td><td class="p-1.5">2.000</td><td class="p-1.5 text-emerald-400">261.62</td></tr>
            </tbody>
          </table>
        </div>
      `;

      if (!outputs.some(o => o.includes('DataFrame') || o.includes('Frequency'))) {
        outputs.push(`   Swara    Ratio  Frequency_Hz\n0     Sa 1.000000        130.81\n1    Ri1 1.066667        139.53\n2    Ga3 1.250000        163.51\n3    Ma1 1.333333        174.41\n4     Pa 1.500000        196.22\n5   Dha1 1.600000        209.30\n6    Ni3 1.875000        245.27\n7    Sa' 2.000000        261.62`);
      }
    }

    if (outputs.length === 0 && errors.length === 0) {
      outputs.push(`[Python 3.11.8 execution completed with exit code 0]`);
    }

    return {
      success: true,
      compileOutput: `python3 solution.py${stdin ? ' < stdin.txt' : ''}`,
      stdout: outputs.join('\n'),
      exitCode: 0,
      executionTimeMs: Math.max(20, Math.round(performance.now() - startTime)),
      memoryUsageKb: 5240,
      matplotlibPlotUrl: plotUrl,
      pandasTableHtml: pandasHtml,
    };
  } catch (err: any) {
    return {
      success: false,
      compileOutput: `python3 solution.py`,
      stdout: outputs.join('\n'),
      stderr: `Traceback (most recent call last):\n  File "solution.py", line 1\n${err.message || String(err)}`,
      exitCode: 1,
      executionTimeMs: Math.round(performance.now() - startTime),
      memoryUsageKb: 4120,
    };
  }
}

/**
 * C Language Compiler (with Stdin inputs)
 */
function runC(code: string, stdin: string, startTime: number): ExecutionResult {
  const compileLogs: string[] = [
    `gcc -Wall -O2 -std=c17 solution.c -o solution -lm`,
  ];

  if (!code.includes('main')) {
    return {
      success: false,
      compileOutput: compileLogs.join('\n') + `\n/usr/bin/ld: undefined reference to 'main'`,
      stdout: '',
      stderr: `Compilation error: 'main' function is required in C programs.`,
      exitCode: 1,
      executionTimeMs: Math.round(performance.now() - startTime),
      memoryUsageKb: 0,
    };
  }

  const openBraces = (code.match(/{/g) || []).length;
  const closeBraces = (code.match(/}/g) || []).length;
  if (openBraces !== closeBraces) {
    return {
      success: false,
      compileOutput: compileLogs.join('\n') + `\nsolution.c: error: unmatched braces`,
      stdout: '',
      stderr: `Syntax Error: Unmatched curly braces (found ${openBraces} '{' and ${closeBraces} '}').`,
      exitCode: 1,
      executionTimeMs: Math.round(performance.now() - startTime),
      memoryUsageKb: 0,
    };
  }

  const outputs: string[] = [];
  const vars: Record<string, any> = {};

  // If scanf is used, parse stdin
  if (code.includes('scanf') && stdin) {
    outputs.push(`[Standard Input read]: ${stdin.trim()}`);
  }

  const printfRegex = /printf\s*\(\s*"([^"\\]*(?:\\.[^"\\]*)*)"\s*(?:,\s*([^)]+))?\s*\)\s*;/g;
  let match;
  let hasOutputs = false;

  while ((match = printfRegex.exec(code)) !== null) {
    hasOutputs = true;
    let formatStr = match[1].replace(/\\n/g, '\n').replace(/\\t/g, '\t');
    const argsStr = match[2];

    if (argsStr) {
      const args = splitCArgs(argsStr);
      let argIndex = 0;
      const formatted = formatStr.replace(/%([0-9]*\.?[0-9]*[dfscu%])/g, (specifier) => {
        if (specifier === '%%') return '%';
        if (argIndex >= args.length) return specifier;
        const rawArg = args[argIndex++].trim();
        try {
          const evalScope = Object.keys(vars).map(k => `const ${k} = ${JSON.stringify(vars[k])};`).join(' ');
          const evaluated = Function(`${evalScope} "use strict"; return (${rawArg});`)();
          return String(evaluated);
        } catch {
          return rawArg;
        }
      });
      outputs.push(formatted);
    } else {
      outputs.push(formatStr);
    }
  }

  if (!hasOutputs) {
    outputs.push(`Program compiled and executed with exit code 0.`);
  }

  compileLogs.push(`Compilation finished with 0 errors, 0 warnings.`);
  compileLogs.push(`./solution${stdin ? ` <<< "${stdin}"` : ''}`);

  return {
    success: true,
    compileOutput: compileLogs.join('\n'),
    stdout: outputs.join(''),
    exitCode: 0,
    executionTimeMs: Math.max(14, Math.round(performance.now() - startTime)),
    memoryUsageKb: 2156,
  };
}

/**
 * C++ Execution
 */
function runCpp(code: string, stdin: string, startTime: number): ExecutionResult {
  const compileLogs = [
    `g++ -Wall -O2 -std=c++20 solution.cpp -o solution`,
    `Compilation finished successfully.`,
    `./solution`,
  ];

  if (!code.includes('main')) {
    return {
      success: false,
      compileOutput: `g++: error: 'main' function missing`,
      stdout: '',
      stderr: `Linker error: undefined reference to 'main'`,
      exitCode: 1,
      executionTimeMs: Math.round(performance.now() - startTime),
      memoryUsageKb: 0,
    };
  }

  const outputs: string[] = [];
  if (code.includes('cin') && stdin) {
    outputs.push(`[cin stream received]: ${stdin.trim()}`);
  }

  const coutRegex = /std::cout\s*<<\s*([^;]+);/g;
  let match;
  while ((match = coutRegex.exec(code)) !== null) {
    const expr = match[1];
    const parts = expr.split('<<').map(p => p.trim());
    let line = '';
    for (const part of parts) {
      if (part === 'std::endl' || part === 'endl') {
        line += '\n';
      } else if (part.startsWith('"') && part.endsWith('"')) {
        line += part.slice(1, -1).replace(/\\n/g, '\n').replace(/\\t/g, '\t');
      } else {
        try {
          line += String(Function(`"use strict"; return (${part});`)());
        } catch {
          line += part;
        }
      }
    }
    outputs.push(line);
  }

  if (outputs.length === 0) {
    return runC(code, stdin, startTime);
  }

  return {
    success: true,
    compileOutput: compileLogs.join('\n'),
    stdout: outputs.join(''),
    exitCode: 0,
    executionTimeMs: Math.max(16, Math.round(performance.now() - startTime)),
    memoryUsageKb: 3410,
  };
}

/**
 * JavaScript / Node.js Execution
 */
function runJavaScript(code: string, stdin: string, startTime: number): ExecutionResult {
  const outputs: string[] = [];
  const errors: string[] = [];

  const originalLog = console.log;
  const originalError = console.error;
  const originalWarn = console.warn;

  try {
    console.log = (...args: any[]) => {
      outputs.push(args.map(a => typeof a === 'object' ? JSON.stringify(a, null, 2) : String(a)).join(' '));
    };
    console.error = (...args: any[]) => {
      errors.push(args.map(a => typeof a === 'object' ? JSON.stringify(a, null, 2) : String(a)).join(' '));
    };
    console.warn = (...args: any[]) => {
      outputs.push('[WARN] ' + args.map(a => String(a)).join(' '));
    };

    const runner = new Function(code);
    runner();

    return {
      success: errors.length === 0,
      compileOutput: `node solution.js`,
      stdout: outputs.join('\n'),
      stderr: errors.length > 0 ? errors.join('\n') : undefined,
      exitCode: errors.length > 0 ? 1 : 0,
      executionTimeMs: Math.max(5, Math.round(performance.now() - startTime)),
      memoryUsageKb: 3820,
    };
  } catch (err: any) {
    return {
      success: false,
      compileOutput: `node solution.js`,
      stdout: outputs.join('\n'),
      stderr: `${err.name}: ${err.message}`,
      exitCode: 1,
      executionTimeMs: Math.round(performance.now() - startTime),
      memoryUsageKb: 3820,
    };
  } finally {
    console.log = originalLog;
    console.error = originalError;
    console.warn = originalWarn;
  }
}

/**
 * Java Execution
 */
function runJava(code: string, stdin: string, startTime: number): ExecutionResult {
  const compileLogs = [
    `javac Main.java`,
    `Compiled Main.class`,
    `java Main`,
  ];

  if (!code.includes('main') || !code.includes('class')) {
    return {
      success: false,
      compileOutput: `javac Main.java\nMain.java: error: main method or class missing`,
      stdout: '',
      stderr: `Error: Main method not found in class Main`,
      exitCode: 1,
      executionTimeMs: Math.round(performance.now() - startTime),
      memoryUsageKb: 0,
    };
  }

  const outputs: string[] = [];
  const printRegex = /System\.out\.println\s*\(\s*([^)]*)\s*\)\s*;/g;
  let match;
  while ((match = printRegex.exec(code)) !== null) {
    const inside = match[1].trim();
    if (inside.startsWith('"') && inside.endsWith('"')) {
      outputs.push(inside.slice(1, -1));
    } else {
      try {
        outputs.push(String(Function(`"use strict"; return (${inside});`)()));
      } catch {
        outputs.push(inside);
      }
    }
  }

  if (outputs.length === 0) {
    outputs.push(`Execution finished. [Process terminated with exit code 0]`);
  }

  return {
    success: true,
    compileOutput: compileLogs.join('\n'),
    stdout: outputs.join('\n'),
    exitCode: 0,
    executionTimeMs: Math.max(22, Math.round(performance.now() - startTime)),
    memoryUsageKb: 6800,
  };
}

function splitCArgs(argsStr: string): string[] {
  const result: string[] = [];
  let current = '';
  let inQuote = false;
  let quoteChar = '';

  for (let i = 0; i < argsStr.length; i++) {
    const ch = argsStr[i];
    if ((ch === '"' || ch === "'") && (i === 0 || argsStr[i - 1] !== '\\')) {
      if (!inQuote) {
        inQuote = true;
        quoteChar = ch;
      } else if (quoteChar === ch) {
        inQuote = false;
      }
    }
    if (ch === ',' && !inQuote) {
      result.push(current);
      current = '';
    } else {
      current += ch;
    }
  }
  if (current) result.push(current);
  return result;
}
