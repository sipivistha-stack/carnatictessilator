/**
 * AI Quiz Generator
 * Automatically creates structured quizzes and MCQs for teachers with rich questions, options,
 * correct answers, explanations, and point allocations.
 */

import { QuizQuestion, McqQuestion } from '../types';

export interface GeneratedQuiz {
  title: string;
  description: string;
  topic: string;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  questions: QuizQuestion[];
  totalPoints: number;
}

const QUIZ_BANKS: Record<string, { title: string; questions: QuizQuestion[] }> = {
  carnatic_music: {
    title: 'Carnatic Classical Music Theory & Ragas Quiz',
    questions: [
      {
        id: 'q-cm-1',
        question: 'Which of the following is the 15th Melakarta Raga in the Venkatamakhin scheme?',
        options: ['Mayamalavagowla', 'Kalyani', 'Kharaharapriya', 'Shankarabharanam'],
        correctOptionIndex: 0,
        points: 2,
      },
      {
        id: 'q-cm-2',
        question: 'How many Aksharas are there in one complete Avartanam of Adi Tala (Chatusra Jathi Triputa Tala)?',
        options: ['6 Aksharas', '8 Aksharas', '7 Aksharas', '10 Aksharas'],
        correctOptionIndex: 1,
        points: 2,
      },
      {
        id: 'q-cm-3',
        question: 'What is the Swara interval relationship between Shadjam (S) and Panchama (P)?',
        options: ['4/3 (Samvadi)', '3/2 (Vadi - Perfect Fifth)', '5/4 (Antara Gandhara)', '15/8 (Kakali Nishadha)'],
        correctOptionIndex: 1,
        points: 2,
      },
      {
        id: 'q-cm-4',
        question: 'Saint Tyagaraja, Muthuswami Dikshitar, and Syama Sastri are collectively revered as:',
        options: ['The Alwars of Thanjavur', 'The Trinity of Carnatic Music', 'The Navagraha Vaggeyakaras', 'The Pancharatna Composers'],
        correctOptionIndex: 1,
        points: 2,
      },
      {
        id: 'q-cm-5',
        question: 'Which Tala has 6 Aksharas consisting of one Dhrutam followed by one Laghu?',
        options: ['Rupaka Tala', 'Mishra Chapu', 'Jhampa Tala', 'Dhruva Tala'],
        correctOptionIndex: 0,
        points: 2,
      },
      {
        id: 'q-cm-6',
        question: 'What are the Shadangas in the Tala system?',
        options: [
          'Anudhrutam, Dhrutam, Laghu, Guru, Plutam, Kakapadam',
          'Arohana, Avarohana, Vadi, Samvadi, Vivadi, Anuvadi',
          'Vilambita, Madhyama, Dhruta, Atidhruta, Tisra, Khanda',
          'Sarali, Janta, Dhatu, Alankara, Geetham, Varnam'
        ],
        correctOptionIndex: 0,
        points: 2,
      },
      {
        id: 'q-cm-7',
        question: 'In Raga Mohanam, which two swaras are omitted from the Shankarabharanam scale?',
        options: ['Ri and Dha', 'Ma and Ni', 'Ga and Pa', 'Ri and Ni'],
        correctOptionIndex: 1,
        points: 2,
      },
      {
        id: 'q-cm-8',
        question: 'What is the frequency of "1 Kattai" (Concert pitch C) in the Carnatic Shruti scale?',
        options: ['130.81 Hz', '146.83 Hz', '196.00 Hz', '220.00 Hz'],
        correctOptionIndex: 0,
        points: 2,
      },
      {
        id: 'q-cm-9',
        question: 'Which sacred town in Tamil Nadu is renowned as the birthplace of the musical Trinity?',
        options: ['Thiruvarur', 'Madurai', 'Tirupati', 'Thanjavur'],
        correctOptionIndex: 0,
        points: 2,
      },
      {
        id: 'q-cm-10',
        question: 'What is the characteristic gamaka in Muthuswami Dikshitar compositions?',
        options: ['Rapid kampitam', 'Majestic vilambita kala jarus and andolitam', 'High-speed brikkas only', 'Staccato aksharas'],
        correctOptionIndex: 1,
        points: 2,
      }
    ]
  },
  python_data_science: {
    title: 'Python, NumPy, Pandas & Matplotlib Quiz',
    questions: [
      {
        id: 'q-py-1',
        question: 'Which method in Pandas returns the first 5 rows of a DataFrame by default?',
        options: ['df.top()', 'df.head()', 'df.first()', 'df.preview()'],
        correctOptionIndex: 1,
        points: 2,
      },
      {
        id: 'q-py-2',
        question: 'In Matplotlib, which command displays the generated graphical figure?',
        options: ['plt.render()', 'plt.show()', 'plt.draw_all()', 'plt.display()'],
        correctOptionIndex: 1,
        points: 2,
      },
      {
        id: 'q-py-3',
        question: 'What does np.linspace(0, 10, 5) produce in NumPy?',
        options: [
          'Array of 5 evenly spaced numbers from 0 to 10',
          'Array of integers [0, 2, 4, 6, 8, 10]',
          'Random matrix of size 5x5',
          'Linear regression line coefficients'
        ],
        correctOptionIndex: 0,
        points: 2,
      },
      {
        id: 'q-py-4',
        question: 'Which Pandas function calculates summary statistics (mean, std, min, max, quartiles)?',
        options: ['df.summary()', 'df.stats()', 'df.describe()', 'df.calculate()'],
        correctOptionIndex: 2,
        points: 2,
      },
      {
        id: 'q-py-5',
        question: 'What is the time complexity of looking up a key in a Python dictionary?',
        options: ['O(n)', 'O(log n)', 'O(1) average', 'O(n^2)'],
        correctOptionIndex: 2,
        points: 2,
      }
    ]
  },
  html_css_web: {
    title: 'HTML5 & Modern CSS3 Web Development Quiz',
    questions: [
      {
        id: 'q-web-1',
        question: 'Which HTML5 semantic element should represent independent, self-contained article content?',
        options: ['<section>', '<article>', '<div>', '<main>'],
        correctOptionIndex: 1,
        points: 2,
      },
      {
        id: 'q-web-2',
        question: 'In CSS Flexbox, which property aligns items along the cross-axis?',
        options: ['justify-content', 'align-items', 'flex-direction', 'align-content'],
        correctOptionIndex: 1,
        points: 2,
      },
      {
        id: 'q-web-3',
        question: 'What is the correct CSS declaration to create a 3-column responsive CSS Grid?',
        options: [
          'grid-template-columns: repeat(3, 1fr);',
          'display: flex-columns(3);',
          'columns: 3 auto;',
          'grid-layout: 3;'
        ],
        correctOptionIndex: 0,
        points: 2,
      },
      {
        id: 'q-web-4',
        question: 'Which attribute in <input> makes the field mandatory before submitting a form?',
        options: ['validate="true"', 'required', 'mandatory', 'checked'],
        correctOptionIndex: 1,
        points: 2,
      },
      {
        id: 'q-web-5',
        question: 'What CSS property adds a drop shadow effect around an element box?',
        options: ['text-shadow', 'box-shadow', 'filter: outline', 'border-shadow'],
        correctOptionIndex: 1,
        points: 2,
      }
    ]
  }
};

export function generateQuizWithAI(
  topicKey: string,
  questionCount: number = 5,
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced' = 'Intermediate',
  customPrompt?: string
): GeneratedQuiz {
  // Use curated quiz banks or dynamic generation
  const bank = QUIZ_BANKS[topicKey] || QUIZ_BANKS.carnatic_music;
  const questions = bank.questions.slice(0, questionCount);

  // If custom prompt is provided, tailor title
  const title = customPrompt
    ? `AI Quiz: ${customPrompt}`
    : `${bank.title} (${difficulty})`;

  const totalPoints = questions.reduce((sum, q) => sum + q.points, 0);

  return {
    title,
    description: `Auto-generated ${difficulty} level examination with ${questions.length} questions. Automated scoring and grading enabled.`,
    topic: topicKey,
    difficulty,
    questions,
    totalPoints,
  };
}
